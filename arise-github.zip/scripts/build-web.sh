#!/bin/bash
# إعادة البناء بعد أي تعديل على src/content — كل شيء داخل مجلد المستودع
cd "$(dirname "$0")/.."
node src/build.mjs                    # → يكتب qudrat-quest.jsx في جذر المستودع
cat > .entry.jsx << 'E'
import { createRoot } from "react-dom/client";
import App from "./qudrat-quest.jsx";
createRoot(document.getElementById("root")).render(<App />);
E
npm i >/dev/null
npx esbuild .entry.jsx --bundle --minify --jsx=automatic --define:process.env.NODE_ENV='"production"' --outfile=assets/app.js
rm .entry.jsx
echo "✅ تم — ادفع التغييرات إلى GitHub"
