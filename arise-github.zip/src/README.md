# Qudrat Quest — Content-Driven Architecture

## البنية
- **engine.jsx** — المحرك الثابت (لا تلمسه): كل الأنظمة، المولدات، الواجهات.
- **content/** — كل المحتوى بيانات صِرفة:
  - `questions-core.js` — بنك الأسئلة (mcq/num/match/order) + الأسئلة الغنية.
  - `lessons-core.js` — مناهج المراحل F/S/Q/P/C + اختبار تحديد المستوى.
  - `awl-s1.js … awl-s3.js` — 180 كلمة AWL مكتملة. `awl-s4 … s10` قوالب جاهزة للتعبئة.
- **build.mjs** — يجمع المحرك + كل ملفات content/ في `../qudrat-quest.jsx` (ملف اللعبة).

## كيف تضيف محتوى (بدون أي كود)
```bash
node build.mjs        # بعد أي تعديل على content/
```
- **1000 سؤال جديد؟** أنشئ `content/questions-geometry.js`:
  `QQ.registerQuestions([{ topic:"geometry", diff:2, skill:"مساحات", est:50, type:"mcq", q:"...", options:[..4], a:1, ex:"...", steps:[...], hints:[...], traps:{0:"..."}, alt:"..." }])`
- **قائمة AWL جديدة؟** عبّئ `awl-s4.js` بنفس مخطط `awl-s1.js` — الحزم والتدريبات والنطق والمراجعة المتباعدة ومعارك الكلمات تُبنى تلقائيًا.
- **درس جديد؟** أضف وحدة داخل مرحلة في `lessons-core.js` (بطاقات + تدريبات) وسجّل متطلبها في PREREQ إن أردت.

`validateContent()` يفحص كل المحتوى عند التشغيل ويطبع أي خلل (خيارات ناقصة، إجابة خارج المدى، كلمة بلا حقول).
