import { useState, useEffect, useRef } from "react";

/* ═══════════════════════════════════════════════════════════
   ⚔️ QUDRAT QUEST — رحلة من الثانوية إلى أرامكو
   RPG • Adventure • Puzzle — أسئلة القدرات هي سلاحك
   ═══════════════════════════════════════════════════════════ */

/* ---------- 🔊 SOUND ENGINE (WebAudio synth) ---------- */
let AC = null;
const ac = () => (AC ||= new (window.AudioContext || window.webkitAudioContext)());
function tone(freq, dur = 0.12, type = "sine", vol = 0.18, delay = 0) {
  try {
    const c = ac();
    if (c.state === "suspended") c.resume();
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(vol, c.currentTime + delay);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + delay + dur);
    o.connect(g); g.connect(c.destination);
    o.start(c.currentTime + delay); o.stop(c.currentTime + delay + dur + 0.05);
  } catch (e) {}
}
const SFX = {
  click: () => tone(600, 0.05, "square", 0.06),
  correct: () => { tone(523, 0.1); tone(784, 0.14, "sine", 0.18, 0.09); },
  crit: () => { tone(523, 0.08); tone(659, 0.08, "sine", 0.2, 0.07); tone(1047, 0.2, "sine", 0.2, 0.14); },
  wrong: () => tone(150, 0.26, "sawtooth", 0.1),
  coin: () => { tone(988, 0.06, "square", 0.1); tone(1319, 0.12, "square", 0.1, 0.06); },
  levelup: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.15, "triangle", 0.16, i * 0.11)),
  boss: () => { tone(110, 0.5, "sawtooth", 0.12); tone(98, 0.5, "sawtooth", 0.12, 0.4); },
  win: () => [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, 0.2, "triangle", 0.15, i * 0.13)),
  door: () => { tone(220, 0.2, "triangle", 0.12); tone(330, 0.25, "triangle", 0.12, 0.15); },
  step: () => { tone(480, 0.04, "square", 0.05); tone(500, 0.04, "square", 0.05, 0.16); tone(480, 0.04, "square", 0.05, 0.32); },
  heart: () => { tone(180, 0.18, "triangle", 0.14); tone(140, 0.25, "triangle", 0.12, 0.12); },
};
let soundOn = true;
const play = (name) => { if (soundOn) SFX[name]?.(); };

/* ---------- 🎵 AMBIENT MUSIC (مقطوعات أصلية مولّدة) ---------- */
let musicTimer = null, musicTimer2 = null;
function stopMusic() {
  if (musicTimer) clearInterval(musicTimer);
  if (musicTimer2) clearInterval(musicTimer2);
  musicTimer = musicTimer2 = null;
}
// 🌙 "حالمة": باد بطيء حزين-هادئ (أجواء dream pop)
const DREAM_CHORDS = [[130.8, 196, 246.9], [110, 164.8, 220], [123.5, 185, 246.9], [98, 146.8, 196]];
// 🌈 "متوهجة": أربيجيو دافئ متموّج
const GLOW_ARP = [196, 246.9, 293.7, 370, 293.7, 246.9];
function startMusic(mood) {
  stopMusic();
  if (mood === "dream") {
    let ci = 0;
    const pad = () => {
      const ch = DREAM_CHORDS[ci % DREAM_CHORDS.length]; ci++;
      ch.forEach((f, i) => { tone(f, 4.2, "sine", 0.035, i * 0.06); tone(f * 2.0, 3.6, "sine", 0.012, 0.3); });
      if (Math.random() > 0.55) tone(ch[1] * 3, 1.8, "sine", 0.015, 1.2);
    };
    pad();
    musicTimer = setInterval(pad, 4600);
  } else if (mood === "glow") {
    let step = 0, base = 1;
    musicTimer = setInterval(() => {
      const f = GLOW_ARP[step % GLOW_ARP.length] * base;
      tone(f, 0.9, "triangle", 0.03);
      step++;
      if (step % 12 === 0) base = base === 1 ? 0.75 : 1;
    }, 460);
    musicTimer2 = setInterval(() => tone(98, 3.8, "sine", 0.03), 3800);
  }
}

/* ---------- ❓ QUESTION POOL ---------- */

/* ═══════════════════════════════════════════════════════════
   📦 QQ CONTENT REGISTRY — Content-Driven Architecture
   المحرك بلا محتوى: كل شيء يصل من content/*.js وقت البناء
   ═══════════════════════════════════════════════════════════ */
/* 🔌 جسر التخزين: داخل Claude يستخدم window.storage، وعلى الويب localStorage — مع ترحيل تلقائي */
const SAVE_KEY = "arise-save";
const store = {
  async get(k) {
    if (typeof window !== "undefined" && window.storage) { try { return await window.storage.get(k); } catch (e) { return null; } }
    try { const v = localStorage.getItem(k); return v ? { value: v } : null; } catch (e) { return null; }
  },
  async set(k, v) {
    if (typeof window !== "undefined" && window.storage) { try { return await window.storage.set(k, v); } catch (e) { return null; } }
    try { localStorage.setItem(k, v); } catch (e) {}
  },
};

const QQ = {
  _core: { mcq: [], num: [], match: [], order: [], verbalSecs: [] },
  _rich: [], _lessons: {}, _awl: {},
  registerCore(o) { ["mcq","num","match","order","verbalSecs"].forEach(k => o[k] && this._core[k].push(...o[k])); },
  registerQuestions(list, defaults = {}) { list.forEach(q => this._rich.push({ ...defaults, ...q })); },
  registerLessons(p) { Object.assign(this._lessons, p); },
  registerAWL(id, data) { this._awl[id] = data; },
  manifest() {
    const words = Object.values(this._awl).reduce((a,s)=>a+s.packs.reduce((x,p)=>x+p.words.length,0),0);
    return { mcq: this._core.mcq.length, num: this._core.num.length, rich: this._rich.length,
             sublists: Object.keys(this._awl).length, awlWords: words, phases: Object.keys(this._lessons).length };
  },
};

/*__CONTENT_INJECT__*/

/* ═══════════════════════════════════════════════════════════
   🏦 CONTENT BANK — بنك المحتوى الموحّد القابل للتوسع
   أضف آلاف الأسئلة عبر addQuestions() فقط — بلا أي تعديل كود
   ═══════════════════════════════════════════════════════════ */
const BANK = [];
let _bid = 0;
/** مخطط السؤال الكامل:
 * subject: 'quant'|'verbal'   المادة
 * topic:   sec                الموضوع (arithmetic, analogy, ...)
 * diff:    1|2|3              الصعوبة (تأسيسي/قدرات/صفوة)
 * skill:   نص المهارة         ("نسبة التغيّر", "كلمات الإشارة"...)
 * est:     ثوانٍ متوقعة للحل
 * type:    'mcq'|'num'
 * q, options?, a, ex          نص السؤال والإجابة والشرح المختصر
 * steps?:  string[]           خطوات الحل بالتدريج
 * hints?:  string[]           تلميحات تدريجية (من الأخف للأصرح)
 * traps?:  {idx: سبب اختياره} تشخيص سبب الخطأ لكل خيار مضلل
 * alt?:    string             طريقة حل ثانية                       */
function addQuestions(list, defaults = {}) {
  list.forEach(raw => {
    const q = { diff: 2, type: raw.options ? "mcq" : "num", est: 45, ...defaults, ...raw };
    q.subject ||= ["analogy", "sentence", "reading", "vocab"].includes(q.topic) ? "verbal" : "quant";
    q.id = q.id || `${q.topic}-${_bid++}`;
    BANK.push(q);
  });
}
const bankPick = ({ topics, n, diffs = [1, 2, 3], g = null, exclude = [] }) => {
  const pool = BANK.filter(x => topics.includes(x.topic) && diffs.includes(x.diff) && !exclude.includes(x.id));
  if (!g) return [...pool].sort(() => Math.random() - 0.5).slice(0, n);
  const byT = {}; topics.forEach(t => byT[t] = pool.filter(x => x.topic === t).sort(() => Math.random() - 0.5));
  const out = [];
  while (out.length < n) {
    const avail = topics.filter(t => byT[t].length);
    if (!avail.length) break;
    const tot = avail.reduce((a, t) => a + weightOf(g, t), 0);
    let r = Math.random() * tot, pick = avail[0];
    for (const t of avail) { r -= weightOf(g, t); if (r <= 0) { pick = t; break; } }
    out.push(byT[pick].shift());
  }
  return out;
};
const bankSimilar = (q) => {
  const c = BANK.filter(x => x.topic === q.topic && x.id !== q.id && x.type === "mcq" && x.diff <= q.diff);
  return c.length ? c[Math.floor(Math.random() * c.length)] : null;
};
const battleDiffs = (g, isBoss) => {
  const base = g.chapter <= 2 ? 1 : g.chapter <= 5 ? 2 : 3;
  return isBoss ? [Math.min(3, base), Math.min(3, base + 1)] : [Math.max(1, base - 1), base];
};

/* ── تسجيل الرصيد الحالي في البنك (المهارة والوقت لكل موضوع) ── */
const TOPIC_META = {
  arithmetic: { skill: "حساب ونسب", est: 45 }, algebra: { skill: "جبر", est: 45 },
  geometry: { skill: "هندسة", est: 50 }, comparison: { skill: "مقارنات", est: 40 },
  data: { skill: "تحليل بيانات", est: 50 }, analogy: { skill: "تناظر لفظي", est: 35 },
  sentence: { skill: "إكمال جمل", est: 40 }, reading: { skill: "استيعاب مقروء", est: 60 },
};

/* ── دفعة أسئلة غنية: خطوات + تلميحات + تشخيص فخوخ + طرق بديلة ── */
function buildChallenges(secs, count, g, isBoss) {
  // 🧠 اختيار موزون من البنك: الأقسام الضعيفة تظهر أكثر + صعوبة تتدرج مع تقدمك
  const out = bankMCQ(secs, count, g, battleDiffs(g, isBoss)).map(q => ({ kind: "mcq", ...q, sec: q.topic }));
  while (out.length < count) {
    const extra = bankMCQ(secs, count - out.length, g, [1, 2, 3]).map(q => ({ kind: "mcq", ...q, sec: q.topic }));
    if (!extra.length) break;
    out.push(...extra);
  }
  const quantIn = secs.filter(s => ["arithmetic", "algebra", "geometry", "data"].includes(s));
  const hasVerbal = secs.some(s => VERBAL_SECS.includes(s));
  if (quantIn.length) {
    // لوحة الأرقام تستهدف أضعف قسم كمي عند اللاعب
    const target = weakestOf(g, quantIn);
    const nums = NUMQ.filter(n => n.sec === target).sort(() => Math.random() - 0.5).slice(0, 2)
      .concat(NUMQ.filter(n => quantIn.includes(n.sec) && n.sec !== target).sort(() => Math.random() - 0.5))
      .slice(0, 2).map(n => ({ kind: "num", ...n }));
    out.splice(1, Math.min(nums.length, out.length > 3 ? nums.length : 1), ...nums);
  }
  if (hasVerbal && (weightOf(g, "vocab") > 45 || Math.random() < 0.6)) {
    // 🎓 لو تعلمت حزم AWL، معارك الكلمات تستخدم كلماتك أنت
    const learned = Object.keys(AWL_WORDS).filter(id => acadDone(g, id)).flatMap(id => AWL_WORDS[id]);
    const m = learned.length >= 4 && Math.random() < 0.7
      ? { pairs: [...learned].sort(() => Math.random() - 0.5).slice(0, 4).map(w => [w.w, w.ar]) }
      : MATCH_SETS[Math.floor(Math.random() * MATCH_SETS.length)];
    out.splice(Math.min(2, out.length), 0, { kind: "match", sec: "vocab", ...m });
  }
  // ✍️ كلماتك المتعلمة تتحول لأسئلة إكمال جمل بنمط الاختبار
  if (secs.includes("sentence")) {
    const learned = Object.keys(AWL_WORDS).filter(id => acadDone(g, id)).flatMap(id => AWL_WORDS[id]);
    if (learned.length >= 4 && Math.random() < 0.5) {
      const w = learned[Math.floor(Math.random() * learned.length)];
      const wrong = learned.filter(x => x.w !== w.w).sort(() => Math.random() - 0.5).slice(0, 3).map(x => x.w);
      const opts = [w.w, ...wrong].sort(() => Math.random() - 0.5);
      out.splice(Math.min(1, out.length), 0, { kind: "mcq", sec: "sentence", skill: "AWL في سياق", diff: 2,
        q: w.bl, options: opts, a: opts.indexOf(w.w), ex: `${w.w} (${w.ar}) — ${w.ex}` });
    }
  }
  if (quantIn.length) {
    const pool = ORDER_QS.filter(o => quantIn.includes(o.sec));
    if (pool.length) {
      const target = weakestOf(g, pool.map(o => o.sec));
      const chosen = pool.filter(o => o.sec === target)[0] || pool[Math.floor(Math.random() * pool.length)];
      out.splice(Math.min(4, out.length), 0, { kind: "order", ...chosen });
    }
  }
  return out;
}


/* ═══════════════════════════════════════════════════════════
   🎓 THE ACADEMY — رحلة تعليم كاملة من الصفر إلى القدرات
   4 مراحل: تأسيس → بناء مهارات → قدرات → احتراف
   ═══════════════════════════════════════════════════════════ */


/* ═══════════════════════════════════════════════════════════
   🎓 ARAMCO TRACK — AWL Engine + CPC Prep
   الكلمات بيانات فقط: addAWL() يستقبل بقية القوائم لاحقًا بلا كود
   ═══════════════════════════════════════════════════════════ */
function say(w) { try { const u = new SpeechSynthesisUtterance(w); u.lang = "en-US"; u.rate = 0.88; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) {} }

/* AWL Sublist 1 — 60 كلمة كاملة التأليف */
/* مولّد تدريبات AWL: معنى ← فراغ ← مرادف/ضد — من البيانات مباشرة */
function awlDrills(words) {
  const pick3 = (arr) => [...arr].sort(() => Math.random() - 0.5).slice(0, 3);
  return words.map((w, i) => {
    const others = words.filter(x => x.w !== w.w);
    const shuffle = (opts, right) => { const o = [...opts].sort(() => Math.random() - 0.5); return { o, a: o.indexOf(right) }; };
    if (i % 3 === 0) {
      const { o, a } = shuffle([w.ar, ...pick3(others).map(x => x.ar)], w.ar);
      return { q: `«${w.w}» means:`, options: o, a, ex: `${w.w} = ${w.ar}. مثال: ${w.ex}` };
    }
    if (i % 3 === 1) {
      const { o, a } = shuffle([w.w, ...pick3(others).map(x => x.w)], w.w);
      return { q: w.bl.replace("_____", "_____ "), options: o, a, ex: `${w.w} (${w.ar}) — ${w.ex}` };
    }
    if (w.ant && i % 6 === 5) {
      const { o, a } = shuffle([w.ant, ...pick3(others.map(x => x.w))], w.ant);
      return { q: `The OPPOSITE of «${w.w}» is:`, options: o, a, ex: `${w.w} (${w.ar}) عكسها ${w.ant}.` };
    }
    const { o, a } = shuffle([w.syn, ...pick3(others.map(x => x.w))], w.syn);
    return { q: `A synonym of «${w.w}» is:`, options: o, a, ex: `${w.w} ≈ ${w.syn} — كلاهما بمعنى ${w.ar}.` };
  });
}
function addAWL(id, icon, name, words) {
  return { id, icon, name, awl: words, need: 5, cards: words.map(w => ({ h: w.w, t: w.ar })), drills: awlDrills(words) };
}
const SRS_INT = [1, 2, 4, 8, 14, 25];   // فواصل المراجعة بأيام اللعبة
const PREREQ = {
  f1: [], f2: ["f1"], f3: ["f2"], f4: ["f1"], f5: ["f4"], f6: [], f7: ["f6"], f8: ["f6"],
  s1: ["f3"], s2: ["f5"], s3: ["f1"], s4: ["f2"], s5: ["f8"], s6: ["f7"],
  q1: ["s4"], q2: ["s2"], q3: ["q1"],
  p1: ["q1", "q2", "q3"], p2: ["p1"],
  c1: ["p2"], c2: ["c1"], c3: ["c2"], c4: ["c3"],
};
const unitById = (id) => { for (const ph of ACADEMY) { const u = ph.units.find(x => x.id === id); if (u) return { u, ph }; } return null; };
const prereqMet = (g, uid) => (PREREQ[uid] || []).every(pid => acadDone(g, pid));
const dueList = (g) => Object.entries(g.srs || {})
  .filter(([id, s]) => s.due <= g.day)
  .map(([id]) => unitById(id))
  .filter(x => x && x.u.drills && x.u.drills.length);

// حالة كل مفهوم على الخريطة
function nodeState(g, uid, phaseIdx) {
  const s = (g.srs || {})[uid];
  if (acadDone(g, uid)) {
    if (s && s.due <= g.day) return { k: "review", label: "يحتاج مراجعة", c: "#E58E26", e: "🟠" };
    if (s && s.lvl >= 3) return { k: "master", label: "أتقنه", c: "#C89235", e: "🥇" };
    return { k: "known", label: "فهمه", c: "#1F7A5C", e: "🟢" };
  }
  const open = prereqMet(g, uid) || phaseIdx < (g.acad?.placed ?? -1);
  if (g.acad?.opened?.[uid]) return { k: "learning", label: "يتعلمه", c: "#3B82C4", e: "🔵" };
  if (open) return { k: "ready", label: "جاهز للتعلم", c: "#3B82C4", e: "🔵" };
  return { k: "locked", label: "لم يبدأ", c: "#8A968E", e: "⚪" };
}

// مسارات الشجرة للعرض
const KNOW_TRACKS = [
  { name: "🧮 مسار الحساب", ids: ["f1", "f2", "f3", "s1"] },
  { name: "⚖️ مسار الجبر", ids: ["f1", "f4", "f5", "s2"] },
  { name: "📐 الهندسة والبيانات", ids: ["f1", "s3", "s4"] },
  { name: "🔤 مسار اللغة", ids: ["f6", "f7", "s6"] },
  { name: "🗝️ مسار المفردات", ids: ["f6", "f8", "s5"] },
  { name: "🧭 الاستراتيجيات", ids: ["s4", "q1", "q3"] },
  { name: "🥇 الاحتراف", ids: ["q3", "p1", "p2"] },
  { name: "🎓 مسار AWL الأكاديمي", ids: ["f8", "a1", "a3", "a6"] },
  { name: "🏭 مسار CPC", ids: ["p2", "c1", "c3", "c4"] },
];


/* ═══ FINALIZE — بناء هياكل اللعبة من سجل المحتوى ═══ */
const QUESTIONS = QQ._core.mcq;
const NUMQ = QQ._core.num;
const MATCH_SETS = QQ._core.match;
const ORDER_QS = QQ._core.order;
const VERBAL_SECS = QQ._core.verbalSecs;
const PLACEMENT = QQ._lessons.PLACEMENT;

addQuestions(QUESTIONS.map(q => ({ ...q, topic: q.sec, ...TOPIC_META[q.sec], diff: 2 })));
addQuestions(QQ._rich);
addQuestions(NUMQ.map(q => ({ ...q, topic: q.sec, type: "num", ...TOPIC_META[q.sec], diff: 1 })));
const bankMCQ = (topics, n, g, diffs) => bankPick({ topics, n, g, diffs }).filter(x => x.type === "mcq");

/* مرحلة AWL تُبنى ديناميكيًا من كل القوائم المسجلة، مع سلسلة متطلباتها */
const AWL_WORDS = {};
function buildAWLPhase() {
  const units = []; let prev = "f8";
  Object.keys(QQ._awl).sort().forEach(sid => QQ._awl[sid].packs.forEach(p => {
    AWL_WORDS[p.id] = p.words;
    units.push(addAWL(p.id, p.icon, `${QQ._awl[sid].title} • ${p.name}`, p.words));
    PREREQ[p.id] = [prev]; prev = p.id;
  }));
  return { id: "A", name: "Aramco Track: الإنجليزية الأكاديمية (AWL)", icon: "🎓", color: "#2E7DA6",
    desc: `${units.length} حزمة • ${Object.values(AWL_WORDS).reduce((a,w)=>a+w.length,0)} كلمة — معنى ونطق ومعارك ومراجعة متباعدة`, units };
}
const PHASE_AWL = buildAWLPhase();
function validateContent() {
  const issues = [];
  BANK.forEach(q => {
    if (q.type === "mcq" && (!q.options || q.options.length !== 4 || q.a < 0 || q.a > 3)) issues.push("bank mcq: " + q.id);
    if (!q.ex) issues.push("bank بلا شرح: " + q.id);
  });
  Object.entries(AWL_WORDS).forEach(([pid, ws]) => ws.forEach(w => {
    if (!w.w || !w.ar || !w.ex || !w.syn || !w.bl || !w.bl.includes("_____")) issues.push(`awl ${pid}: ${w.w || "?"}`);
  }));
  ACADEMY.forEach(ph => ph.units.forEach(u => (u.drills || []).forEach((d, i) => {
    if (d.kind !== "num" && (!d.options || d.a >= d.options.length)) issues.push(`درل ${u.id}#${i}`);
  })));
  if (issues.length) console.warn("⚠️ Content issues:", issues);
  return issues.length;
}
const ACADEMY = [QQ._lessons.F, QQ._lessons.S, PHASE_AWL, QQ._lessons.Q, QQ._lessons.P, QQ._lessons.C];
{
  const aw = KNOW_TRACKS.find(t => t.name.includes("AWL"));
  const U = PHASE_AWL.units;
  if (aw && U.length) aw.ids = ["f8", U[0].id, U[Math.floor(U.length/2)].id, U[U.length-1].id];
}
validateContent();

const acadDone = (g, unitId) => !!(g.acad && g.acad.units && g.acad.units[unitId]);
const phaseDone = (g, phaseId) => { const ph = ACADEMY.find(p => p.id === phaseId); return ph.units.every(u => acadDone(g, u.id)); };
const phaseProg = (g, ph) => Math.round((ph.units.filter(u => acadDone(g, u.id)).length / ph.units.length) * 100);

/* ---------- 🌳 SKILL TREE ---------- */
const SKILLS = [
  { id: "qtime", branch: "الكمي", icon: "🧮", name: "عين المحلّل", desc: "+8 ثوانٍ في أسئلة الكمي", cost: 1 },
  { id: "qcrit", branch: "الكمي", icon: "💥", name: "ضربة حسابية", desc: "الكريت في الكمي يبدأ من كومبو ×2", cost: 2 },
  { id: "vtime", branch: "اللفظي", icon: "📖", name: "قارئ سريع", desc: "+8 ثوانٍ في أسئلة اللفظي", cost: 1 },
  { id: "vhint", branch: "اللفظي", icon: "🔮", name: "حدس لغوي", desc: "تلميح مجاني بداية كل معركة", cost: 2 },
  { id: "heart4", branch: "عام", icon: "🫀", name: "قلب المحارب", desc: "قلب رابع دائم في المعارك", cost: 3 },
  { id: "gold", branch: "عام", icon: "💰", name: "جيب عميق", desc: "+50% عملات من كل معركة", cost: 2 },
];

/* ---------- 🛒 SHOP ---------- */
const SHOP_ITEMS = [
  { id: "hint", icon: "💡", name: "تلميح", desc: "يحذف خيارين خاطئين", price: 30 },
  { id: "freeze", icon: "🧊", name: "تجميد الوقت", desc: "يوقف العداد لسؤال واحد", price: 40 },
  { id: "potion", icon: "🧪", name: "جرعة حياة", desc: "يرجع قلبًا مفقودًا في المعركة", price: 50 },
];
const AVATARS = [
  { id: "a1", e: "🧑‍🎓", name: "طالب", price: 0 },
  { id: "a2", e: "🥷", name: "نينجا القدرات", price: 120 },
  { id: "a3", e: "🦅", name: "الصقر", price: 160 },
  { id: "a4", e: "🐪", name: "ابن الصحراء", price: 140 },
  { id: "a5", e: "👨‍🚀", name: "رائد المستقبل", price: 220 },
];

/* ---------- 🏅 ACHIEVEMENTS ---------- */
const ACHV = [
  { id: "first", icon: "🩸", name: "أول انتصار", desc: "اربح أول معركة" },
  { id: "combo5", icon: "🔥", name: "سلسلة نارية", desc: "كومبو ×5 في معركة" },
  { id: "ch1", icon: "🎒", name: "خريج الثانوية", desc: "أنهِ الفصل الأول" },
  { id: "gat90", icon: "🏆", name: "نادي الـ90", desc: "حقق 90+ في اختبار القدرات" },
  { id: "rich", icon: "💰", name: "التاجر", desc: "اجمع 500 عملة" },
  { id: "usa", icon: "✈️", name: "مغترب", desc: "اوصل إلى أمريكا" },
  { id: "grad", icon: "🎓", name: "بكالوريوس", desc: "تخرّج من الجامعة" },
  { id: "aramco", icon: "🛢️", name: "حلم أرامكو", desc: "احصل على الوظيفة" },
  { id: "streak3", icon: "⚡", name: "منضبط", desc: "3 أيام لعب متتالية" },
  { id: "skills3", icon: "🌳", name: "متطوّر", desc: "افتح 3 مهارات" },
];

const TITLES = [
  { xp: 0, name: "طالب ثانوي", icon: "🎒" },
  { xp: 150, name: "مجتهد", icon: "📚" },
  { xp: 350, name: "محارب القدرات", icon: "⚔️" },
  { xp: 650, name: "عابر المحيط", icon: "🌊" },
  { xp: 1000, name: "طالب جامعي", icon: "🎓" },
  { xp: 1500, name: "مشروع مهندس", icon: "⚙️" },
  { xp: 2200, name: "أسطورة أرامكو", icon: "👑" },
];


const lvlOf = (xp) => Math.floor(Math.sqrt(xp / 60)) + 1;
const xpForLvl = (l) => 60 * (l - 1) * (l - 1);
const titleOf = (xp) => TITLES.reduce((a, t) => (xp >= t.xp ? t : a), TITLES[0]);

/* ═══════════════════════════════════════════════════════════
   🔁 LOOP ENGINE — مهام دورية، موسم، مقتنيات، خط الرحلة
   ═══════════════════════════════════════════════════════════ */

const DAILY_POOL = [
  { id: "win2", t: "اربح معركتين", goal: 2, ev: "win", r: { coins: 30, xp: 20 } },
  { id: "ans10", t: "أجب 10 إجابات صحيحة", goal: 10, ev: "correct", r: { coins: 25, xp: 15 } },
  { id: "combo3", t: "حقق كومبو ×3 في معركة", goal: 1, ev: "combo3", r: { coins: 20, xp: 15 } },
  { id: "work1", t: "اشتغل وردية عمل", goal: 1, ev: "work", r: { coins: 35, xp: 5 } },
  { id: "perfect", t: "اربح معركة بلا أي خطأ", goal: 1, ev: "perfect", r: { coins: 40, xp: 25 } },
  { id: "talk1", t: "تحدث مع شخصية", goal: 1, ev: "talk", r: { coins: 15, xp: 10 } },
  { id: "awl5", t: "أتقن أو راجع 5 كلمات AWL", goal: 5, ev: "awlword", r: { coins: 30, xp: 20 } },
];
const WEEKLY_POOL = [
  { id: "win8", t: "اربح 8 معارك هذا الأسبوع", goal: 8, ev: "win", r: { coins: 120, xp: 80, item: "potion" } },
  { id: "ans50", t: "50 إجابة صحيحة هذا الأسبوع", goal: 50, ev: "correct", r: { coins: 100, xp: 70, item: "freeze" } },
  { id: "boss2", t: "اهزم زعيمين (تُحسب الإعادة)", goal: 2, ev: "bosswin", r: { coins: 150, xp: 100, item: "hint" } },
  { id: "perfect3", t: "3 معارك مثالية بلا أخطاء", goal: 3, ev: "perfect", r: { coins: 140, xp: 90, item: "potion" } },
  { id: "awl30", t: "30 كلمة AWL هذا الأسبوع", goal: 30, ev: "awlword", r: { coins: 130, xp: 90, item: "hint" } },
];
const SEASON = {
  name: "موسم الرحلة الأول: طريق الـ90",
  tiers: [
    { p: 60, e: "🪙", t: "كيس عملات", r: { coins: 80 } },
    { p: 150, e: "💡", t: "حزمة تلميحات", r: { items: { hint: 2 } } },
    { p: 280, e: "🧪", t: "حزمة بقاء", r: { items: { potion: 2, freeze: 1 } } },
    { p: 450, e: "💰", t: "كنز الموسم", r: { coins: 250 } },
    { p: 650, e: "🏆", t: "صندوق الأسطورة", r: { coins: 300, items: { hint: 2, freeze: 2, potion: 2 } } },
  ],
};
const Q_SECS = ["arithmetic", "algebra", "geometry", "comparison", "data"];
const V_SECS = ["analogy", "sentence", "reading"];

const COLLECT = [
  { id: "cert1", e: "📜", n: "شهادة الثانوية", h: "اهزم الاختبار التجريبي", cond: (g) => g.done["1:boss"] },
  { id: "gatcard", e: "🎫", n: "بطاقة نتيجة قياس", h: "ادخل اختبار القدرات", cond: (g) => !!g.gatScore },
  { id: "gat90m", e: "🥇", n: "وسام نادي الـ90", h: "حقق 90+ في القدرات", cond: (g) => (g.gatScore || 0) >= 90 },
  { id: "accept", e: "✉️", n: "خطاب القبول الجامعي", h: "انقبل في جامعة", cond: (g) => !!g.uni },
  { id: "board", e: "🛂", n: "بطاقة صعود الطائرة", h: "اعبر فرز الابتعاث", cond: (g) => g.done["3:boss"] },
  { id: "mug", e: "☕", n: "كوب ليالي الفاينلات", h: "انجُ من أسبوع الفاينلات", cond: (g) => g.done["5:boss"] },
  { id: "cap", e: "🎓", n: "قبعة التخرج", h: "تخرّج بالبكالوريوس", cond: (g) => g.done["6:boss"] },
  { id: "badge", e: "🪪", n: "بطاقة موظف أرامكو", h: "حقق النهاية الأسطورية", cond: (g) => g.ending === "legend" },
  { id: "flame", e: "🔥", n: "شعلة الكومبو", h: "كومبو ×5", cond: (g) => g.stats.bestCombo >= 5 },
  { id: "bolt", e: "⚡", n: "صاعقة الانضباط", h: "سلسلة 7 أيام", cond: (g) => g.streak >= 7 || g.ach.includes("streak7") },
  { id: "lv5m", e: "🏵️", n: "وسام المستوى 5", h: "اوصل المستوى 5", cond: (g) => lvlOf(g.xp) >= 5 },
  { id: "lv10m", e: "💠", n: "وسام المستوى 10", h: "اوصل المستوى 10", cond: (g) => lvlOf(g.xp) >= 10 },
  { id: "dipF", e: "🧱", n: "شهادة التأسيس", h: "أكمل مرحلة التأسيس بالأكاديمية", cond: (g) => phaseDone(g, "F") },
  { id: "dipS", e: "🔨", n: "شهادة بناء المهارات", h: "أكمل المرحلة الثانية بالأكاديمية", cond: (g) => phaseDone(g, "S") },
  { id: "dipQ", e: "🧭", n: "درع الاستراتيجيات", h: "أكمل مرحلة القدرات بالأكاديمية", cond: (g) => phaseDone(g, "Q") },
  { id: "dipP", e: "🥇", n: "ختم الاحتراف", h: "أكمل المحاكاة والتحدي", cond: (g) => phaseDone(g, "P") },
  { id: "dipA", e: "🎓", n: "شهادة AWL الأكاديمية", h: "أتقن حزم الكلمات الست", cond: (g) => phaseDone(g, "A") },
  { id: "dipC", e: "🏭", n: "شهادة CPC Prep", h: "أكمل تحضير أرامكو", cond: (g) => phaseDone(g, "C") },
  { id: "road6", e: "🏢", n: "طريق أرامكو مكتمل", h: "أنهِ محطات الرحلة الست", cond: (g) => roadMilestones(g).M.every(m => m.done) },
  { id: "steel", e: "🧠", n: "الذاكرة الفولاذية", h: "أوصل مفهومًا لأعلى مستوى تثبيت", cond: (g) => Object.values(g.srs || {}).some(s => s.lvl >= 4) },
];

const dayKey = () => new Date().toDateString();
const weekKey = () => { const d = new Date(); return d.getFullYear() + "-w" + Math.floor((d - new Date(d.getFullYear(), 0, 1)) / 6048e5); };
const seedPick = (pool, seed, count) => {
  let h = 7; for (const c of seed) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  const arr = [...pool]; const out = [];
  for (let i = 0; i < count && arr.length; i++) { h = (h * 1103515245 + 12345) >>> 0; out.push(arr.splice(h % arr.length, 1)[0].id); }
  return out;
};
function ensurePeriods(n) {
  if (!n.daily || n.daily.date !== dayKey()) n.daily = { date: dayKey(), ids: seedPick(DAILY_POOL, dayKey(), 3), prog: {}, claimed: {} };
  if (!n.weekly || n.weekly.week !== weekKey()) n.weekly = { week: weekKey(), ids: seedPick(WEEKLY_POOL, weekKey(), 2), prog: {}, claimed: {} };
  if (!n.season) n.season = { pts: 0, claimed: [] };
  if (!n.history) n.history = [];
  if (!n.timeline) n.timeline = [];
}
function questEv(n, ev, amt = 1) {
  ensurePeriods(n);
  const upd = (scope, pool) => scope.ids.forEach(id => {
    const d = pool.find(p => p.id === id);
    if (d && d.ev === ev && !scope.claimed[id]) scope.prog[id] = Math.min(d.goal, (scope.prog[id] || 0) + amt);
  });
  upd(n.daily, DAILY_POOL); upd(n.weekly, WEEKLY_POOL);
}
function tl(n, k, e, t, b) { if (!n.timeline.some(x => x.k === k)) n.timeline.push({ k, day: n.day, e, t, b }); }

/* ═══ 🪞 شخصية اللاعب المستنتجة من أفعاله ═══ */
function traitsOf(g) {
  const m = g.mem || {};
  return {
    studious: (m.study || 0) >= 6 && (m.study || 0) >= (m.work || 0),
    worker: (m.work || 0) >= 4 && (m.work || 0) > (m.study || 0),
    tired: g.energy < 30,
    comeback: !!m.lastComeback,
    precise: (m.perfects || 0) >= 3,
  };
}

const SEC_AR = { analogy: "التناظر اللفظي", sentence: "إكمال الجمل", reading: "الاستيعاب", arithmetic: "الحساب والنسب", algebra: "الجبر", geometry: "الهندسة", comparison: "المقارنات", data: "تحليل البيانات", vocab: "المفردات" };

/* ═══════════════════════════════════════════════════════════
   🧠 ADAPTIVE BRAIN — اللعبة تراقب، تحلل، وتكيّف المحتوى
   ═══════════════════════════════════════════════════════════ */
const ALL_SECS = ["arithmetic", "algebra", "geometry", "comparison", "data", "analogy", "sentence", "reading", "vocab"];
const secStat = (g, s) => g.stats.bySec[s] || { a: 0, c: 0, t: 0, to: 0 };
const secAcc = (g, s) => { const v = secStat(g, s); return v.a ? Math.round((v.c / v.a) * 100) : null; };
const secAvgT = (g, s) => { const v = secStat(g, s); return v.a ? Math.round((v.t || 0) / v.a) : null; };

// مستوى الإتقان لكل قسم
function masteryOf(g, s) {
  const v = secStat(g, s);
  if (v.a < 4) return { lvl: 0, label: "جديد", e: "🌱" };
  const acc = (v.c / v.a) * 100;
  if (acc >= 85 && v.a >= 8) return { lvl: 3, label: "متقن", e: "🏆" };
  if (acc >= 70) return { lvl: 2, label: "متمكن", e: "💪" };
  if (acc >= 50) return { lvl: 1, label: "يتطور", e: "📈" };
  return { lvl: 0, label: "ركّز هنا", e: "🎯" };
}
// وزن ظهور القسم: الضعيف يظهر أكثر، المتقن يقل
function weightOf(g, s) {
  const v = secStat(g, s);
  if (v.a < 4) return 60;                       // قسم جديد: اعطه فرصة عادلة
  const acc = (v.c / v.a) * 100;
  return Math.max(8, Math.round(112 - acc));    // 40% دقة → وزن 72، 90% دقة → وزن 22
}
const weakestOf = (g, secs) => [...secs].sort((a, b) => weightOf(g, b) - weightOf(g, a))[0];

// نصائح مخصصة لكل قسم (تُدمج مع أرقام اللاعب الفعلية)
const TIP_FIX = {
  arithmetic: "خطأ النسب الأشهر: القسمة على القيمة الجديدة. القاعدة: نسبة التغيّر = الفرق ÷ (القديمة). وللرجوع لسعر قبل الخصم: اقسم على النسبة المتبقية، لا تجمع.",
  algebra: "اعزل x بعكس العملية خطوة خطوة، وتحقق بالتعويض قبل ما تضغط — 5 ثوانٍ تحقق توفر قلبًا كاملًا.",
  geometry: "احفظ الخمسة الذهبية: مثلث 180°، فيثاغورس وثلاثية (3,4,5)، مساحة الدائرة πr² ومحيطها 2πr، والمحيط = 2(طول+عرض). أغلب أخطائك من الخلط بين المساحة والمحيط.",
  comparison: "لا تحكم من أول نظرة. جرّب دائمًا: عدد كبير ← 1 ← 0 ← كسر بين 0 و1. إذا اختلفت النتيجة بين تجربتين فالجواب Cannot be determined فورًا.",
  data: "قبل أي رقم: اقرأ عنوان الجدول ووحدته. ونسبة التغير تُقسم على القيمة الأصلية دائمًا.",
  analogy: "كوّن جملة تربط الكلمتين قبل ما تشوف الخيارات (A hammer drives a nail)، ثم طبّقها حرفيًا على كل خيار — خيار واحد فقط ستنطبق عليه.",
  sentence: "أول شي حدد كلمة الإشارة: although/but = عكس الاتجاه، because/so = نفس الاتجاه. توقّع الكلمة بنفسك ثم احذف المخالف.",
  reading: "اقرأ السؤال قبل القطعة، وجاوب الفكرة الرئيسية بما يغطي القطعة كلها — الخيار اللي يذكر تفصيلة صحيحة لكن جزئية هو الفخ.",
  vocab: "اربط كل كلمة جديدة بصورة أو موقف (scarce = ماء الصحراء النادر). المراجعة بعد النوم مباشرة تثبّت ضعف ما تثبّته المذاكرة المتواصلة.",
};
const TIP_SPEED = {
  arithmetic: "درّب نفسك على حيلة الـ10%: حرّك الفاصلة ثم ركّب. الحساب الذهني السريع = وقت إضافي لباقي الأسئلة.",
  reading: "لا تترجم في راسك — اقرأ وافهم بالإنجليزي مباشرة. الترجمة الذهنية تلتهم نصف وقتك.",
  default: "إذا أخذ السؤال منك دقيقة: احذف خيارين وخمّن بذكاء وواصل — سؤال واحد لا يستحق طاقة معركة كاملة.",
};

// المدرب الذكي: يختار أهم ملاحظة بناء على البيانات الفعلية
function coachInsight(g) {
  const cand = [];
  ALL_SECS.forEach(s => {
    const v = secStat(g, s);
    if (v.a < 4) return;
    const acc = Math.round((v.c / v.a) * 100);
    const avg = Math.round((v.t || 0) / v.a);
    const name = SEC_AR[s] || s;
    if (acc < 55)
      cand.push({ p: 110 - acc, e: "🎯", h: `${name}: ${acc}% صح من ${v.a} محاولة`, d: `${TIP_FIX[s]} — رفعت ظهور ${name} في معاركك القادمة حتى تكسره.` });
    else if ((v.to || 0) >= 3)
      cand.push({ p: 65, e: "⏰", h: `${v.to} إجابات ضاعت بانتهاء الوقت في ${name}`, d: TIP_SPEED[s] || TIP_SPEED.default });
    else if (avg >= 50 && acc >= 60)
      cand.push({ p: 45, e: "🐢", h: `${name}: دقتك ${acc}% لكن متوسط حلّك ${avg} ثانية`, d: TIP_SPEED[s] || TIP_SPEED.default });
    else if (acc >= 85 && v.a >= 8)
      cand.push({ p: 25, e: "🏆", h: `أتقنت ${name} — ${acc}% عبر ${v.a} محاولة`, d: `خفّضت ظهوره ووجّهت أسئلتك نحو ${SEC_AR[weakestOf(g, ALL_SECS.filter(x => secStat(g, x).a > 0 && x !== s))] || "أقسام جديدة"}. الإتقان يُصان بالتنويع.` });
  });
  if (!cand.length) return null;
  return cand.sort((a, b) => b.p - a.p)[0];
}

const accOf = (g, secs) => { let a = 0, c = 0; secs.forEach(s => { const v = g.stats.bySec[s]; if (v) { a += v.a; c += v.c; } }); return a ? Math.round((c / a) * 100) : null; };

/* ---------- 📜 CHAPTERS: STORY + QUESTS ---------- */
const CH = [
  {
    id: 1, emoji: "🏫", title: "الفصل الأول: الثانوية", place: "حيّك — المملكة العربية السعودية",
    intro: [
      { who: "الراوي", e: "📖", t: "سنة التخرج. كل شيء في حياتك القادمة يمر من بوابة واحدة: اختبار القدرات." },
      { who: "أبوك", e: "👳", t: "يا وليدي، أنا أعرف قدك. أرامكو ما تاخذ إلا اللي يتعب... ورّني وش عندك." },
      { who: "سلطان (صديقك)", e: "😎", t: "تراهم يقولون اللي ياخذ 90+ يفتح له باب الابتعاث. أنا بذاكر معك... بس أول واحد ينهزم يعزم الثاني 🍔" },
    ],
    quests: [
      { id: "q1", type: "battle", name: "وحش الكسل", icon: "😴", desc: "أول ليلة مذاكرة. الكسل يجلس على كتفك — اطرده بالأرقام.", enemy: { hp: 3, secs: ["arithmetic"], time: 45, xp: 40, coins: 25 } },
      { id: "q2", type: "battle", name: "شبح النسيان", icon: "👻", desc: "القوانين تتبخر من راسك؟ ثبّتها بمعركة جبر.", enemy: { hp: 3, secs: ["algebra"], time: 45, xp: 40, coins: 25 } },
      { id: "q3", type: "battle", name: "متاهة الكلمات", icon: "🌀", desc: "بوابة المكتبة مقفلة بألغاز لفظية. كل إجابة تفك قفلًا.", enemy: { hp: 3, secs: ["analogy", "sentence"], time: 45, xp: 45, coins: 30 } },
      { id: "side1", type: "battle", side: true, repeat: true, name: "وردية الكشك 🕐", icon: "🏪", desc: "شغلة جانبية: حاسب الزبائن بسرعة واكسب عملات. (قابلة للتكرار)", enemy: { hp: 4, secs: ["arithmetic", "data"], time: 30, xp: 15, coins: 45 } },
    ],
    boss: { name: "الاختبار التجريبي", icon: "📝", desc: "بروفة القدرات في المدرسة. اهزمه لتثبت أنك جاهز للحقيقي.", hp: 5, secs: ["arithmetic", "algebra", "analogy", "sentence"], time: 40, xp: 90, coins: 60 },
    outro: [{ who: "المرشد الطلابي", e: "🧑‍🏫", t: "نتيجتك التجريبية ممتازة. سجلتك في اختبار القدرات الرسمي... الأسبوع الجاي. لا تخذل نفسك." }],
  },
  {
    id: 2, emoji: "🏛️", title: "الفصل الثاني: يوم الاختبار", place: "مقر قياس",
    intro: [
      { who: "الراوي", e: "📖", t: "قاعة صامتة. شاشة أمامك. قلبك يدق. هذا هو اليوم اللي تدربت له." },
      { who: "أنت", e: "😤", t: "كل سؤال جاوبته، كل قلب خسرته، كل كومبو... كان لأجل هذي اللحظة." },
    ],
    quests: [
      { id: "q1", type: "battle", name: "قهر التوتر", icon: "😰", desc: "قبل الدخول، توترك يهاجمك. اهزمه بأسئلة إحماء سريعة.", enemy: { hp: 3, secs: ["arithmetic", "geometry"], time: 35, xp: 40, coins: 20 } },
    ],
    boss: { name: "⚡ اختبار القدرات ⚡", icon: "🐉", desc: "المعركة الكبرى: 10 أسئلة من كل الأقسام. أداؤك هنا يحدد درجتك... ودرجتك تحدد مستقبلك.", hp: 10, secs: ["arithmetic", "algebra", "geometry", "comparison", "data", "analogy", "sentence", "reading"], time: 40, xp: 150, coins: 100, isGat: true },
    outro: [{ who: "الراوي", e: "📖", t: "أسبوعان من الانتظار... ثم وصلت الرسالة النصية: نتيجتك ظهرت." }],
  },
  {
    id: 3, emoji: "🎓", title: "الفصل الثالث: أبواب الجامعات", place: "منصة القبول الموحد",
    intro: [{ who: "الراوي", e: "📖", t: "درجتك صارت مفتاحًا. بعض الأبواب تنفتح لها... وبعضها يحتاج مفتاحًا أثقل." }],
    quests: [
      { id: "choice", type: "choice", name: "اختر جامعتك", icon: "🗝️", desc: "درجتك تحدد الأبواب المفتوحة." },
      { id: "q1", type: "battle", name: "مقابلة القبول", icon: "🎤", desc: "لجنة القبول تختبر لغتك. أثبت جدارتك.", enemy: { hp: 3, secs: ["sentence", "reading"], time: 45, xp: 50, coins: 30 } },
    ],
    boss: { name: "اختبار الابتعاث المبدئي", icon: "🛂", desc: "أرامكو تفرز المتقدمين. تجاوز الفرز لتحجز مقعدك في الطائرة.", hp: 5, secs: ["comparison", "algebra", "reading"], time: 40, xp: 100, coins: 70 },
    outro: [{ who: "أمك", e: "🤲", t: "دمعت عيونها وهي تودعك في المطار: الله يوفقك يا ضاوي... لا تنسانا من دعائك." }],
  },
  {
    id: 4, emoji: "🗽", title: "الفصل الرابع: أمريكا", place: "الولايات المتحدة — بيئة جديدة كليًا",
    usa: true,
    intro: [
      { who: "الراوي", e: "📖", t: "14 ساعة طيران. لغة ثانية. وجوه جديدة. برد ما تعرفه. أهلًا بك في الغربة." },
      { who: "Officer", e: "🛂", t: "Welcome to the United States. Purpose of your visit?" },
      { who: "أنت", e: "💼", t: "Scholarship student. Petroleum Engineering... إن شاء الله." },
    ],
    quests: [
      { id: "q1", type: "battle", name: "متاهة المطار", icon: "🛄", desc: "لافتات، إعلانات، اتجاهات — كلها بالإنجليزي. اقرأ صح توصل صح.", enemy: { hp: 3, secs: ["reading", "sentence"], time: 45, xp: 55, coins: 35 } },
      { id: "q2", type: "battle", name: "Roommate Jake", icon: "🧑‍🤝‍🧑", desc: "زميل سكنك يتكلم بسرعة صاروخ. افهمه وجاوبه لتكسب أول صديق.", enemy: { hp: 3, secs: ["analogy", "sentence"], time: 40, xp: 55, coins: 35 } },
      { id: "side1", type: "battle", side: true, repeat: true, name: "شفت المقهى ☕", icon: "🧋", desc: "شغل جزئي: احسب الفواتير والباقي بسرعة. (قابل للتكرار)", enemy: { hp: 4, secs: ["arithmetic", "data"], time: 28, xp: 15, coins: 50 } },
    ],
    boss: { name: "امتحان تحديد المستوى", icon: "🏛️", desc: "الجامعة تقرر: تبدأ مباشرة أم سنة تحضيرية؟ قرارها بيدك أنت.", hp: 6, secs: ["reading", "sentence", "algebra", "arithmetic"], time: 38, xp: 120, coins: 80 },
    outro: [{ who: "Prof. Johnson", e: "👨‍🏫", t: "Impressive placement. See you in class, Mr. Dhawi." }],
  },
  {
    id: 5, emoji: "📚", title: "الفصل الخامس: الحياة الجامعية", place: "الحرم الجامعي",
    usa: true,
    intro: [{ who: "الراوي", e: "📖", t: "محاضرات، مشاريع، ليالي سهر، وقهوة كثيرة. هنا يُصنع المهندسون." }],
    quests: [
      { id: "q1", type: "battle", name: "Midterm الرياضيات", icon: "📐", desc: "أول ميدترم. البروفيسور لا يرحم.", enemy: { hp: 4, secs: ["algebra", "geometry"], time: 40, xp: 60, coins: 40 } },
      { id: "q2", type: "battle", name: "مشروع الفريق", icon: "🧪", desc: "فريقك تأخر والتسليم غدًا. حلّل البيانات وأنقذ المشروع.", enemy: { hp: 4, secs: ["data", "comparison"], time: 40, xp: 60, coins: 40 } },
      { id: "q3", type: "battle", name: "نادي المناظرات", icon: "🗣️", desc: "مثّل الطلاب السعوديين في مناظرة الجامعة.", enemy: { hp: 3, secs: ["sentence", "reading"], time: 40, xp: 55, coins: 35 } },
    ],
    boss: { name: "أسبوع الفاينلات", icon: "🌪️", desc: "كل المواد في أسبوع واحد. أطول معركة في الرحلة — لا تنهار.", hp: 7, secs: ["arithmetic", "algebra", "geometry", "comparison", "data", "sentence", "reading"], time: 36, xp: 140, coins: 90 },
    outro: [{ who: "سلطان (مكالمة فيديو)", e: "📱", t: "يا بعد حيي! باقي لك سنة وتتخرج.. تراي محتفظ بفاتورة البرجر لا تنسى 🍔" }],
  },
  {
    id: 6, emoji: "🎓", title: "الفصل السادس: التخرج", place: "قاعة الاحتفالات الكبرى",
    usa: true,
    intro: [{ who: "الراوي", e: "📖", t: "أربع سنين اختصرتها اللحظة هذي: اسمك يُنادى على المسرح... لكن قبلها، آخر عقبة." }],
    quests: [
      { id: "q1", type: "battle", name: "مناقشة مشروع التخرج", icon: "🎤", desc: "لجنة من ثلاثة بروفيسورات. دافع عن مشروعك رقمًا رقمًا.", enemy: { hp: 4, secs: ["data", "comparison", "reading"], time: 38, xp: 70, coins: 45 } },
    ],
    boss: { name: "الاختبار الشامل النهائي", icon: "🏰", desc: "آخر بوابة قبل الشهادة. كل ما تعلمته في الرحلة... الآن.", hp: 7, secs: ["arithmetic", "algebra", "geometry", "comparison", "data", "analogy", "sentence", "reading"], time: 35, xp: 160, coins: 110 },
    outro: [{ who: "الراوي", e: "📖", t: "🎓 \"Dhawi... Bachelor of Engineering, with Honors.\" — تصفيق. دموع. ومكالمة لأهلك ما تُنسى." }],
  },
  {
    id: 7, emoji: "🛢️", title: "الفصل الأخير: طريق أرامكو", place: "الظهران — المملكة",
    intro: [
      { who: "الراوي", e: "📖", t: "رجعت للوطن بشهادة... لكن الحلم ما اكتمل بعد. برج أرامكو ينتظر." },
      { who: "م. خالد (التوظيف)", e: "🧑‍💼", t: "سيرتك قوية يا ضاوي. عندنا مقابلة فنية واختبار قبول. الأفضل فقط يعبرون." },
    ],
    quests: [
      { id: "q1", type: "battle", name: "المقابلة الفنية", icon: "🎙️", desc: "أسئلة سريعة بالإنجليزي أمام لجنة. كل تلعثم يحسب عليك.", enemy: { hp: 4, secs: ["sentence", "analogy", "reading"], time: 35, xp: 70, coins: 50 } },
    ],
    boss: { name: "👑 اختبار قبول أرامكو 👑", icon: "🏯", desc: "المعركة الأخيرة في الرحلة كلها. أصعب توقيت، أقوى أسئلة. أداؤك هنا + درجة قدراتك = نهايتك.", hp: 8, secs: ["arithmetic", "algebra", "geometry", "comparison", "data", "analogy", "sentence", "reading"], time: 30, xp: 200, coins: 150, isFinal: true },
    outro: [],
  },
];

const UNIS = [
  { name: "جامعة البترول والمعادن (KFUPM)", need: 90, e: "⛽" },
  { name: "جامعة الملك سعود", need: 85, e: "🏛️" },
  { name: "جامعة الملك عبدالعزيز", need: 80, e: "🌊" },
  { name: "جامعة إقليمية", need: 0, e: "🏫" },
];


/* ═══════════════════════════════════════════════════════════
   🌍 WORLD LAYER — عالم حر، وقت، شخصيات حية، أحداث
   ═══════════════════════════════════════════════════════════ */

const eraOf = (ch) => (ch <= 3 ? "sa" : ch <= 6 ? "us" : "sa2");
const SLOTS = ["🌅 الصباح", "☀️ الظهر", "🌆 المساء"];

const LOCS = {
  sa: [
    { id: "home", e: "🏠", name: "البيت" },
    { id: "library", e: "📚", name: "الأكاديمية" },
    { id: "school", e: "🏫", name: "المدرسة" },
    { id: "kiosk", e: "🏪", name: "الكشك" },
    { id: "qiyas", e: "🏛️", name: "مركز قياس", minCh: 2 },
  ],
  us: [
    { id: "dorm", e: "🛏️", name: "السكن الجامعي" },
    { id: "campus", e: "🎓", name: "الحرم الجامعي" },
    { id: "cafe", e: "☕", name: "المقهى" },
    { id: "airport", e: "🛫", name: "المطار", maxCh: 4 },
  ],
  sa2: [
    { id: "home2", e: "🏠", name: "بيت الأهل" },
    { id: "library", e: "📚", name: "الأكاديمية" },
    { id: "aramco", e: "🛢️", name: "برج أرامكو" },
  ],
};

// السماء تتغير مع الوقت والمكان
const SKY = {
  sa: ["linear-gradient(#FFE3B3,#FDF6E3)", "linear-gradient(#AEE1F9,#F4F6F3)", "linear-gradient(#F2A65A,#5B3A6E)"],
  us: ["linear-gradient(#C9D9F0,#EDF2F9)", "linear-gradient(#9CC3E8,#E8EEF5)", "linear-gradient(#31456E,#141F38)"],
  sa2: ["linear-gradient(#FFE3B3,#FDF6E3)", "linear-gradient(#AEE1F9,#F4F6F3)", "linear-gradient(#F2A65A,#5B3A6E)"],
};
const NIGHT = "linear-gradient(#0B1020,#1A1030)";

/* ---------- 🎲 أحداث الصباح العشوائية ---------- */
const EVENTS = [
  { id: "mom", e: "📞", t: "اتصال من أمك", d: "«اشتقنا لك يا وليدي… انتبه لنفسك.» — دعواتها شحنتك.", fx: (n) => { n.energy = Math.min(100, n.energy + 20); }, tag: "+20 طاقة" },
  { id: "fire", e: "🔥", t: "يوم حماس", d: "صحيت وأنت شعلة. كل XP اليوم مضاعف!", fx: (n) => { n.dayFlags.x2 = true; }, tag: "XP ×2 اليوم" },
  { id: "sale", e: "🏷️", t: "تخفيضات المتجر", d: "كل أدوات المعركة بنص السعر اليوم فقط.", fx: (n) => { n.dayFlags.sale = true; }, tag: "خصم 50%" },
  { id: "gift", e: "🎁", t: "هدية من سلطان", d: "«خذ هذي ولا تقول أحد» — حوّل لك مصروف.", fx: (n) => { n.coins += 35; }, tag: "+35 🪙" },
  { id: "bad", e: "😴", t: "نوم متقطع", d: "سهرت على جوالك… صحيت مكسّر.", fx: (n) => { n.energy = Math.max(20, n.energy - 20); }, tag: "−20 طاقة" },
  { id: "hint", e: "💡", t: "فكرة قبل الفطور", d: "خطرت لك طريقة حل ذكية. سجلتها.", fx: (n) => { n.items.hint++; }, tag: "+1 تلميح" },
];

/* ---------- 🗣️ الشخصيات الحية — تتذكر وتتفاعل ---------- */
function awlFlavor(g) {
  const learned = Object.keys(AWL_WORDS).filter(id => acadDone(g, id)).flatMap(id => AWL_WORDS[id]);
  return learned.length ? learned[Math.floor(Math.random() * learned.length)] : null;
}
function npcLines(id, g) {
  const lb = g.lastBattle, m = g.mem || {}, tr = traitsOf(g);
  const L = [];
  if (id === "dad") {
    if (m.lastComeback) L.push({ who: "أبوك", e: "👳", t: `سمعت إنك رجعت لـ"${m.lastComeback}" وكسرته بعد ما طرحك… هذا بالضبط اللي أعرفه فيك: ما تنكسر، تتأخر بس.` });
    else if (tr.tired) L.push({ who: "أبوك", e: "👳", t: "تعال… عيونك تعبانة يا وليدي. المذاكرة بعقل مرتاح تسوى ثلاث ليالي سهر. نم مبكر الليلة." });
    else if (tr.worker) L.push({ who: "أبوك", e: "👳", t: "الكشك زين والرزق حلال، بس لا يأكل مذاكرتك. إذا ضاق عليك المصروف… أنا موجود." });
    if ((g.gatScore || 0) >= 90) L.push({ who: "أبوك", e: "👳", t: `تسعين يا ${g.name}؟! والله إني فخور فيك… هذا اللي كنت أقوله لك.` });
    else if (lb && !lb.won) L.push({ who: "أبوك", e: "👳", t: "شفتك طالع من المعركة مكسور… اسمعني: اللي ينهزم ويرجع، هذا اللي يوصل." });
    else if (tr.studious) L.push({ who: "أبوك", e: "👳", t: `صرت أسمع اسمك بالمجلس… "ولد فلان ما يرفع راسه من الكتاب". كمّل يا بعد حيي.` });
    else if (g.streak >= 3) L.push({ who: "أبوك", e: "👳", t: `${g.streak} أيام ورا بعض وأنت مواصل… كذا يكون الرجال.` });
    else L.push({ who: "أبوك", e: "👳", t: "المذاكرة أول، والباقي يجي. تحتاج شي قول لي." });
  }
  if (id === "sultan") {
    if (m.gatImproved) L.push({ who: "سلطان", e: "😎", t: `لحظة لحظة… من ${m.gatImproved.from} إلى ${m.gatImproved.to}؟! يا وحش الإعادة 😤🔥 أنا اللي علمته ترا (أمزح، كله منك).` });
    else if (m.lastComeback && g.chapter <= 3) L.push({ who: "سلطان", e: "😎", t: `كل المدرسة تتكلم عن رجعتك لـ"${m.lastComeback}". قلت لهم: هذا ربعي وأنا أعرفه من زمان 😌` });
    if (g.chapter === 1) L.push({ who: "سلطان", e: "😎", t: tr.worker ? "يا شيخ خذ لك إجازة من الكشك… المعدل ما ينسحب من الكاشير 🍔" : lb?.won ? "سمعت إنك دمرت آخر معركة… خل نشوفك بالتجريبي" : "متوتر؟ عادي كلنا. المهم عزيمة البرجر قايمة على الخسران." });
    else if (g.chapter <= 3) L.push({ who: "سلطان", e: "😎", t: g.gatScore ? (g.gatScore >= 90 ? `${g.gatScore}؟ يا وحش!! أرامكو جات تجيك` : `درجتك ${g.gatScore}… قريبة. عيدها وارفعها، وأنا وياك`) : "خلصت قياس؟ طمني أول ما تطلع النتيجة!" });
    else L.push({ who: "سلطان (مكالمة)", e: "📱", t: tr.studious ? "يا مغترب! صرت تذاكر أكثر مني أنا بالسعودية… فاتورة البرجر لسا محفوظة 🍔" : "يا مغترب! أمريكا غيرتك؟ ترا فاتورة البرجر لسا محفوظة عندي 🍔" });
  }
  if (id === "jake") {
    if (tr.tired) L.push({ who: "Jake", e: "🧑‍🤝‍🧑", t: "Bro, you look wrecked. Sleep IS a study strategy — trust me, I learned the hard way." });
    else if (m.lastComeback) L.push({ who: "Jake", e: "🧑‍🤝‍🧑", t: `You went back and beat "${m.lastComeback}"? That's the comeback spirit, man. Respect.` });
    const fw = awlFlavor(g);
    if (fw) L.push({ who: "Jake", e: "🧑‍🤝‍🧑", t: `Word of the day from your flashcards: «${fw.w}» — ${fw.ar}. Drop it in an essay and profs will love you.` });
    if (g.chapter === 4) L.push({ who: "Jake", e: "🧑‍🤝‍🧑", t: lb?.won ? "Dude, you're crushing it! Placement test next — you got this." : "Rough day? Happens. Coffee, reset, try again tomorrow." });
    else L.push({ who: "Jake", e: "🧑‍🤝‍🧑", t: g.chapter >= 6 ? `Graduation soon, ${g.name}! Remember when you couldn't find gate B12? Look at you now.` : "Midterms week is brutal. Library at 8? I'll bring snacks." });
  }
  if (id === "prof") {
    if (tr.precise) L.push({ who: "Prof. Johnson", e: "👨‍🏫", t: `${m.perfects} flawless battles, ${g.name}. That level of precision is what separates engineers from students.` });
    else if (m.comeback["5:boss"]) L.push({ who: "Prof. Johnson", e: "👨‍🏫", t: "Your resilience after stumbling in finals week impressed me more than any grade could." });
    if (g.stats.answered && g.stats.correct / g.stats.answered >= 0.8) L.push({ who: "Prof. Johnson", e: "👨‍🏫", t: `Your accuracy is remarkable, ${g.name}. Top of the class material.` });
    else L.push({ who: "Prof. Johnson", e: "👨‍🏫", t: "Struggling is part of learning. Review your mistakes — they teach more than victories." });
    const pw = awlFlavor(g);
    if (pw) L.push({ who: "Prof. Johnson", e: "👨‍🏫", t: `Vocabulary shapes thought. Today's word: «${pw.w}» (${pw.ar}) — try using it in a sentence before we meet again.` });
  }
  if (id === "khaled") {
    if (phaseDone(g, "C")) L.push({ who: "م. خالد", e: "🧑‍💼", t: `شهادة CPC Preparation مكتملة في ملفك يا ${g.name}… قليلون يجون بهذا الاستعداد. الاختبار الأخير صار تحصيل حاصل.` });
    else if (g.chapter === 7) L.push({ who: "م. خالد", e: "🧑‍💼", t: "قبل ما تدخل اختبار القبول: برنامجنا يشترط إتمام تحضير CPC. الأكاديمية عندك في الحي — أكمله وارجع لي." });
    if (m.gatImproved) L.push({ who: "م. خالد", e: "🧑‍💼", t: `ملفك يحكي قصة: أعدت القدرات ورفعتها من ${m.gatImproved.from} إلى ${m.gatImproved.to}. نحن لا نوظف الكمال… نوظف من لا يستسلم.` });
    L.push({ who: "م. خالد", e: "🧑‍💼", t: (g.gatScore || 0) >= 90 ? `ملفك من الأقوى اللي شفتها يا ${g.name}. باقي عليك الاختبار الأخير… ولا أشك فيك.` : "المنافسة شرسة هالسنة. اللي يعبر الاختبار الأخير بجدارة، الوظيفة له." });
  }
  if (id === "mom") {
    if (tr.tired) L.push({ who: "أمك", e: "🤲", t: "وجهك شاحب يا قلبي… لا تذبح نفسك. ارتاح، وأنا أدعي لك بالتوفيق كل سجدة." });
    else L.push({ who: "أمك", e: "🤲", t: g.chapter >= 4 ? "يا قلب أمك… كل ليلة أدعي لك. كل زين؟ تاكل عدل؟" : "قم تعش يا ولدي، والمذاكرة لها بقية بكرة بإذن الله." });
  }
  return L.slice(0, 2);
}

/* ---------- 🏠 محتوى المباني حسب الفصل ---------- */
function locContent(locId, g) {
  const ch = g.chapter;
  const c = { npcs: [], quests: [], acts: [] };
  const CQ = (chId, qid) => {
    const chd = CH.find(x => x.id === chId);
    if (qid === "boss") return { chId, qid, isBoss: true, name: chd.boss.name, icon: chd.boss.icon, desc: chd.boss.desc, enemy: { hp: chd.boss.hp, secs: chd.boss.secs, time: chd.boss.time, xp: chd.boss.xp, coins: chd.boss.coins, isGat: chd.boss.isGat, isFinal: chd.boss.isFinal }, mainsDone: chd.quests.filter(q => !q.side).every(q => g.done[`${chId}:${q.id}`]) };
    const q = chd.quests.find(x => x.id === qid);
    return { chId, qid, name: q.name, icon: q.icon, desc: q.desc, enemy: q.enemy, side: q.side, repeat: q.repeat, type: q.type };
  };
  if (locId === "home") {
    c.npcs = ["dad", "mom"];
    if (ch === 1) c.quests.push(CQ(1, "q1"));
    if (ch === 3) { c.quests.push(CQ(3, "choice"), CQ(3, "q1"), CQ(3, "boss")); }
    c.acts.push("rest", "daily", "sleep");
  }
  if (locId === "school") {
    c.npcs = ["sultan"];
    if (ch === 1) c.quests.push(CQ(1, "q2"), CQ(1, "q3"), CQ(1, "boss"));
  }
  if (locId === "library") c.acts.push("academy");
  if (locId === "kiosk") c.quests.push(CQ(1, "side1"));
  if (locId === "qiyas") {
    if (ch === 2) c.quests.push(CQ(2, "q1"), CQ(2, "boss"));
    if (ch >= 3 && (g.gatScore || 0) < 90) c.acts.push("retake");
  }
  if (locId === "airport" && ch === 4) c.quests.push(CQ(4, "q1"));
  if (locId === "dorm") {
    c.npcs = ["jake"];
    if (ch === 4) c.quests.push(CQ(4, "q2"));
    c.acts.push("call", "rest", "daily", "sleep");
  }
  if (locId === "campus") {
    c.npcs = ["prof"];
    c.acts.push("academy");
    if (ch === 4) c.quests.push(CQ(4, "boss"));
    if (ch === 5) c.quests.push(CQ(5, "q1"), CQ(5, "q2"), CQ(5, "q3"), CQ(5, "boss"));
    if (ch === 6) c.quests.push(CQ(6, "q1"), CQ(6, "boss"));
  }
  if (locId === "cafe") c.quests.push(CQ(4, "side1"));
  if (locId === "home2") { c.npcs = ["dad", "mom", "sultan"]; c.acts.push("rest", "daily", "sleep"); }
  if (locId === "aramco") {
    c.npcs = ["khaled"];
    const q1 = CQ(7, "q1"), boss = CQ(7, "boss");
    if (!phaseDone(g, "C")) { boss.mainsDone = false; boss.desc = "🔒 التوظيف يشترط إنهاء CPC Preparation في الأكاديمية أولًا — هذا شرط أرامكو الحقيقي."; }
    c.quests.push(q1, boss);
  }
  return c;
}

/* ---------- 🎬 انتقالات سينمائية ---------- */
function Transition({ card, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, card.ms || 2100); return () => clearTimeout(t); }, []);
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 200, background: card.bg || "#0B0F14", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", animation: "fadein .5s ease", color: "#fff", textAlign: "center", padding: 20 }}>
      <div style={{ fontSize: 64, animation: "pop .6s ease" }}>{card.e}</div>
      <div style={{ fontSize: 24, fontWeight: 900, margin: "10px 0 4px", animation: "drop .7s ease" }}>{card.t}</div>
      {card.sub && <div style={{ fontSize: 14.5, opacity: .8, animation: "drop .9s ease", lineHeight: 1.9 }}>{card.sub}</div>}
    </div>
  );
}

/* ---------- 🚶 الشارع — تجوال حر ---------- */
function Street({ g, theme, night, pos, setPos, onEnter }) {
  const era = eraOf(g.chapter);
  const locs = LOCS[era].filter(l => (!l.minCh || g.chapter >= l.minCh) && (!l.maxCh || g.chapter <= l.maxCh));
  const [walking, setWalking] = useState(false);
  const av = AVATARS.find(a => a.id === g.avatar);
  const sky = night ? NIGHT : SKY[era][Math.min(g.slot, 2)];
  const w = 100 / locs.length;

  const go = (i, loc) => {
    if (walking) return;
    play("click");
    if (i === pos) { onEnter(loc); return; }
    play("step");
    setWalking(true); setPos(i);
    setTimeout(() => { setWalking(false); play("door"); onEnter(loc); }, 750);
  };

  return (
    <div style={{ borderRadius: 18, overflow: "hidden", border: `1px solid ${theme.line}`, marginBottom: 12 }}>
      <div style={{ background: sky, transition: "background 1.2s ease", padding: "22px 8px 0", position: "relative" }}>
        <div style={{ position: "absolute", top: 10, left: 14, fontSize: 22 }}>{night ? "🌙" : g.slot === 0 ? "🌅" : g.slot === 1 ? "☀️" : "🌆"}</div>
        {era === "us" && <div style={{ position: "absolute", top: 10, right: 14, fontSize: 18, opacity: .8 }}>🗽</div>}
        <div style={{ display: "flex" }}>
          {locs.map((l, i) => {
            const active = i === pos;
            return (
              <button key={l.id} onClick={() => go(i, l)}
                style={{ flex: 1, background: "none", border: "none", cursor: "pointer", fontFamily: "inherit", padding: "6px 2px 14px", textAlign: "center", filter: night ? "brightness(.65)" : "none" }}>
                <div style={{ fontSize: 42, transform: active ? "scale(1.12)" : "scale(1)", transition: "transform .3s" }}>{l.e}</div>
                <div style={{ fontSize: 11.5, fontWeight: 800, color: night ? "#cbd5e8" : "#3A3A3A", marginTop: 2, background: "rgba(255,255,255,.55)", borderRadius: 8, display: "inline-block", padding: "1px 7px" }}>{l.name}</div>
              </button>
            );
          })}
        </div>
        {/* الرصيف واللاعب */}
        <div style={{ height: 46, background: night ? "#1C1C28" : "#8A8A8A", position: "relative", borderTop: `4px dashed ${night ? "#3A3A55" : "#C9C9C9"}` }}>
          <div style={{ position: "absolute", bottom: 8, left: `calc(${pos * w}% + ${w / 2}% - 16px)`, transition: "left .75s ease-in-out", fontSize: 30, transform: walking ? "translateY(-2px)" : "none" }}>
            <span style={{ display: "inline-block", animation: walking ? "walkbob .3s infinite alternate" : "none" }}>{av.e}</span>
          </div>
        </div>
      </div>
      <div style={{ background: theme.card, padding: "8px 12px", fontSize: 12, color: theme.sub, textAlign: "center", fontWeight: 700 }}>
        {night ? "🌙 الليل هبط — ارجع البيت ونم لتبدأ يومًا جديدًا" : "اضغط مبنى للمشي إليه، واضغطه مرة ثانية للدخول"}
      </div>
    </div>
  );
}

/* ---------- 🚪 داخل المبنى ---------- */
function Interior({ g, theme, loc, night, canAct, onQuest, onAct, onTalk, close }) {
  const c = locContent(loc.id, g);
  return (
    <div style={{ animation: "drop .3s ease" }}>
      <button onClick={close} style={{ background: "none", border: "none", color: theme.text, fontWeight: 800, fontSize: 14, cursor: "pointer", fontFamily: "inherit", marginBottom: 8, opacity: .8 }}>→ اخرج للشارع</button>
      <div className="card" style={{ textAlign: "center" }}>
        <div style={{ fontSize: 44 }}>{loc.e}</div>
        <div style={{ fontWeight: 900, fontSize: 17 }}>{loc.name}</div>
      </div>

      {c.npcs.length > 0 && <>
        <div style={{ fontWeight: 900, fontSize: 13.5, color: "#C89235", margin: "6px 4px" }}>الموجودون هنا</div>
        <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
          {c.npcs.map(id => {
            const l = npcLines(id, g)[0];
            return (
              <button key={id} className="card" onClick={() => onTalk(npcLines(id, g))} style={{ flex: 1, textAlign: "center", fontFamily: "inherit", cursor: "pointer", margin: 0, color: theme.text }}>
                <div style={{ fontSize: 30 }}>{l.e}</div>
                <div style={{ fontWeight: 800, fontSize: 12.5, marginTop: 2 }}>{l.who.split(" (")[0]}</div>
                <div style={{ fontSize: 10.5, color: theme.sub }}>💬 تكلم</div>
              </button>
            );
          })}
        </div>
      </>}

      {c.quests.length > 0 && <div style={{ fontWeight: 900, fontSize: 13.5, color: "#C89235", margin: "6px 4px" }}>المهمات هنا</div>}
      {c.quests.map(q => {
        if (q.type === "choice") {
          const done = g.done[`${q.chId}:${q.qid}`];
          return (
            <button key={q.qid} className="card" disabled={done} onClick={() => !done && onAct("choice")}
              style={{ width: "100%", textAlign: "right", fontFamily: "inherit", cursor: done ? "default" : "pointer", display: "flex", gap: 12, alignItems: "center", opacity: done ? .55 : 1, color: theme.text }}>
              <div style={{ fontSize: 28 }}>{done ? "✅" : "💻"}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 900, fontSize: 14.5 }}>منصة القبول الجامعي</div>
                <div style={{ fontSize: 12.5, color: theme.sub, marginTop: 2 }}>{done ? `مقبول في: ${g.uni}` : "قدّم على الجامعات المتاحة لدرجتك"}</div>
              </div>
            </button>
          );
        }
        const done = g.done[`${q.chId}:${q.qid}`];
        const locked = q.isBoss && !q.mainsDone;
        const playable = canAct && !locked && (q.repeat || !done);
        return (
          <button key={q.qid} className="card" disabled={!playable}
            onClick={() => playable && onQuest(q)}
            style={{ width: "100%", textAlign: "right", fontFamily: "inherit", cursor: playable ? "pointer" : "default", display: "flex", gap: 12, alignItems: "center", opacity: (done && !q.repeat) || locked || !canAct ? .55 : 1, background: q.isBoss ? "#17251F" : theme.card, color: q.isBoss ? "#fff" : theme.text, border: q.isBoss ? "none" : `1px solid ${theme.line}` }}>
            <div style={{ fontSize: 30 }}>{done && !q.repeat ? (q.isBoss ? "🏆" : "✅") : locked ? "🔒" : q.icon}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 900, fontSize: 14.5 }}>{q.name} {q.side && <span style={{ fontSize: 10.5, background: "#C8923522", color: "#C89235", borderRadius: 6, padding: "1px 6px" }}>عمل 🪙</span>}{q.isBoss && !done && <span style={{ fontSize: 10.5, background: "#B3402F33", color: "#F0A090", borderRadius: 6, padding: "1px 6px", marginRight: 4 }}>زعيم</span>}</div>
              <div style={{ fontSize: 12, color: q.isBoss ? "rgba(255,255,255,.75)" : theme.sub, marginTop: 2, lineHeight: 1.6 }}>{locked ? "أنهِ مهمات الفصل الرئيسية أولًا" : q.desc}</div>
              <div style={{ fontSize: 11, fontWeight: 800, color: "#C89235", marginTop: 2 }}>⭐ {q.enemy.xp} XP • 🪙 {q.enemy.coins} • يستهلك: وقت + طاقة</div>
            </div>
          </button>
        );
      })}

      {c.acts.length > 0 && <div style={{ fontWeight: 900, fontSize: 13.5, color: "#C89235", margin: "6px 4px" }}>أنشطة</div>}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {c.acts.includes("academy") && <button className="card" onClick={() => onAct("academy")} style={{ margin: 0, fontFamily: "inherit", cursor: "pointer", textAlign: "center", color: theme.text, gridColumn: "1 / -1", border: "2px solid #7B5EA755" }}>
          <div style={{ fontSize: 26 }}>🎓</div><div style={{ fontWeight: 900, fontSize: 13 }}>ادخل قاعات الأكاديمية</div><div style={{ fontSize: 11, color: theme.sub }}>تعلّم من الصفر → الاحتراف • لا يستهلك وقتك اليومي</div></button>}
        {c.acts.includes("rest") && <button className="card" disabled={!canAct} onClick={() => canAct && onAct("rest")} style={{ margin: 0, fontFamily: "inherit", cursor: canAct ? "pointer" : "default", textAlign: "center", opacity: canAct ? 1 : .5, color: theme.text }}>
          <div style={{ fontSize: 26 }}>🛋️</div><div style={{ fontWeight: 900, fontSize: 13 }}>استراحة</div><div style={{ fontSize: 11, color: theme.sub }}>+40 طاقة • يستهلك وقت</div></button>}
        {c.acts.includes("call") && <button className="card" disabled={g.dayFlags?.called} onClick={() => !g.dayFlags?.called && onAct("call")} style={{ margin: 0, fontFamily: "inherit", cursor: g.dayFlags?.called ? "default" : "pointer", textAlign: "center", opacity: g.dayFlags?.called ? .5 : 1, color: theme.text }}>
          <div style={{ fontSize: 26 }}>📞</div><div style={{ fontWeight: 900, fontSize: 13 }}>اتصل بأهلك</div><div style={{ fontSize: 11, color: theme.sub }}>{g.dayFlags?.called ? "اتصلت اليوم ✓" : "+15 طاقة • مجاني"}</div></button>}
        {c.acts.includes("daily") && <button className="card" onClick={() => onAct("daily")} style={{ margin: 0, fontFamily: "inherit", cursor: "pointer", textAlign: "center", color: theme.text, border: g.dailyDate !== new Date().toDateString() ? "2px solid #C89235" : `1px solid ${theme.line}` }}>
          <div style={{ fontSize: 26, animation: g.dailyDate !== new Date().toDateString() ? "pulse 1.6s infinite" : "none" }}>🎁</div><div style={{ fontWeight: 900, fontSize: 13 }}>صندوق اليوم</div><div style={{ fontSize: 11, color: theme.sub }}>عملات + غرض</div></button>}
        {c.acts.includes("retake") && <button className="card" disabled={!canAct} onClick={() => canAct && onAct("retake")} style={{ margin: 0, fontFamily: "inherit", cursor: canAct ? "pointer" : "default", textAlign: "center", color: theme.text, opacity: canAct ? 1 : .5 }}>
          <div style={{ fontSize: 26 }}>🔁</div><div style={{ fontWeight: 900, fontSize: 13 }}>أعد اختبار القدرات</div><div style={{ fontSize: 11, color: theme.sub }}>{canAct ? `ارفع درجتك (${g.gatScore})` : "المركز مغلق ليلًا"}</div></button>}
        {c.acts.includes("sleep") && <button className="card" onClick={() => onAct("sleep")} style={{ margin: 0, fontFamily: "inherit", cursor: "pointer", textAlign: "center", color: theme.text, gridColumn: c.acts.length % 2 ? "auto" : "1 / -1" }}>
          <div style={{ fontSize: 26 }}>😴</div><div style={{ fontWeight: 900, fontSize: 13 }}>نَم — ابدأ يومًا جديدًا</div><div style={{ fontSize: 11, color: theme.sub }}>طاقة كاملة + حدث صباحي</div></button>}
      </div>
    </div>
  );
}




/* ═══════════════ 🎓 ACADEMY UI — التعلم داخل القصة ═══════════════ */

function Academy({ g, theme, onExit, onPlace, onFinishUnit, onSimDone, onReview, onOpenUnit, startReview }) {
  const [sub, setSub] = useState(() => (startReview ? "review" : null));
  const fresh = g.acad.placed === null && Object.keys(g.acad.units || {}).length === 0;
  const due = dueList(g);

  if (sub === "ask") return <AskTeacher g={g} theme={theme} onBack={() => setSub(null)} onBonus={(b) => onFinishUnit({ id: "__bonus", drills: null }, ACADEMY[0], { bonusOnly: b })} />;
  if (sub === "place") return <Placement theme={theme} onDone={(rec) => { onPlace(rec); setSub(null); }} onBack={() => setSub(null)} />;
  if (sub === "review") return <ReviewSession g={g} theme={theme} onFinish={onReview} onExit={() => setSub(null)} />;
  if (sub === "map") return <KnowledgeMap g={g} theme={theme} close={() => setSub(null)} onPick={({ u, ph }) => {
    const i = ACADEMY.findIndex(x => x.id === ph.id);
    const open = prereqMet(g, u.id) || i < (g.acad.placed ?? -1);
    setSub(open ? { unit: u, phase: ph } : { lock: u, phase: ph });
  }} />;
  if (sub && sub.lock) {
    const U = sub.lock;
    return (
      <div style={{ animation: "drop .3s ease" }}>
        <button onClick={() => setSub(null)} style={{ background: "none", border: "none", color: theme.text, fontWeight: 800, fontSize: 14, cursor: "pointer", fontFamily: "inherit", marginBottom: 8, opacity: .8 }}>→ رجوع</button>
        <div className="card" style={{ textAlign: "center" }}>
          <div style={{ fontSize: 40 }}>🔒</div>
          <div style={{ fontWeight: 900, fontSize: 16, margin: "6px 0" }}>{U.icon} {U.name}</div>
          <div style={{ fontSize: 13, color: theme.sub, lineHeight: 1.9 }}>هذا المفهوم يقف على أكتاف مفاهيم قبله — القفز فوقها يبني فهمًا مكسورًا.</div>
        </div>
        <div className="card">
          <div style={{ fontWeight: 900, fontSize: 13.5, marginBottom: 8 }}>متطلباته:</div>
          {(PREREQ[U.id] || []).map(pid => {
            const f = unitById(pid); const done = acadDone(g, pid);
            return <div key={pid} style={{ display: "flex", gap: 8, fontSize: 13.5, fontWeight: 800, marginBottom: 6 }}><span>{done ? "✅" : "⬜"}</span><span>{f.u.icon} {f.u.name}</span></div>;
          })}
        </div>
        {(() => { const miss = (PREREQ[U.id] || []).find(pid => !acadDone(g, pid)); const f = miss && unitById(miss); return f && (
          <button className="btn" style={{ width: "100%", padding: 12, marginBottom: 8 }} onClick={() => setSub({ unit: f.u, phase: f.ph })}>📖 تعلّم المتطلب الناقص: {f.u.name} ←</button>
        ); })()}
        <button className="btn ghost" style={{ width: "100%", padding: 11 }} onClick={() => setSub({ unit: U, phase: sub.phase, test: true })}>🔓 أعرفه أصلًا — اختبار الإتقان الصارم (3/3 بلا خطأ)</button>
      </div>
    );
  }
  if (sub && sub.unit) {
    const U = sub.unit, PH = sub.phase;
    if (U.sim) return <SimFlow g={g} theme={theme} unit={U} onDone={(res) => { onSimDone(U, PH, res); setSub(null); }} onBack={() => setSub(null)} />;
    return <LessonPlayer g={g} theme={theme} unit={U} test={sub.test} onOpen={() => onOpenUnit(U)} onDone={(fail) => { if (!fail) onFinishUnit(U, PH, { tested: !!sub.test }); setSub(null); }} onBack={() => setSub(null)} />;
  }

  const placedIdx = g.acad.placed ?? -1;
  const phaseOpen = (i) => i === 0 || i <= placedIdx || phaseDone(g, ACADEMY[i - 1].id);

  return (
    <div style={{ animation: "drop .3s ease" }}>
      <button onClick={onExit} style={{ background: "none", border: "none", color: theme.text, fontWeight: 800, fontSize: 14, cursor: "pointer", fontFamily: "inherit", marginBottom: 8, opacity: .8 }}>→ اخرج من الأكاديمية</button>
      <div className="card" style={{ textAlign: "center", background: "#17251F", color: "#fff", border: "none" }}>
        <div style={{ fontSize: 40 }}>📚</div>
        <div style={{ fontWeight: 900, fontSize: 17 }}>الأكاديمية</div>
        <div style={{ fontSize: 12.5, opacity: .85, marginTop: 4, lineHeight: 1.8 }}>رحلة كاملة: من لا شيء… إلى درجة عالية في القدرات. بدون أي مصدر خارجي.</div>
        <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 10 }}>
          <button className="btn ghost" style={{ padding: "8px 14px", fontSize: 12.5, color: "#fff", borderColor: "rgba(255,255,255,.35)" }} onClick={() => { play("click"); setSub("map"); }}>🗺️ خريطة المعرفة</button>
          <button className="btn gold" style={{ padding: "8px 14px", fontSize: 12.5 }} onClick={() => { play("click"); setSub("ask"); }}>💬 اسأل المعلم</button>
        </div>
      </div>
      <div className="card" style={{ display: "flex", gap: 10, alignItems: "center", padding: 11 }}>
        <TeacherFace size={38} />
        <div style={{ fontSize: 12.5, lineHeight: 1.7, color: theme.sub }}><b style={{ color: theme.text }}>المعلم حاضر دائمًا:</b> غلطت بأي تطبيق؟ زر «🧑‍🏫 لم أفهم» يفتح شرحًا متدرجًا، تلميحات، وسؤالًا مشابهًا حتى ترسخ.</div>
      </div>
      {due.length > 0 && (
        <button className="card" onClick={() => { play("click"); setSub("review"); }} style={{ width: "100%", textAlign: "right", fontFamily: "inherit", cursor: "pointer", display: "flex", alignItems: "center", gap: 12, border: "2px solid #7B5EA7", color: theme.text }}>
          <div style={{ fontSize: 30, animation: "pulse 1.8s infinite" }}>🧠</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 900, fontSize: 14.5 }}>مراجعة اليوم: {due.length} {due.length === 1 ? "مفهوم" : "مفاهيم"}</div>
            <div style={{ fontSize: 12, color: theme.sub, marginTop: 2 }}>حان موعدها بالضبط — 3 دقائق تحفظها لك حتى يوم الاختبار</div>
          </div>
          <div style={{ fontWeight: 900, color: "#7B5EA7", fontSize: 13 }}>ابدأ ←</div>
        </button>
      )}

      {fresh && (
        <div className="card" style={{ border: "2px solid #C89235" }}>
          <div style={{ fontWeight: 900, fontSize: 14.5, marginBottom: 6 }}>👋 أول مرة هنا — من وين نبدأ؟</div>
          <div style={{ fontSize: 13, color: theme.sub, lineHeight: 1.8, marginBottom: 10 }}>دقيقة واحدة تحدد مستواك، أو ابدأ من الصفر تمامًا — كلاهما طريق صحيح.</div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn gold" style={{ flex: 1, padding: 11, fontSize: 13.5 }} onClick={() => { play("click"); setSub("place"); }}>🧪 حدد مستواي</button>
            <button className="btn ghost" style={{ flex: 1, padding: 11, fontSize: 13.5 }} onClick={() => { play("click"); onPlace(0); }}>🧱 أبدأ من الصفر</button>
          </div>
        </div>
      )}

      {ACADEMY.map((ph, i) => {
        const open = phaseOpen(i);
        const prog = phaseProg(g, ph);
        const skipped = i < placedIdx && prog < 100;
        return (
          <div key={ph.id} className="card" style={{ opacity: open ? 1 : .55, border: prog === 100 ? `2px solid ${ph.color}` : `1px solid ${theme.line}` }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ fontSize: 30 }}>{prog === 100 ? "✅" : open ? ph.icon : "🔒"}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 900, fontSize: 14.5 }}>{ph.name}</div>
                <div style={{ fontSize: 12, color: theme.sub, marginTop: 2 }}>{open ? ph.desc : `أكمل ${ACADEMY[i - 1].name.split(":")[1]} أولًا`}{skipped ? " • 🟡 متجاوَز بالتشخيص — متاح للمراجعة" : ""}</div>
                <div style={{ background: theme.line, borderRadius: 99, height: 6, overflow: "hidden", marginTop: 6 }}>
                  <div style={{ width: `${prog}%`, height: "100%", background: ph.color, borderRadius: 99, transition: "width .5s" }} />
                </div>
              </div>
              <div style={{ fontSize: 12, fontWeight: 900, color: ph.color }}>{prog}%</div>
            </div>
            {open && (
              <div style={{ marginTop: 10, borderTop: `1px solid ${theme.line}`, paddingTop: 8 }}>
                {ph.units.map((u, ui) => {
                  const done = acadDone(g, u.id);
                  const uOpen = prereqMet(g, u.id) || i < placedIdx;
                  const st = nodeState(g, u.id, i);
                  return (
                    <button key={u.id} onClick={() => { play("click"); setSub(uOpen ? { unit: u, phase: ph } : { lock: u, phase: ph }); }}
                      style={{ display: "flex", width: "100%", alignItems: "center", gap: 10, background: "none", border: "none", padding: "8px 2px", cursor: uOpen ? "pointer" : "default", fontFamily: "inherit", color: theme.text, opacity: uOpen ? 1 : .45, textAlign: "right" }}>
                      <span style={{ fontSize: 20 }}>{done ? "✅" : uOpen ? u.icon : "🔒"}</span>
                      <span style={{ flex: 1, fontWeight: 800, fontSize: 13.5 }}>{u.name} <span style={{ fontSize: 10 }}>{st.e}</span></span>
                      <span style={{ fontSize: 11.5, color: ph.color, fontWeight: 900 }}>{done ? "مراجعة ↺" : !uOpen ? "🔓 اختبر" : u.sim ? "ابدأ 🎬" : "تعلّم ←"}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
      {g.acad.simBest && <div className="card" style={{ textAlign: "center", fontWeight: 900, fontSize: 13.5 }}>🎭 أفضل درجة محاكاة: <span style={{ color: "#C89235", fontSize: 17 }}>{g.acad.simBest.score}</span></div>}
    </div>
  );
}

/* ---------- 🧪 اختبار تحديد المستوى ---------- */
function Placement({ theme, onDone, onBack }) {
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [picked, setPicked] = useState(null);
  const [end, setEnd] = useState(false);
  const q = PLACEMENT[i];
  if (end) {
    const rec = score <= 1 ? 0 : score <= 3 ? 1 : 2;
    return (
      <div className="card" style={{ textAlign: "center", padding: 24, animation: "pop .4s ease" }}>
        <div style={{ fontSize: 46 }}>{["🧱", "🔨", "🧭"][rec]}</div>
        <div style={{ fontWeight: 900, fontSize: 16, margin: "8px 0" }}>نتيجتك: {score}/5</div>
        <div style={{ fontSize: 13.5, lineHeight: 1.9, color: theme.sub }}>نوصيك بالبدء من <b style={{ color: theme.text }}>{ACADEMY[rec].name}</b>{rec > 0 ? " — والمراحل الأسبق تظل متاحة للمراجعة متى شئت." : " — أساس متين يبني كل ما بعده."}</div>
        <button className="btn gold" style={{ width: "100%", marginTop: 14, padding: 12 }} onClick={() => onDone(rec)}>ابدأ رحلتي 🎓</button>
      </div>
    );
  }
  return (
    <div style={{ animation: "drop .3s ease" }}>
      <button onClick={onBack} style={{ background: "none", border: "none", color: theme.text, fontWeight: 800, fontSize: 14, cursor: "pointer", fontFamily: "inherit", marginBottom: 8, opacity: .8 }}>→ رجوع</button>
      <div className="card">
        <div style={{ fontSize: 12, fontWeight: 900, color: "#C89235", marginBottom: 8 }}>🧪 تحديد المستوى • {i + 1}/5 — لا توجد إجابة "غلط"، فقط خريطة</div>
        <div dir="ltr" style={{ textAlign: "left", fontSize: 15.5, fontWeight: 600, marginBottom: 12, lineHeight: 1.7 }}>{q.q}</div>
        {q.options.map((o, idx) => {
          let st = {};
          if (picked !== null) { if (idx === q.a) st = { borderColor: "#1F7A5C", background: "#1F7A5C22" }; else if (idx === picked) st = { borderColor: "#B3402F", background: "#B3402F22" }; }
          return <button key={idx} className="opt" style={st} onClick={() => {
            if (picked !== null) return;
            setPicked(idx); play(idx === q.a ? "correct" : "click");
            const ns = score + (idx === q.a ? 1 : 0);
            setTimeout(() => { setScore(ns); setPicked(null); if (i + 1 >= PLACEMENT.length) setEnd(true); else setI(i + 1); }, 650);
          }}>{String.fromCharCode(65 + idx)}. {o}</button>;
        })}
      </div>
    </div>
  );
}

/* ---------- 📖 مشغّل الدرس: بطاقات → تطبيق → إتقان ---------- */
function LessonPlayer({ g, theme, unit, onDone, onBack, test, onOpen }) {
  const [stage, setStage] = useState(test ? "drill" : "cards");
  const [teach, setTeach] = useState(false);
  useEffect(() => { if (!test && onOpen) onOpen(); }, []);
  const [ci, setCi] = useState(0);
  const [di, setDi] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [picked, setPicked] = useState(null);
  const [numVal, setNumVal] = useState("");
  const need = unit.need || Math.min(3, unit.drills?.length || 0);
  const drill = unit.drills?.[di % (unit.drills?.length || 1)];
  const review = acadDone(g, unit.id);

  const answer = (ok) => {
    if (test && !ok) { play("wrong"); setStage("fail"); return; }
    play(ok ? "correct" : "wrong");
    setPicked(ok ? "ok" : "no");
    if (ok) {
      const nc = correct + 1;
      setTimeout(() => {
        setCorrect(nc); setPicked(null); setNumVal("");
        if (nc >= need) setStage("pass"); else setDi(di + 1);
      }, 800);
    }
  };
  const nextAfterWrong = () => { setPicked(null); setNumVal(""); setDi(di + 1); };

  if (stage === "fail") return (
    <div className="card" style={{ textAlign: "center", padding: 24, animation: "pop .4s ease" }}>
      <div style={{ fontSize: 46 }}>🧱</div>
      <div style={{ fontWeight: 900, fontSize: 16, margin: "8px 0", color: "#B3402F" }}>الاختبار الصارم لا يسامح</div>
      <div style={{ fontSize: 13.5, color: theme.sub, lineHeight: 1.9 }}>خطأ واحد يعني أن الأساس يحتاج بناء فعليًا — وهذا خبر جيد: عرفناه قبل يوم الاختبار الحقيقي. ادرس متطلباته ثم ارجع.</div>
      <button className="btn" style={{ width: "100%", marginTop: 12, padding: 12 }} onClick={() => onDone(true)}>فهمت — ارجعني ←</button>
    </div>
  );
  if (stage === "pass") return (
    <div className="card" style={{ textAlign: "center", padding: 26, animation: "pop .45s ease", position: "relative", overflow: "hidden" }}>
      {["✨", "🎓", "⭐", "✨", "🌟"].map((c, i) => <span key={i} style={{ position: "absolute", bottom: 8, left: `${12 + i * 18}%`, fontSize: 18, animation: `confetti ${1 + i * .15}s ease forwards` }}>{c}</span>)}
      <div style={{ fontSize: 52 }}>🎓</div>
      <div style={{ fontWeight: 900, fontSize: 18, margin: "8px 0 4px", color: "#1F7A5C" }}>{test ? "🔓 اجتزت اختبار الإتقان!" : review ? "مراجعة مكتملة" : "أتقنت الدرس!"}</div>
      <div style={{ fontSize: 14, color: theme.sub }}>{unit.name}</div>
      <button className="btn gold" style={{ width: "100%", marginTop: 14, padding: 12 }} onClick={onDone}>{review ? "رجوع" : "استلم مكافأتك ←"}</button>
    </div>
  );

  return (
    <div style={{ animation: "drop .3s ease" }}>
      <button onClick={onBack} style={{ background: "none", border: "none", color: theme.text, fontWeight: 800, fontSize: 14, cursor: "pointer", fontFamily: "inherit", marginBottom: 8, opacity: .8 }}>→ رجوع للأكاديمية</button>

      {stage === "cards" && <>
        {unit.awl ? (() => { const w = unit.awl[ci]; return (
          <div className="card" style={{ minHeight: 200, textAlign: "center" }}>
            <div style={{ fontSize: 11.5, fontWeight: 900, color: "#2E7DA6", marginBottom: 10 }}>{unit.icon} كلمة {ci + 1}/{unit.awl.length}</div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10 }}>
              <div dir="ltr" style={{ fontSize: 30, fontWeight: 900, letterSpacing: .5 }}>{w.w}</div>
              <button onClick={() => { play("click"); say(w.w); }} style={{ border: "none", background: "#2E7DA61a", color: "#2E7DA6", borderRadius: 99, width: 40, height: 40, fontSize: 18, cursor: "pointer" }}>🔊</button>
            </div>
            <div style={{ fontSize: 17, fontWeight: 900, color: "#0F5147", margin: "6px 0 10px" }}>{w.ar}</div>
            <div dir="ltr" style={{ textAlign: "left", background: theme.line + "44", borderRadius: 12, padding: "10px 13px", fontSize: 14, lineHeight: 1.8, fontStyle: "italic" }}>“{w.ex}”</div>
            <div style={{ display: "flex", gap: 6, justifyContent: "center", flexWrap: "wrap", marginTop: 10 }}>
              <span style={{ background: "#1F7A5C18", color: "#1F7A5C", borderRadius: 8, padding: "3px 10px", fontSize: 12, fontWeight: 800 }} dir="ltr">≈ {w.syn}</span>
              {w.ant && <span style={{ background: "#B3402F14", color: "#B3402F", borderRadius: 8, padding: "3px 10px", fontSize: 12, fontWeight: 800 }} dir="ltr">≠ {w.ant}</span>}
            </div>
            <div dir="ltr" style={{ textAlign: "left", fontSize: 12.5, color: theme.sub, marginTop: 10, lineHeight: 1.7 }}>✍️ {w.bl.replace("_____", `[${w.w}]`)}</div>
          </div>
        ); })() : (
        <div className="card" style={{ minHeight: 180 }}>
          <div style={{ fontSize: 11.5, fontWeight: 900, color: "#C89235", marginBottom: 8 }}>{unit.icon} {unit.name} • مفهوم {ci + 1}/{unit.cards.length}</div>
          <div style={{ fontWeight: 900, fontSize: 16, marginBottom: 8 }}>{unit.cards[ci].h}</div>
          <div style={{ fontSize: 14.5, lineHeight: 2 }}>{unit.cards[ci].t}</div>
          {unit.cards[ci].ex && <div dir="ltr" style={{ textAlign: "left", background: "#1F7A5C18", border: "1.5px solid #1F7A5C44", borderRadius: 10, padding: "9px 12px", marginTop: 10, fontSize: 14, fontWeight: 800, color: theme.text, fontFamily: "Menlo, Consolas, monospace" }}>{unit.cards[ci].ex}</div>}
        </div>)}
        <div style={{ display: "flex", gap: 8 }}>
          {ci > 0 && <button className="btn ghost" style={{ flex: 1, padding: 12 }} onClick={() => { play("click"); setCi(ci - 1); }}>السابق</button>}
          <button className="btn" style={{ flex: 2, padding: 12 }} onClick={() => { play("click"); ci + 1 < unit.cards.length ? setCi(ci + 1) : setStage(unit.drills ? "drill" : "pass"); }}>
            {ci + 1 < unit.cards.length ? "فهمت — التالي ←" : unit.drills ? "✏️ طبّق اللي تعلمته" : "إنهاء"}
          </button>
        </div>
      </>}

      {stage === "drill" && drill && <>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8, padding: "0 4px" }}>
          <span style={{ fontSize: 12.5, fontWeight: 900, color: test ? "#B3402F" : "#C89235" }}>{test ? "🔓 اختبار صارم: 3/3 — أي خطأ ينهيه" : "✏️ تطبيق بلا خوف — الخطأ هنا معلّم، مو عقوبة"}</span>
          <span style={{ fontSize: 12.5, fontWeight: 900 }}>{"🟢".repeat(correct)}{"⚪".repeat(Math.max(0, need - correct))}</span>
        </div>
        <div className="card">
          <div dir="ltr" style={{ textAlign: "left", fontSize: 16, fontWeight: 700, marginBottom: 12, lineHeight: 1.7 }}>{drill.q}</div>
          {drill.kind === "num" ? <>
            <div dir="ltr" style={{ textAlign: "center", fontSize: 24, fontWeight: 900, letterSpacing: 3, background: theme.line + "55", borderRadius: 12, padding: "9px 0", marginBottom: 10, minHeight: 48, color: picked === "ok" ? "#1F7A5C" : picked === "no" ? "#B3402F" : theme.text }}>{numVal || "؟"}</div>
            {picked === null && <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 7 }}>
              {[1,2,3,4,5,6,7,8,9,"⌫",0,"✓"].map(k => (
                <button key={k} className="opt" style={{ textAlign: "center", fontSize: 17, fontWeight: 900, padding: "12px 0", margin: 0, background: k === "✓" ? "#0F5147" : undefined, color: k === "✓" ? "#fff" : undefined, opacity: k === "✓" && !numVal ? .45 : 1 }}
                  onClick={() => { play("click"); if (k === "⌫") setNumVal(v => v.slice(0, -1)); else if (k === "✓") { if (numVal) answer(parseInt(numVal, 10) === drill.a); } else if (numVal.length < 6) setNumVal(v => v + k); }}>{k}</button>
              ))}
            </div>}
          </> : drill.options.map((o, idx) => {
            let st = {};
            if (picked !== null) { if (idx === drill.a) st = { borderColor: "#1F7A5C", background: "#1F7A5C22", fontWeight: 700 }; else st = { opacity: .5 }; }
            return <button key={idx} className="opt" style={st} onClick={() => picked === null && answer(idx === drill.a)}>{String.fromCharCode(65 + idx)}. {o}</button>;
          })}
          {picked === "ok" && <div style={{ marginTop: 8, background: "#1F7A5C1d", borderRadius: 12, padding: "10px 13px", fontSize: 13.5, fontWeight: 800, color: "#1F7A5C" }}>✓ صحيح! {drill.ex}</div>}
          {picked === "no" && <div style={{ marginTop: 8 }}>
            <div style={{ background: "#B3402F14", border: "1.5px solid #B3402F33", borderRadius: 12, padding: "11px 13px", fontSize: 13.5, lineHeight: 1.9 }}>
              <b style={{ color: "#B3402F" }}>لا بأس — هذا سر الدرس:</b> {drill.ex}
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
              <button className="btn ghost" style={{ flex: 1, padding: 11, fontSize: 13 }} onClick={() => { play("click"); setTeach(true); }}>🧑‍🏫 لم أفهم</button>
              <button className="btn" style={{ flex: 2, padding: 11 }} onClick={nextAfterWrong}>فهمت — سؤال آخر ←</button>
            </div>
          </div>}
        </div>
      </>}
      {teach && drill && <Teacher g={g} theme={theme} q={{ ...drill, topic: unit.id.startsWith("f6") || unit.id.startsWith("f7") || unit.id === "s5" || unit.id === "s6" || unit.id === "f8" ? "sentence" : "arithmetic", ...drill }} picked={null} fallbackCard={unit.cards[0]} onClose={() => setTeach(false)} />}
    </div>
  );
}

/* ---------- 🎭 المحاكاة والتقرير التحليلي ---------- */
function SimFlow({ g, theme, unit, onDone, onBack }) {
  const [phase, setPhase] = useState("rules");   // rules | run | report
  const [qs] = useState(() => bankPick({ topics: Object.keys(TOPIC_META), n: unit.sim.n, diffs: unit.sim.hard ? [2, 3] : [1, 2, 3] }).filter(x => x.type === 'mcq').map(x => ({ ...x, sec: x.topic })));
  const [i, setI] = useState(0);
  const [log, setLog] = useState([]);
  const [flash, setFlash] = useState(null);
  const [timeLeft, setTimeLeft] = useState(unit.sim.time);
  const q = qs[i];

  useEffect(() => { if (phase === "run") setTimeLeft(unit.sim.time); }, [i, phase]);
  useEffect(() => {
    if (phase !== "run" || flash) return;
    const t = setInterval(() => setTimeLeft(x => x - 1), 1000);
    return () => clearInterval(t);
  }, [phase, i, flash]);
  useEffect(() => { if (phase === "run" && timeLeft <= 0 && !flash) submit(-1); }, [timeLeft]);

  const submit = (idx) => {
    const ok = idx === q.a;
    play(ok ? "correct" : "wrong");
    setFlash(ok ? "ok" : "no");
    const nl = [...log, { sec: q.sec, ok, t: unit.sim.time - Math.max(timeLeft, 0) }];
    setLog(nl);
    setTimeout(() => {
      setFlash(null);
      if (i + 1 >= qs.length) { setPhase("report"); play("win"); }
      else setI(i + 1);
    }, 550);
  };

  if (phase === "rules") return (
    <div style={{ animation: "drop .3s ease" }}>
      <button onClick={onBack} style={{ background: "none", border: "none", color: theme.text, fontWeight: 800, fontSize: 14, cursor: "pointer", fontFamily: "inherit", marginBottom: 8, opacity: .8 }}>→ رجوع</button>
      <div className="card" style={{ background: "#17251F", color: "#fff", border: "none", textAlign: "center", padding: 22 }}>
        <div style={{ fontSize: 48 }}>{unit.icon}</div>
        <div style={{ fontWeight: 900, fontSize: 17, margin: "6px 0" }}>{unit.name}</div>
        <div style={{ fontSize: 13.5, opacity: .9, lineHeight: 1.9 }}>{unit.cards[0].t}</div>
      </div>
      <button className="btn" style={{ width: "100%", padding: 14, fontSize: 16, background: "#B3402F" }} onClick={() => { play("boss"); setPhase("run"); }}>🎬 ابدأ — القاعة صامتة</button>
    </div>
  );

  if (phase === "report") {
    const correct = log.filter(x => x.ok).length;
    const acc = correct / log.length;
    const score = Math.min(100, Math.round(55 + acc * 45));
    const bySec = {};
    log.forEach(({ sec, ok }) => { bySec[sec] ||= { a: 0, c: 0 }; bySec[sec].a++; if (ok) bySec[sec].c++; });
    const rows = Object.entries(bySec).sort((a, b) => (a[1].c / a[1].a) - (b[1].c / b[1].a));
    const weak = rows.filter(([, v]) => v.c / v.a < 0.7).slice(0, 2);
    return (
      <div style={{ animation: "pop .4s ease" }}>
        <div className="card" style={{ textAlign: "center" }}>
          <div style={{ fontSize: 13, fontWeight: 900, color: theme.sub }}>📋 تقرير المحاكاة</div>
          <div style={{ fontSize: 42, fontWeight: 900, color: score >= 90 ? "#C89235" : "#0F5147", margin: "4px 0" }}>{score}</div>
          <div style={{ fontSize: 13, color: theme.sub }}>درجة تقديرية • {correct}/{log.length} صحيحة {unit.sim.hard && "• 🏅 وضع الصفوة"}</div>
        </div>
        <div className="card">
          <div style={{ fontWeight: 900, fontSize: 13.5, marginBottom: 8 }}>أداؤك حسب القسم في هذه الجلسة:</div>
          {rows.map(([sec, v]) => {
            const p = Math.round((v.c / v.a) * 100);
            return (
              <div key={sec} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7 }}>
                <span style={{ fontSize: 12, fontWeight: 800, minWidth: 96 }}>{SEC_AR[sec] || sec}</span>
                <div style={{ flex: 1, background: theme.line, borderRadius: 99, height: 8, overflow: "hidden" }}>
                  <div style={{ width: `${p}%`, height: "100%", borderRadius: 99, background: p >= 80 ? "#1F7A5C" : p >= 60 ? "#C89235" : "#B3402F" }} />
                </div>
                <span style={{ fontSize: 11.5, fontWeight: 900, minWidth: 34, textAlign: "left" }}>{p}%</span>
              </div>
            );
          })}
        </div>
        {weak.length > 0 && <div className="card" style={{ background: "#B3402F0d", borderColor: "#B3402F33" }}>
          <div style={{ fontWeight: 900, fontSize: 13.5, marginBottom: 6 }}>🦉 وصفة المدرب بعد هذه الجلسة:</div>
          {weak.map(([sec]) => <div key={sec} style={{ fontSize: 13, lineHeight: 1.9, marginBottom: 6 }}><b>{SEC_AR[sec]}:</b> {TIP_FIX[sec]}</div>)}
        </div>}
        <button className="btn gold" style={{ width: "100%", padding: 13 }} onClick={() => onDone({ score, acc, log })}>اعتمد النتيجة ←</button>
      </div>
    );
  }

  return (
    <div style={{ animation: "drop .25s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8, padding: "0 4px" }}>
        <span style={{ fontSize: 12.5, fontWeight: 900, color: theme.sub }}>🎭 محاكاة • {i + 1}/{qs.length}</span>
        <span className={timeLeft <= 5 ? "tpulse" : ""} style={{ fontWeight: 900, fontSize: 14, color: timeLeft <= 8 ? "#B3402F" : theme.text, direction: "ltr" }}>⏱ {Math.max(timeLeft, 0)}s</span>
      </div>
      <div style={{ background: theme.line, borderRadius: 99, height: 6, marginBottom: 10, overflow: "hidden" }}>
        <div style={{ width: `${(i / qs.length) * 100}%`, height: "100%", background: "#B3402F", borderRadius: 99, transition: "width .4s" }} />
      </div>
      <div className="card" style={{ animation: flash === "no" ? "shake .35s ease" : "none" }}>
        <div dir="ltr" style={{ textAlign: "left", fontSize: 15.5, fontWeight: 600, lineHeight: 1.75, marginBottom: 12, whiteSpace: "pre-line" }}>{q.q}</div>
        {q.options.map((o, idx) => (
          <button key={idx} className="opt" disabled={!!flash}
            style={flash && idx === q.a ? { borderColor: "#1F7A5C", background: "#1F7A5C22" } : {}}
            onClick={() => !flash && submit(idx)}>{String.fromCharCode(65 + idx)}. {o}</button>
        ))}
      </div>
    </div>
  );
}



/* ═══════════════════════════════════════════════════════════
   🧑‍🏫 المعلم — شرح ذكي متدرج + معلم AI يناسب مستواك
   ═══════════════════════════════════════════════════════════ */
/* ---------- 🏔️ شعار Arise ---------- */
function AriseLogo({ size = 90, color = "currentColor" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill={color} aria-label="Arise">
      <path d="M12 86 L44 16 L64 54 L55 54 L44 33 L27 86 Z" />
      <path d="M58 86 L70 86 L89 42 L79 40 Z" />
      <path d="M18 80 L70 32 L76 39 L25 86 Z" />
      <path d="M66 14 L93 21 L83 45 Z" />
    </svg>
  );
}

/* ---------- 🎨 نظام الأيقونات الأصلية ---------- */
const IC_PATHS = {
  coin: <><circle cx="12" cy="12" r="9" fill="#F0C560" stroke="#B8860B" strokeWidth="1.6"/><circle cx="12" cy="12" r="5.5" fill="none" stroke="#B8860B" strokeWidth="1.3"/><path d="M12 8.8v6.4M9.6 10.4h4.8" stroke="#8A6508" strokeWidth="1.5" strokeLinecap="round"/></>,
  heart: <path d="M12 20.5S4.5 15.8 2.6 12C.9 8.6 3 5.2 6.2 5.2c2 0 3.6 1.1 5.8 3.3 2.2-2.2 3.8-3.3 5.8-3.3 3.2 0 5.3 3.4 3.6 6.8-1.9 3.8-9.4 8.5-9.4 8.5z"/>,
  bolt2: <path d="M13 2 4.5 13.5h5.6L9 22l8.7-11.6h-5.6z" fill="#F0C560" stroke="#B8860B" strokeWidth="1"/>,
  battery: <><rect x="2.5" y="8" width="16" height="9" rx="2.4" fill="none" stroke="currentColor" strokeWidth="1.8"/><rect x="19.5" y="10.5" width="2.5" height="4" rx="1" fill="currentColor"/></>,
  skull: <><path d="M12 3c-4.6 0-7.6 3-7.6 7.2 0 2.5 1.2 4.2 2.6 5.2V19a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-3.6c1.4-1 2.6-2.7 2.6-5.2C19.6 6 16.6 3 12 3z" fill="#E8E6E0"/><circle cx="9" cy="11" r="1.9" fill="#17251F"/><circle cx="15" cy="11" r="1.9" fill="#17251F"/><path d="M10.5 17h3M12 14.3l-1 1.6h2z" stroke="#17251F" strokeWidth="1.2" fill="#17251F"/></>,
  brain: <path d="M9 3.5C6.8 3.5 5.4 5 5.3 6.8 3.8 7.3 3 8.6 3 10.1c0 1 .4 1.9 1.1 2.5-.4.6-.6 1.3-.6 2 0 2 1.6 3.5 3.6 3.6.4 1.6 1.8 2.6 3.4 2.6h1V3.5H9zM15 3.5c2.2 0 3.6 1.5 3.7 3.3 1.5.5 2.3 1.8 2.3 3.3 0 1-.4 1.9-1.1 2.5.4.6.6 1.3.6 2 0 2-1.6 3.5-3.6 3.6-.4 1.6-1.8 2.6-3.4 2.6h-1V3.5H15z" fill="#9B7EC8" stroke="#7B5EA7" strokeWidth="1"/>,
};
function Ico({ n, s = 16, c = "currentColor", style = {} }) {
  return <svg width={s} height={s} viewBox="0 0 24 24" fill={c} style={{ verticalAlign: "-2px", ...style }}>{IC_PATHS[n]}</svg>;
}

function TeacherFace({ size = 44 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48">
      <circle cx="24" cy="26" r="15" fill="#F1D3B0" />
      <path d="M9 24c0-10 6-16 15-16s15 6 15 16l-2 1c0-4-2-6-4-6H15c-2 0-4 2-4 6z" fill="#FDFDFB" stroke="#DDD6C8" strokeWidth="1"/>
      <path d="M7 23h34l-2 4H9z" fill="#C0392B"/>
      <circle cx="18" cy="27" r="4.4" fill="none" stroke="#17251F" strokeWidth="1.8"/>
      <circle cx="30" cy="27" r="4.4" fill="none" stroke="#17251F" strokeWidth="1.8"/>
      <path d="M22.4 27h3.2" stroke="#17251F" strokeWidth="1.8"/>
      <circle cx="18" cy="27" r="1.5" fill="#17251F"/><circle cx="30" cy="27" r="1.5" fill="#17251F"/>
      <path d="M19 35c2 2.2 8 2.2 10 0" stroke="#8A5A3B" strokeWidth="1.8" fill="none" strokeLinecap="round"/>
      <path d="M14 20c3-2 17-2 20 0" stroke="#D9C9B0" strokeWidth="1.4" fill="none"/>
    </svg>
  );
}

function AICheck({ theme, data, onBonus }) {
  const [picked, setPicked] = useState(null);
  if (!data?.check?.options) return null;
  const c = data.check;
  return (
    <div style={{ marginTop: 10, borderTop: `1px dashed ${theme.line}`, paddingTop: 10 }}>
      <div style={{ fontWeight: 900, fontSize: 12.5, color: "#7B5EA7", marginBottom: 6 }}>🧪 سؤال المعلم للتأكد:</div>
      <div dir="ltr" style={{ textAlign: "left", fontWeight: 700, fontSize: 14.5, marginBottom: 8, lineHeight: 1.7 }}>{c.q}</div>
      {c.options.map((o, i) => {
        let st = {};
        if (picked !== null) { if (i === c.a) st = { borderColor: "#1F7A5C", background: "#1F7A5C22" }; else if (i === picked) st = { borderColor: "#B3402F", background: "#B3402F22" }; }
        return <button key={i} className="opt" style={{ ...st, fontSize: 13.5, padding: "10px 12px" }} onClick={() => {
          if (picked !== null) return;
          setPicked(i); play(i === c.a ? "correct" : "wrong");
          if (i === c.a && onBonus) onBonus(10);
        }}>{String.fromCharCode(65 + i)}. {o}</button>;
      })}
      {picked !== null && <div style={{ fontSize: 13, lineHeight: 1.8, background: picked === c.a ? "#1F7A5C14" : "#B3402F10", borderRadius: 10, padding: "8px 11px" }}>
        <b style={{ color: picked === c.a ? "#1F7A5C" : "#B3402F" }}>{picked === c.a ? "✓ رسخت الفكرة" : "لسا شوي —"}</b> {c.ex}
      </div>}
    </div>
  );
}

async function askAI(prompt) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: "claude-sonnet-4-6", max_tokens: 1000, messages: [{ role: "user", content: prompt }] }),
  });
  const data = await res.json();
  const text = data.content.map(c => c.text || "").join("");
  return JSON.parse(text.replace(/```json|```/g, "").trim());
}

function Teacher({ g, theme, q, picked, fallbackCard, onClose, onBonus }) {
  const [tab, setTab] = useState("main");   // main | similar | ai
  const [hintN, setHintN] = useState(0);
  const [sq] = useState(() => bankSimilar(q));
  const [sPicked, setSPicked] = useState(null);
  const [ai, setAi] = useState(null);
  const [loading, setLoading] = useState(false);
  const wrongOpt = picked != null && q.options ? q.options[picked] : null;
  const trap = picked != null && q.traps ? q.traps[picked] : null;
  const level = masteryOf(g, q.topic || q.sec).label;

  const runAI = async () => {
    setLoading(true); setTab("ai");
    try {
      const j = await askAI(`أنت «المعلم» في لعبة تعليمية سعودية لاختبار القدرات (GAT English). مستوى الطالب في هذا الموضوع: «${level}». اشرح له هذا السؤال بأسلوب مختلف تمامًا وبسيط يناسب مستواه، بالعربية، مع مثال جديد محلول، ثم سؤال تحقق جديد.
السؤال: ${q.q}
الخيارات: ${(q.options || []).join(" | ")}
الإجابة الصحيحة: ${q.options ? q.options[q.a] : q.a}
${wrongOpt ? `الطالب اختار خطأً: ${wrongOpt}` : ""}
أجب فقط بـ JSON خام بلا أي أسوار: {"explain":"شرح عربي مبسط بأسلوب جديد (سطران إلى أربعة)","example":"مثال جديد محلول سطر أو سطران","check":{"q":"سؤال جديد بالإنجليزية بنفس المهارة","options":["أ","ب","ج","د"],"a":0,"ex":"شرح عربي قصير"}}`);
      setAi(j);
    } catch (e) { setAi({ err: true }); }
    setLoading(false);
  };

  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 195, background: "rgba(0,0,0,.55)", display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: theme.bg, color: theme.text, width: "min(100%,620px)", maxHeight: "88vh", overflowY: "auto", borderRadius: "22px 22px 0 0", padding: "14px 16px 28px", animation: "drop .3s ease" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
          <TeacherFace size={40} />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 900, fontSize: 15 }}>المعلم</div>
            <div style={{ fontSize: 11, color: theme.sub }}>ما ننتقل حتى تفهم — هذا شغلي</div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: theme.text }}>✕</button>
        </div>

        {tab === "main" && <>
          {wrongOpt != null && (
            <div className="card" style={{ borderColor: "#B3402F44", background: "#B3402F0a" }}>
              <div style={{ fontWeight: 900, fontSize: 13, color: "#B3402F", marginBottom: 4 }}>🔍 ليش أخطأت بالضبط:</div>
              <div style={{ fontSize: 13.5, lineHeight: 1.9 }}>{trap || `اخترت «${wrongOpt}» — والصحيح «${q.options[q.a]}». ${q.ex || ""}`}</div>
            </div>
          )}
          <div className="card">
            <div style={{ fontWeight: 900, fontSize: 13, color: "#0F5147", marginBottom: 8 }}>🪜 الحل خطوة بخطوة:</div>
            {(q.steps || [q.ex || (fallbackCard ? fallbackCard.t : "")]).map((s, i) => (
              <div key={i} style={{ display: "flex", gap: 8, marginBottom: 7 }}>
                <span style={{ minWidth: 22, height: 22, borderRadius: "50%", background: "#0F5147", color: "#fff", fontSize: 11.5, fontWeight: 900, display: "flex", alignItems: "center", justifyContent: "center" }}>{i + 1}</span>
                <span style={{ fontSize: 13.5, lineHeight: 1.8 }}>{s}</span>
              </div>
            ))}
            {q.alt && <div style={{ marginTop: 8, background: "#7B5EA714", border: "1.5px solid #7B5EA733", borderRadius: 10, padding: "9px 12px", fontSize: 13, lineHeight: 1.8 }}><b style={{ color: "#7B5EA7" }}>🔀 {q.alt}</b></div>}
          </div>
          {q.hints && hintN < q.hints.length && (
            <button className="btn ghost" style={{ width: "100%", padding: 10, marginBottom: 8, fontSize: 13.5 }} onClick={() => { play("click"); setHintN(hintN + 1); }}>💡 أعطني تلميحًا فقط ({hintN}/{q.hints.length})</button>
          )}
          {q.hints && q.hints.slice(0, hintN).map((h, i) => (
            <div key={i} className="card" style={{ padding: "9px 13px", fontSize: 13, borderColor: "#C8923544" }}>💡 {i + 1}: {h}</div>
          ))}
          <div style={{ display: "flex", gap: 8 }}>
            {sq && <button className="btn" style={{ flex: 1, padding: 11, fontSize: 13 }} onClick={() => { play("click"); setTab("similar"); }}>🧪 جرّبني بسؤال مشابه</button>}
            <button className="btn gold" style={{ flex: 1, padding: 11, fontSize: 13 }} onClick={runAI}>🤖 اشرح بأسلوب آخر</button>
          </div>
        </>}

        {tab === "similar" && sq && (
          <div className="card">
            <div style={{ fontWeight: 900, fontSize: 12.5, color: "#0F5147", marginBottom: 8 }}>🧪 نفس المهارة ({sq.skill}) — لو حليته، الفكرة رسخت:</div>
            <div dir="ltr" style={{ textAlign: "left", fontWeight: 700, fontSize: 15, marginBottom: 10, lineHeight: 1.7, whiteSpace: "pre-line" }}>{sq.q}</div>
            {sq.options.map((o, i) => {
              let st = {};
              if (sPicked !== null) { if (i === sq.a) st = { borderColor: "#1F7A5C", background: "#1F7A5C22" }; else if (i === sPicked) st = { borderColor: "#B3402F", background: "#B3402F22" }; }
              return <button key={i} className="opt" style={st} onClick={() => {
                if (sPicked !== null) return;
                setSPicked(i); play(i === sq.a ? "correct" : "wrong");
                if (i === sq.a && onBonus) onBonus(8);
              }}>{String.fromCharCode(65 + i)}. {o}</button>;
            })}
            {sPicked !== null && (
              <div style={{ fontSize: 13, lineHeight: 1.8, background: sPicked === sq.a ? "#1F7A5C14" : "#B3402F10", borderRadius: 10, padding: "9px 12px" }}>
                <b style={{ color: sPicked === sq.a ? "#1F7A5C" : "#B3402F" }}>{sPicked === sq.a ? "✓ رسخت! خذ مكافأتك" : "شوف الخطوات:"}</b> {sPicked === sq.a ? sq.ex : (sq.steps || [sq.ex]).join(" ← ")}
              </div>
            )}
            <button className="btn ghost" style={{ width: "100%", marginTop: 10, padding: 10, fontSize: 13 }} onClick={() => setTab("main")}>→ رجوع للشرح</button>
          </div>
        )}

        {tab === "ai" && (
          <div className="card">
            {loading && <div style={{ textAlign: "center", padding: 20 }}><div style={{ fontSize: 30, animation: "pulse 1s infinite" }}>🤖</div><div style={{ fontSize: 13, color: theme.sub, marginTop: 6 }}>المعلم يعيد صياغة الشرح على مستواك ({level})…</div></div>}
            {!loading && ai?.err && <div style={{ fontSize: 13.5, textAlign: "center", color: theme.sub }}>المعلم الذكي (AI) يعمل داخل تطبيق Claude فقط — أما الشرح المتدرج والتلميحات والسؤال المشابه فتعمل دائمًا، حتى بلا إنترنت. <button className="btn ghost" style={{ marginTop: 8, padding: "8px 14px", fontSize: 12.5 }} onClick={runAI}>حاول مرة أخرى</button></div>}
            {!loading && ai && !ai.err && <>
              <div style={{ fontWeight: 900, fontSize: 12.5, color: "#C89235", marginBottom: 6 }}>🤖 بأسلوب مختلف (مضبوط على مستواك: {level}):</div>
              <div style={{ fontSize: 14, lineHeight: 2 }}>{ai.explain}</div>
              {ai.example && <div dir="auto" style={{ background: "#1F7A5C14", borderRadius: 10, padding: "9px 12px", marginTop: 8, fontSize: 13.5, lineHeight: 1.8 }}>📝 {ai.example}</div>}
              <AICheck theme={theme} data={ai} onBonus={onBonus} />
            </>}
            <button className="btn ghost" style={{ width: "100%", marginTop: 10, padding: 10, fontSize: 13 }} onClick={() => setTab("main")}>→ رجوع للشرح المتدرج</button>
          </div>
        )}
      </div>
    </div>
  );
}


/* ---------- 💬 اسأل المعلم (سؤال حر) ---------- */
function AskTeacher({ g, theme, onBack, onBonus }) {
  const [txt, setTxt] = useState("");
  const [loading, setLoading] = useState(false);
  const [ans, setAns] = useState(null);
  const send = async () => {
    if (!txt.trim() || loading) return;
    setLoading(true); setAns(null); play("click");
    const weak = SEC_AR[weakestOf(g, Object.keys(TOPIC_META))] || "عام";
    try {
      const j = await askAI(`أنت «المعلم» داخل أكاديمية لعبة تعليمية سعودية تحضّر لاختبار القدرات بالإنجليزية. أضعف مواضيع الطالب حاليًا: ${weak}. أجب عن سؤاله التالي بالعربية ببساطة وود، بمثال محلول، ثم سؤال تحقق قصير.
سؤال الطالب: «${txt.trim()}»
أجب فقط بـ JSON خام: {"explain":"إجابة عربية واضحة (٣-٦ أسطر)","example":"مثال محلول","check":{"q":"سؤال تحقق","options":["أ","ب","ج","د"],"a":0,"ex":"شرح قصير"}}`);
      setAns(j);
    } catch (e) { setAns({ err: true }); }
    setLoading(false);
  };
  return (
    <div style={{ animation: "drop .3s ease" }}>
      <button onClick={onBack} style={{ background: "none", border: "none", color: theme.text, fontWeight: 800, fontSize: 14, cursor: "pointer", fontFamily: "inherit", marginBottom: 8, opacity: .8 }}>→ رجوع للأكاديمية</button>
      <div className="card" style={{ display: "flex", gap: 10, alignItems: "center" }}>
        <TeacherFace size={46} />
        <div style={{ fontSize: 13.5, lineHeight: 1.8 }}><b>اسألني أي شيء عن الدروس</b> — كسور، نسب، تناظر، أزمنة… أشرحه على مستواك بمثال وسؤال تحقق.</div>
      </div>
      <div className="card">
        <textarea value={txt} onChange={e => setTxt(e.target.value)} rows={3} placeholder="مثال: ليش نقسم على القيمة القديمة في نسبة التغيّر؟"
          style={{ width: "100%", border: `1.5px solid ${theme.line}`, borderRadius: 12, padding: "10px 12px", fontFamily: "inherit", fontSize: 14, resize: "none", background: "transparent", color: theme.text }} />
        <button className="btn gold" style={{ width: "100%", marginTop: 8, padding: 12, opacity: txt.trim() && !loading ? 1 : .5 }} onClick={send}>{loading ? "المعلم يفكر…" : "📨 اسأل المعلم"}</button>
      </div>
      {ans?.err && <div className="card" style={{ textAlign: "center", fontSize: 13.5, color: theme.sub }}>سؤال المعلم الحر يحتاج تشغيل Arise داخل Claude — بقية الأكاديمية تعمل كاملة أوفلاين.</div>}
      {ans && !ans.err && (
        <div className="card">
          <div style={{ fontSize: 14, lineHeight: 2 }}>{ans.explain}</div>
          {ans.example && <div dir="auto" style={{ background: "#1F7A5C14", borderRadius: 10, padding: "9px 12px", marginTop: 8, fontSize: 13.5, lineHeight: 1.8 }}>📝 {ans.example}</div>}
          <AICheck theme={theme} data={ans} onBonus={onBonus} />
        </div>
      )}
    </div>
  );
}

/* ---------- 🔁 جلسة المراجعة اليومية (تكرار متباعد) ---------- */
function ReviewSession({ g, theme, onFinish, onExit }) {
  const [items] = useState(() => dueList(g).sort(() => Math.random() - 0.5));
  const [i, setI] = useState(0);
  const [stage, setStage] = useState("q");        // q | reteach | q2 | done
  const [picked, setPicked] = useState(null);
  const [numVal, setNumVal] = useState("");
  const [results, setResults] = useState([]);
  const [dIdx] = useState(() => items.map(it => Math.floor(Math.random() * it.u.drills.length)));
  const it = items[i];
  if (!it && stage !== "done") return <div className="card" style={{ textAlign: "center" }}>لا مراجعات اليوم — ذاكرتك مثبتة ✓<button className="btn" style={{ marginTop: 10 }} onClick={onExit}>رجوع</button></div>;
  const drill = it ? it.u.drills[(dIdx[i] + (stage === "q2" ? 1 : 0)) % it.u.drills.length] : null;

  const record = (ok) => {
    if (stage === "q" && !ok) { play("wrong"); setPicked(null); setNumVal(""); setStage("reteach"); return; }
    play(ok ? "correct" : "wrong");
    const nr = [...results, { id: it.u.id, ok: stage === "q" }];
    setTimeout(() => {
      setResults(nr); setPicked(null); setNumVal("");
      if (i + 1 >= items.length) { setStage("done"); play("win"); onFinish(nr); }
      else { setI(i + 1); setStage("q"); }
    }, 750);
    setPicked(ok ? "ok" : "no");
  };

  if (stage === "done") {
    const kept = results.filter(r => r.ok).length;
    return (
      <div className="card" style={{ textAlign: "center", padding: 26, animation: "pop .4s ease" }}>
        <div style={{ fontSize: 50 }}>🧠</div>
        <div style={{ fontWeight: 900, fontSize: 18, margin: "8px 0" }}>مراجعة اليوم اكتملت</div>
        <div style={{ fontSize: 14, lineHeight: 2 }}>ثابت في ذاكرتك: <b style={{ color: "#1F7A5C" }}>{kept}</b> • رجع لخطة الغد: <b style={{ color: "#E58E26" }}>{results.length - kept}</b></div>
        <div style={{ fontSize: 12.5, color: theme.sub, marginTop: 6 }}>كل إجابة صحيحة تُبعد موعد المراجعة القادمة — هكذا تبقى المعلومة ليوم الاختبار.</div>
        <button className="btn gold" style={{ width: "100%", marginTop: 14, padding: 12 }} onClick={onExit}>ممتاز ←</button>
      </div>
    );
  }

  if (stage === "reteach") return (
    <div style={{ animation: "drop .3s ease" }}>
      <div className="card" style={{ border: "1.5px solid #E58E2666" }}>
        <div style={{ fontSize: 12, fontWeight: 900, color: "#E58E26", marginBottom: 8 }}>🔄 تنشيط سريع — {it.u.icon} {it.u.name}</div>
        <div style={{ fontWeight: 900, fontSize: 15, marginBottom: 6 }}>{it.u.cards[0].h}</div>
        <div style={{ fontSize: 14, lineHeight: 2 }}>{it.u.cards[0].t}</div>
        {it.u.cards[0].ex && <div dir="ltr" style={{ textAlign: "left", background: "#1F7A5C18", borderRadius: 10, padding: "8px 12px", marginTop: 8, fontSize: 13.5, fontWeight: 800, fontFamily: "Menlo, monospace" }}>{it.u.cards[0].ex}</div>}
      </div>
      <button className="btn" style={{ width: "100%", padding: 12 }} onClick={() => { play("click"); setStage("q2"); }}>تذكرت — جرّبني بسؤال تطبيقي ←</button>
    </div>
  );

  return (
    <div style={{ animation: "drop .25s ease" }}>
      <div style={{ display: "flex", justifyContent: "space-between", padding: "0 4px", marginBottom: 8 }}>
        <span style={{ fontSize: 12.5, fontWeight: 900, color: "#7B5EA7" }}>🔁 مراجعة {i + 1}/{items.length} — {it.u.icon} {it.u.name}</span>
        <button onClick={onExit} style={{ background: "none", border: "none", color: theme.sub, fontWeight: 800, fontSize: 12.5, cursor: "pointer", fontFamily: "inherit" }}>إيقاف مؤقت</button>
      </div>
      <div className="card">
        {stage === "q2" && <div style={{ fontSize: 11.5, fontWeight: 900, color: "#E58E26", marginBottom: 8 }}>سؤال التثبيت بعد التنشيط:</div>}
        <div dir="ltr" style={{ textAlign: "left", fontSize: 16, fontWeight: 700, marginBottom: 12, lineHeight: 1.7 }}>{drill.q}</div>
        {drill.kind === "num" ? <>
          <div dir="ltr" style={{ textAlign: "center", fontSize: 24, fontWeight: 900, letterSpacing: 3, background: theme.line + "55", borderRadius: 12, padding: "9px 0", marginBottom: 10, minHeight: 48, color: picked === "ok" ? "#1F7A5C" : picked === "no" ? "#B3402F" : theme.text }}>{numVal || "؟"}</div>
          {picked === null && <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 7 }}>
            {[1,2,3,4,5,6,7,8,9,"⌫",0,"✓"].map(k => (
              <button key={k} className="opt" style={{ textAlign: "center", fontSize: 17, fontWeight: 900, padding: "12px 0", margin: 0, background: k === "✓" ? "#0F5147" : undefined, color: k === "✓" ? "#fff" : undefined, opacity: k === "✓" && !numVal ? .45 : 1 }}
                onClick={() => { play("click"); if (k === "⌫") setNumVal(v => v.slice(0, -1)); else if (k === "✓") { if (numVal) record(parseInt(numVal, 10) === drill.a); } else if (numVal.length < 6) setNumVal(v => v + k); }}>{k}</button>
            ))}
          </div>}
        </> : drill.options.map((o, idx) => {
          let st = {};
          if (picked !== null) { if (idx === drill.a) st = { borderColor: "#1F7A5C", background: "#1F7A5C22" }; else st = { opacity: .5 }; }
          return <button key={idx} className="opt" style={st} onClick={() => picked === null && record(idx === drill.a)}>{String.fromCharCode(65 + idx)}. {o}</button>;
        })}
        {picked === "ok" && <div style={{ marginTop: 8, background: "#1F7A5C1d", borderRadius: 12, padding: "9px 12px", fontSize: 13, fontWeight: 800, color: "#1F7A5C" }}>✓ ثابتة! {drill.ex}</div>}
        {picked === "no" && <div style={{ marginTop: 8, background: "#B3402F14", borderRadius: 12, padding: "9px 12px", fontSize: 13, lineHeight: 1.8 }}><b style={{ color: "#B3402F" }}>القاعدة:</b> {drill.ex} — رجعت لخطة الغد.</div>}
      </div>
    </div>
  );
}

/* ---------- 🗺️ خريطة المعرفة ---------- */
function KnowledgeMap({ g, theme, onPick, close }) {
  return (
    <div onClick={close} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 60, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: theme.bg, color: theme.text, width: "min(100%,620px)", maxHeight: "86vh", overflowY: "auto", borderRadius: "22px 22px 0 0", padding: "16px 16px 30px", animation: "drop .3s ease" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
          <div style={{ fontWeight: 900, fontSize: 17 }}>🗺️ خريطة المعرفة</div>
          <button onClick={close} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: theme.text }}>✕</button>
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 12, fontSize: 10.5, fontWeight: 800 }}>
          {[["⚪", "لم يبدأ"], ["🔵", "يتعلمه"], ["🟢", "فهمه"], ["🟠", "يحتاج مراجعة"], ["🥇", "أتقنه"]].map(([e, l]) => (
            <span key={l} style={{ background: theme.line + "66", borderRadius: 8, padding: "3px 8px" }}>{e} {l}</span>
          ))}
        </div>
        {KNOW_TRACKS.map(tr => (
          <div key={tr.name} className="card" style={{ padding: 12 }}>
            <div style={{ fontWeight: 900, fontSize: 13, marginBottom: 8 }}>{tr.name}</div>
            <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 4 }}>
              {tr.ids.map((uid, i) => {
                const found = unitById(uid);
                const phIdx = ACADEMY.findIndex(p => p.id === found.ph.id);
                const st = nodeState(g, uid, phIdx);
                return (
                  <span key={uid + i} style={{ display: "flex", alignItems: "center", gap: 4 }}>
                    {i > 0 && <span style={{ color: theme.sub, fontWeight: 900 }}>←</span>}
                    <button onClick={() => onPick(found)} style={{ border: `1.5px solid ${st.c}`, background: st.c + "18", color: theme.text, borderRadius: 10, padding: "6px 9px", fontSize: 11.5, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" }}>
                      {st.e} {found.u.name.split(" ").slice(0, 2).join(" ")}
                    </button>
                  </span>
                );
              })}
            </div>
          </div>
        ))}
        <div style={{ fontSize: 11.5, color: theme.sub, textAlign: "center", lineHeight: 1.8 }}>القاعدة: لا مفهوم يُفتح قبل متطلباته — إلا باجتياز اختبار الإتقان الصارم 🔓</div>
      </div>
    </div>
  );
}

/* ---------- 🦉 المدرب الذكي ---------- */
function Coach({ tip, close }) {
  useEffect(() => { play("coin"); }, []);
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 190, background: "rgba(0,0,0,.45)", display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={close}>
      <div onClick={e => e.stopPropagation()} style={{ width: "min(96%,560px)", margin: "0 8px 14px", background: "#17251F", color: "#fff", borderRadius: 20, padding: "16px 16px 14px", animation: "drop .35s ease", border: "1.5px solid #C8923555", boxShadow: "0 -8px 40px rgba(0,0,0,.4)" }}>
        <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
          <div style={{ animation: "pulse 2.5s infinite" }}><TeacherFace size={46} /></div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11.5, fontWeight: 900, color: "#C89235", letterSpacing: .5 }}>المعلم • تحليل مبني على أدائك أنت</div>
            <div style={{ fontWeight: 900, fontSize: 15, margin: "4px 0 6px" }}>{tip.e} {tip.h}</div>
            <div style={{ fontSize: 13.5, lineHeight: 1.9, opacity: .92 }}>{tip.d}</div>
          </div>
        </div>
        <button className="btn gold" style={{ width: "100%", marginTop: 12, padding: 11 }} onClick={close}>فهمت — كمّل ⚔️</button>
      </div>
    </div>
  );
}


/* ---------- ⚔️ استعداد ما قبل الزعيم ---------- */
function BossPrep({ g, theme, q, onBegin, onBack }) {
  const maxH = (g.skills.includes("heart4") ? 4 : 3) - (g.energy < 30 ? 1 : 0);
  return (
    <div style={{ animation: "pop .4s ease" }}>
      <div className="card" style={{ background: "#17251F", color: "#fff", border: "none", textAlign: "center", padding: 22 }}>
        <div style={{ fontSize: 12, color: "#F0C560", fontWeight: 900, letterSpacing: 2 }}>— معركة زعيم —</div>
        <div style={{ fontSize: 56, margin: "6px 0", animation: "pulse 2s infinite" }}>{q.icon}</div>
        <div style={{ fontWeight: 900, fontSize: 18 }}>{q.name}</div>
        <div style={{ fontSize: 13, opacity: .85, marginTop: 6, lineHeight: 1.8 }}>{q.desc}</div>
        <div style={{ display: "flex", justifyContent: "center", gap: 14, marginTop: 12, fontSize: 12.5, fontWeight: 800 }}>
          <span>💀 HP {q.enemy.hp}</span><span>⏱ {q.enemy.time}ث/سؤال</span><span>⭐ {q.enemy.xp} XP</span>
        </div>
      </div>
      <div className="card">
        <div style={{ fontWeight: 900, fontSize: 13.5, marginBottom: 8 }}>عدّتك للمعركة:</div>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, fontWeight: 800, flexWrap: "wrap", gap: 6 }}>
          <span>{"❤️".repeat(Math.max(2, maxH))}{g.energy < 30 ? " (مرهق −1)" : ""}</span>
          <span>💡×{g.items.hint} 🧊×{g.items.freeze} 🧪×{g.items.potion}</span>
          <span>🔋 {g.energy}%</span>
        </div>
        {g.mode === "calm" && <div style={{ fontSize: 12, color: theme.sub, fontWeight: 800, marginTop: 8 }}>⏱ تنبيه: معارك الزعماء بمؤقت دائمًا — حتى في الوضع الهادئ. هذي هيبتهم.</div>}
        {g.energy < 30 && <div style={{ fontSize: 12, color: "#B3402F", fontWeight: 800, marginTop: 8 }}>⚠️ طاقتك منخفضة — الأفضل ترتاح أو تنام قبل الزعيم.</div>}
      </div>
      <button className="btn" style={{ width: "100%", padding: 14, fontSize: 16, background: "#B3402F" }} onClick={onBegin}>⚔️ ادخل المعركة</button>
      <button className="btn ghost" style={{ width: "100%", padding: 11, marginTop: 8 }} onClick={onBack}>لست جاهزًا بعد — رجوع</button>
    </div>
  );
}

/* ---------- 🎯 الهدف التالي + مركز المهمات ---------- */
const LOC_HINT = {
  1: { q1: "🏠 البيت", q2: "🏫 المدرسة", q3: "🏫 المدرسة", boss: "🏫 المدرسة" },
  2: { q1: "🏛️ مركز قياس", boss: "🏛️ مركز قياس" },
  3: { choice: "🏠 البيت (منصة القبول)", q1: "🏠 البيت", boss: "🏠 البيت" },
  4: { q1: "🛫 المطار", q2: "🛏️ السكن", boss: "🎓 الجامعة" },
  5: { q1: "🎓 الجامعة", q2: "🎓 الجامعة", q3: "🎓 الجامعة", boss: "🎓 الجامعة" },
  6: { q1: "🎓 الجامعة", boss: "🎓 الجامعة" },
  7: { q1: "🛢️ برج أرامكو", boss: "🛢️ برج أرامكو" },
};
function nextGoal(g) {
  const acadCount = Object.keys(g.acad?.units || {}).length;
  if (g.chapter === 1 && g.stats.battles === 0 && acadCount === 0)
    return { t: "🎓 ابدأ رحلة التعلم من الأكاديمية", sub: "حدد مستواك أو ابدأ من الصفر • 📍 📚 الأكاديمية", pct: 5, gold: true };
  const d = g.daily;
  if (d) for (const id of d.ids) {
    const def = DAILY_POOL.find(p => p.id === id);
    if (def && !d.claimed[id] && (d.prog[id] || 0) >= def.goal) return { t: "🎁 مكافأة جاهزة للاستلام!", sub: def.t + " — افتح 📋 المهمات", pct: 100, gold: true };
  }
  const ch = CH.find(c => c.id === g.chapter);
  const mains = ch.quests.filter(q => !q.side);
  const doneCount = mains.filter(q => g.done[`${ch.id}:${q.id}`]).length;
  const total = mains.length + 1;
  const nq = mains.find(q => !g.done[`${ch.id}:${q.id}`]);
  const hint = (qid) => LOC_HINT[ch.id]?.[qid] ? ` • 📍 ${LOC_HINT[ch.id][qid]}` : "";
  if (nq) return { t: `🎯 ${nq.type === "choice" ? "اختر جامعتك" : nq.name}`, sub: ch.title + hint(nq.id), pct: Math.round((doneCount / total) * 100) };
  if (!g.done[`${ch.id}:boss`]) return { t: `⚔️ الزعيم بانتظارك: ${ch.boss.name}`, sub: ch.title + hint("boss"), pct: Math.round((doneCount / total) * 100), boss: true };
  return { t: "🏆 الفصل مكتمل — واصل رحلتك", sub: ch.title, pct: 100 };
}

function TaskRow({ def, prog, claimed, onClaim, theme, weekly }) {
  const p = Math.min(def.goal, prog || 0);
  const done = p >= def.goal;
  return (
    <div style={{ marginBottom: 9 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
        <div style={{ fontSize: 12.5, fontWeight: 800, flex: 1 }}>{def.t}</div>
        {claimed ? <span style={{ fontSize: 11.5, color: "#1F7A5C", fontWeight: 900 }}>✓ مُستلمة</span> :
          done ? <button className="btn gold" style={{ padding: "5px 12px", fontSize: 12 }} onClick={onClaim}>استلم 🎁</button> :
            <span style={{ fontSize: 11.5, fontWeight: 900, color: theme.sub }}>{p}/{def.goal}</span>}
      </div>
      <div style={{ background: theme.line, borderRadius: 99, height: 6, overflow: "hidden", marginTop: 4 }}>
        <div style={{ width: `${(p / def.goal) * 100}%`, height: "100%", borderRadius: 99, background: claimed ? "#1F7A5C" : weekly ? "#7B5EA7" : "#C89235", transition: "width .4s" }} />
      </div>
    </div>
  );
}

function GoalTasks({ g, theme, claimTask, claimSeason, onReview }) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState("d");
  const goal = nextGoal(g);
  const d = g.daily, w = g.weekly, s = g.season;
  const readyCount = (d ? d.ids.filter(id => { const def = DAILY_POOL.find(p => p.id === id); return def && !d.claimed[id] && (d.prog[id] || 0) >= def.goal; }).length : 0)
    + (w ? w.ids.filter(id => { const def = WEEKLY_POOL.find(p => p.id === id); return def && !w.claimed[id] && (w.prog[id] || 0) >= def.goal; }).length : 0)
    + (s ? SEASON.tiers.filter((t, i) => s.pts >= t.p && !s.claimed.includes(i)).length : 0);
  return (
    <div className="card" style={{ padding: 12, border: goal.gold ? "2px solid #C89235" : `1px solid ${theme.line}` }}>
      {/* الهدف التالي */}
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 900, fontSize: 13.5, color: goal.boss ? "#B3402F" : theme.text }}>{goal.t}</div>
          <div style={{ fontSize: 11, color: theme.sub, marginTop: 2 }}>{goal.sub} • {goal.pct}%</div>
        </div>
        <button onClick={() => { play("click"); setOpen(!open); }} style={{ border: "none", background: "#C8923522", color: "#C89235", borderRadius: 10, padding: "7px 11px", fontWeight: 900, fontSize: 12.5, cursor: "pointer", fontFamily: "inherit", position: "relative" }}>
          📋 المهمات{readyCount > 0 && <span style={{ position: "absolute", top: -6, left: -6, background: "#B3402F", color: "#fff", borderRadius: 99, fontSize: 10, padding: "1px 6px", fontWeight: 900 }}>{readyCount}</span>}
        </button>
      </div>
      <div style={{ background: theme.line, borderRadius: 99, height: 7, overflow: "hidden", marginTop: 8 }}>
        <div style={{ width: `${goal.pct}%`, height: "100%", borderRadius: 99, background: "linear-gradient(90deg,#F0C560,#C89235)", transition: "width .5s" }} />
      </div>
      {dueList(g).length > 0 && (
        <button onClick={onReview} style={{ display: "flex", width: "100%", alignItems: "center", gap: 8, marginTop: 9, border: "1.5px solid #7B5EA755", background: "#7B5EA714", borderRadius: 11, padding: "8px 11px", cursor: "pointer", fontFamily: "inherit", color: theme.text }}>
          <Ico n="brain" s={19} />
          <span style={{ flex: 1, textAlign: "right", fontWeight: 800, fontSize: 12.5 }}>مراجعة اليوم: {dueList(g).length} — قبل ما تتبخر من الذاكرة</span>
          <span style={{ fontWeight: 900, fontSize: 12, color: "#7B5EA7" }}>3 دقائق ←</span>
        </button>
      )}

      {open && <div style={{ marginTop: 12, borderTop: `1px solid ${theme.line}`, paddingTop: 10 }}>
        <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
          {[["d", "☀️ اليوم"], ["w", "📅 الأسبوع"], ["s", "🏆 الموسم"]].map(([id, l]) => (
            <button key={id} onClick={() => setTab(id)} style={{ flex: 1, border: "none", borderRadius: 10, padding: "7px 0", fontWeight: 900, fontSize: 12.5, cursor: "pointer", fontFamily: "inherit", background: tab === id ? "#0F5147" : theme.line + "66", color: tab === id ? "#fff" : theme.text }}>{l}</button>
          ))}
        </div>
        {tab === "d" && d && d.ids.map(id => { const def = DAILY_POOL.find(p => p.id === id); return def && <TaskRow key={id} def={def} prog={d.prog[id]} claimed={d.claimed[id]} onClaim={() => claimTask("d", id)} theme={theme} />; })}
        {tab === "d" && <div style={{ fontSize: 11, color: theme.sub, textAlign: "center" }}>تتجدد تلقائيًا كل يوم • كل مهمة = +15 نقطة موسم</div>}
        {tab === "w" && w && w.ids.map(id => { const def = WEEKLY_POOL.find(p => p.id === id); return def && <TaskRow key={id} def={def} prog={w.prog[id]} claimed={w.claimed[id]} onClaim={() => claimTask("w", id)} theme={theme} weekly />; })}
        {tab === "w" && <div style={{ fontSize: 11, color: theme.sub, textAlign: "center" }}>تتجدد كل أسبوع • كل مهمة = +40 نقطة موسم</div>}
        {tab === "s" && s && <>
          <div style={{ fontWeight: 900, fontSize: 12.5, marginBottom: 6 }}>{SEASON.name} — <span style={{ color: "#C89235" }}>{s.pts} نقطة</span></div>
          {SEASON.tiers.map((t, i) => {
            const reached = s.pts >= t.p, claimed = s.claimed.includes(i);
            return (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <div style={{ fontSize: 20, filter: reached ? "none" : "grayscale(1)", opacity: reached ? 1 : .5 }}>{t.e}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 12, fontWeight: 800 }}>{t.t} <span style={{ color: theme.sub }}>({t.p} نقطة)</span></div>
                  <div style={{ background: theme.line, borderRadius: 99, height: 5, overflow: "hidden", marginTop: 3 }}>
                    <div style={{ width: `${Math.min(100, (s.pts / t.p) * 100)}%`, height: "100%", background: "#7B5EA7", borderRadius: 99 }} />
                  </div>
                </div>
                {claimed ? <span style={{ fontSize: 11, color: "#1F7A5C", fontWeight: 900 }}>✓</span> :
                  reached ? <button className="btn gold" style={{ padding: "5px 11px", fontSize: 11.5 }} onClick={() => claimSeason(i)}>استلم</button> :
                    <span style={{ fontSize: 11, color: theme.sub, fontWeight: 800 }}>🔒</span>}
              </div>
            );
          })}
          <div style={{ fontSize: 11, color: theme.sub, textAlign: "center" }}>النقاط من: المعارك (+10) • الزعماء (+25) • المهام اليومية (+15) والأسبوعية (+40)</div>
        </>}
      </div>}
    </div>
  );
}


/* ---------- 🏢 Road to Aramco ---------- */
function roadMilestones(g) {
  const p = (id) => phaseProg(g, ACADEMY.find(x => x.id === id));
  const M = [
    { icon: "🧱", name: "Foundation", desc: "أساسيات الرياضيات والإنجليزية", pct: Math.round((p("F") + p("S")) / 2), done: phaseDone(g, "F") && phaseDone(g, "S"), go: "acad" },
    { icon: "🎓", name: "Academic English (AWL)", desc: `${Object.values(AWL_WORDS).reduce((a,w)=>a+w.length,0)} كلمة أكاديمية — معنى ونطق واستخدام`, pct: p("A"), done: phaseDone(g, "A"), go: "acad" },
    { icon: "🧭", name: "GAT English", desc: "استراتيجيات + محاكاة + دخول اختبار القدرات", pct: Math.round((p("Q") + p("P") + (g.gatScore ? 100 : 0)) / 3), done: phaseDone(g, "Q") && phaseDone(g, "P") && !!g.gatScore, go: "acad" },
    { icon: "🏭", name: "CPC Preparation", desc: "سرعة ذهنية، منطق، وقراءة بنمط أرامكو", pct: p("C"), done: phaseDone(g, "C"), go: "acad" },
    { icon: "🏯", name: "Aramco Assessment", desc: "اختبار القبول — المعركة الأخيرة في القصة", pct: g.done["7:boss"] ? 100 : Math.round((g.chapter / 7) * 100), done: !!g.done["7:boss"], go: "world" },
    { icon: "🪪", name: "Job Offer", desc: "عرض العمل — النهاية الأسطورية", pct: g.ending === "legend" ? 100 : g.ending ? 50 : 0, done: g.ending === "legend", go: "world" },
  ];
  let unlocked = 0;
  M.forEach((m, i) => { m.locked = i > 0 && !M[i - 1].done; if (!m.locked) unlocked = i; });
  return { M, current: M.findIndex(m => !m.done && !m.locked) };
}
function RoadPanel({ g, theme, close, goAcad }) {
  const { M, current } = roadMilestones(g);
  const total = Math.round(M.reduce((a, m) => a + m.pct, 0) / 6);
  return (
    <div onClick={close} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 55, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: theme.bg, color: theme.text, width: "min(100%,620px)", maxHeight: "86vh", overflowY: "auto", borderRadius: "22px 22px 0 0", padding: "16px 16px 30px", animation: "drop .3s ease" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
          <div style={{ fontWeight: 900, fontSize: 17 }}>🏢 Road to Aramco</div>
          <button onClick={close} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: theme.text }}>✕</button>
        </div>
        <div style={{ fontSize: 12.5, color: theme.sub, marginBottom: 10 }}>كل لعبة تلعبها = خطوة حقيقية نحو القبول • إجمالي الرحلة: <b style={{ color: "#C89235" }}>{total}%</b></div>
        {M.map((m, i) => (
          <div key={m.name} style={{ display: "flex", gap: 12 }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 36 }}>
              <div style={{ width: 36, height: 36, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17, fontWeight: 900,
                background: m.done ? "#1F7A5C" : i === current ? "#C89235" : theme.card, color: m.done || i === current ? "#fff" : theme.sub,
                border: `2px solid ${m.done ? "#1F7A5C" : i === current ? "#C89235" : theme.line}`, animation: i === current ? "pulse 2s infinite" : "none" }}>
                {m.done ? "✓" : m.locked ? "🔒" : m.icon}
              </div>
              {i < M.length - 1 && <div style={{ width: 3, flex: 1, minHeight: 22, background: m.done ? "#1F7A5C" : theme.line, borderRadius: 2 }} />}
            </div>
            <div className="card" style={{ flex: 1, opacity: m.locked ? .5 : 1 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                <div>
                  <div style={{ fontWeight: 900, fontSize: 14 }} dir="ltr">{m.icon} {m.name}</div>
                  <div style={{ fontSize: 12, color: theme.sub, marginTop: 2 }}>{m.locked ? "أتقن المرحلة السابقة لفتحها" : m.desc}</div>
                </div>
                {!m.locked && !m.done && i === current && <button className="btn gold" style={{ padding: "7px 12px", fontSize: 12 }} onClick={() => { close(); if (m.go === "acad") goAcad(); }}>{m.go === "acad" ? "الأكاديمية ←" : "العالم ←"}</button>}
              </div>
              <div style={{ background: theme.line, borderRadius: 99, height: 7, overflow: "hidden", marginTop: 8 }}>
                <div style={{ width: `${m.pct}%`, height: "100%", borderRadius: 99, background: m.done ? "#1F7A5C" : "linear-gradient(90deg,#F0C560,#C89235)", transition: "width .5s" }} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- 📔 سجل الرحلة ---------- */
function Journal({ g, theme, close }) {
  const [tab, setTab] = useState("tl");
  const col = COLLECT.map(c => ({ ...c, got: c.cond(g) }));
  const gotN = col.filter(c => c.got).length;
  const tline = [...(g.timeline || [])].sort((a, b) => a.day - b.day);
  return (
    <div onClick={close} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 50, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: theme.bg, color: theme.text, width: "min(100%,620px)", maxHeight: "84vh", overflowY: "auto", borderRadius: "22px 22px 0 0", padding: "16px 16px 30px", animation: "drop .3s ease" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <div style={{ fontWeight: 900, fontSize: 17 }}>📔 رحلة {g.name}</div>
          <button onClick={close} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: theme.text }}>✕</button>
        </div>
        <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
          {[["tl", "📖 يومياتي"], ["col", `🎒 المقتنيات ${gotN}/${col.length}`]].map(([id, l]) => (
            <button key={id} onClick={() => setTab(id)} style={{ flex: 1, border: "none", borderRadius: 10, padding: "8px 0", fontWeight: 900, fontSize: 13, cursor: "pointer", fontFamily: "inherit", background: tab === id ? "#0F5147" : theme.line + "66", color: tab === id ? "#fff" : theme.text }}>{l}</button>
          ))}
        </div>

        {tab === "tl" && <>
          <div className="card" style={{ textAlign: "center", fontSize: 12.5, fontWeight: 800, color: theme.sub }}>
            من طالب ثانوي 🎒 إلى {g.ending === "legend" ? "مهندس أرامكو 👑" : titleOf(g.xp).name + " " + titleOf(g.xp).icon} — اليوم {g.day} من الرحلة
          </div>
          {tline.length === 0 && <div className="card" style={{ textAlign: "center", color: theme.sub, fontSize: 13 }}>هنا يُكتب دفتر يومياتك… كل لحظة كبيرة تعيشها تتحول لسطر يُروى.</div>}
          {tline.map((x, i) => (
            <div key={x.k} style={{ display: "flex", gap: 12 }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 30 }}>
                <div style={{ width: 30, height: 30, borderRadius: "50%", background: "#0F5147", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15 }}>{x.e}</div>
                {i < tline.length - 1 && <div style={{ width: 3, flex: 1, minHeight: 18, background: theme.line, borderRadius: 2 }} />}
              </div>
              <div className="card" style={{ flex: 1, padding: "10px 13px" }}>
                <div style={{ fontWeight: 900, fontSize: 13.5 }}>{x.t}</div>
                {x.b && <div style={{ fontSize: 12, color: theme.sub, marginTop: 4, lineHeight: 1.8, fontStyle: "italic" }}>"{x.b}"</div>}
                <div style={{ fontSize: 11, color: theme.sub, marginTop: 3 }}>📅 اليوم {x.day}</div>
              </div>
            </div>
          ))}
          {/* محطات قادمة */}
          {CH.filter(c => c.id > g.chapter || (c.id === g.chapter && !g.done[`${c.id}:boss`])).slice(0, 2).map(c => (
            <div key={c.id} style={{ display: "flex", gap: 12, opacity: .45 }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 30 }}>
                <div style={{ width: 30, height: 30, borderRadius: "50%", background: theme.line, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15 }}>🔮</div>
              </div>
              <div className="card" style={{ flex: 1, padding: "10px 13px" }}>
                <div style={{ fontWeight: 900, fontSize: 13.5 }}>؟؟؟ — {c.title}</div>
                <div style={{ fontSize: 11, color: theme.sub, marginTop: 2 }}>بانتظارك…</div>
              </div>
            </div>
          ))}
        </>}

        {tab === "col" && <>
          <div style={{ background: theme.line, borderRadius: 99, height: 8, overflow: "hidden", marginBottom: 10 }}>
            <div style={{ width: `${(gotN / col.length) * 100}%`, height: "100%", background: "linear-gradient(90deg,#F0C560,#C89235)", borderRadius: 99 }} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
            {col.map(c => (
              <div key={c.id} className="card" style={{ textAlign: "center", margin: 0, padding: "12px 6px", opacity: c.got ? 1 : .45, border: c.got ? "1.5px solid #C89235" : `1px solid ${theme.line}` }}>
                <div style={{ fontSize: 28, filter: c.got ? "none" : "grayscale(1) blur(1px)" }}>{c.e}</div>
                <div style={{ fontWeight: 900, fontSize: 11, marginTop: 4, lineHeight: 1.5 }}>{c.got ? c.n : "؟؟؟"}</div>
                <div style={{ fontSize: 9.5, color: theme.sub, marginTop: 2, lineHeight: 1.5 }}>{c.got ? "✓ في حوزتك" : c.h}</div>
              </div>
            ))}
          </div>
        </>}
      </div>
    </div>
  );
}

/* ═══════════════ 🎮 GAME APP v2 — عالم حي بنظام يوم ═══════════════ */

const SAVE_VER = 1;
const newSave = () => ({
  v: SAVE_VER,
  started: false, name: "ضاوي", avatar: "a1", owned: ["a1"], mode: "calm",
  chapter: 1, done: {}, seen: {},
  day: 1, slot: 0, energy: 100, dayFlags: {}, lastBattle: null,
  xp: 0, coins: 60, skills: [], items: { hint: 1, freeze: 0, potion: 0 },
  streak: 0, lastDay: "", dailyDate: "",
  ach: [], gatScore: null, uni: null, finalAcc: null, ending: null,
  stats: { answered: 0, correct: 0, bySec: {}, battles: 0, bestCombo: 0 },
  daily: null, weekly: null, season: null, history: [], timeline: [], coachN: 0,
  acad: { units: {}, placed: null, simBest: null, opened: {} },
  srs: {},
  mem: { study: 0, work: 0, rest: 0, perfects: 0, lost: {}, comeback: {}, gatFirst: null, gatImproved: null, lastComeback: null },
});



class Guard extends (typeof React !== "undefined" ? React.Component : Object) {
  constructor(p) { super(p); this.state = { err: false }; }
  static getDerivedStateFromError() { return { err: true }; }
  render() {
    if (this.state.err) return (
      <div dir="rtl" style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: "Tahoma", background: "#F4F6F3", padding: 20, textAlign: "center" }}>
        <div style={{ fontSize: 54 }}>🛠️</div>
        <div style={{ fontWeight: 900, fontSize: 18, margin: "10px 0" }}>صار خلل غير متوقع</div>
        <div style={{ fontSize: 14, color: "#5A6A62", lineHeight: 1.9 }}>حفظ Arise بأمان تام. اضغط الزر وترجع لرحلتك من نفس النقطة.</div>
        <button onClick={() => this.setState({ err: false })} style={{ marginTop: 16, border: "none", background: "#0F5147", color: "#fff", padding: "12px 26px", borderRadius: 12, fontSize: 15, fontWeight: 800, fontFamily: "inherit", cursor: "pointer" }}>↩️ ارجع للعبة</button>
      </div>
    );
    return this.props.children;
  }
}
import React from "react";

export default function AppRoot() { return <Guard><App /></Guard>; }

function App() {
  const [g, setG] = useState(newSave());
  const [view, setView] = useState({ s: "title" });
  const [panel, setPanel] = useState(null);
  const [trans, setTrans] = useState(null);       // بطاقة سينمائية
  const [coach, setCoach] = useState(null);       // 🦉 المدرب الذكي
  const [toasts, setToasts] = useState([]);
  const [musicMode, setMusicMode] = useState("off");
  const [sound, setSound] = useState(true);
  const loaded = useRef(false);

  useEffect(() => {
    (async () => {
      try {
        let r = await store.get(SAVE_KEY);
        if (!r?.value) r = await store.get("qq-save");   // ترحيل حفظات ما قبل Arise
        if (r?.value) setG({ ...newSave(), ...JSON.parse(r.value) });
      } catch (e) {}
      setG(prev => { const n = JSON.parse(JSON.stringify(prev)); ensurePeriods(n); return n; });
      loaded.current = true;
    })();
    return () => stopMusic();
  }, []);
  useEffect(() => {
    if (!loaded.current) return;
    (async () => { try { await store.set(SAVE_KEY, JSON.stringify(g)); } catch (e) {} })();
  }, [g]);
  useEffect(() => { soundOn = sound; }, [sound]);
  useEffect(() => { if (musicMode !== "off") startMusic(musicMode); else stopMusic(); }, [musicMode]);

  const toast = (msg) => {
    const id = Date.now() + Math.random();
    setToasts(t => [...t, { id, msg }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 2800);
  };
  const mut = (fn) => setG(prev => { const n = JSON.parse(JSON.stringify(prev)); fn(n); return n; });

  const grant = (n, achId) => {
    if (achId && !n.ach.includes(achId)) {
      n.ach.push(achId);
      const a = ACHV.find(x => x.id === achId);
      toast(`🏅 إنجاز: ${a.name}`); play("coin");
    }
  };

  const addRewards = (n, xp, coins) => {
    const beforeLvl = lvlOf(n.xp);
    if (n.dayFlags?.x2) xp *= 2;
    if (n.energy >= 80) xp = Math.round(xp * 1.1);
    n.xp += xp;
    n.coins += Math.round(coins * (n.skills.includes("gold") ? 1.5 : 1));
    if (n.coins >= 500) grant(n, "rich");
    const afterLvl = lvlOf(n.xp);
    if (afterLvl > beforeLvl) {
      let bonus = 0, chest = false;
      for (let L = beforeLvl + 1; L <= afterLvl; L++) {
        bonus += 20 * L;
        if (L === 2) tl(n, "lv2", "⬆️", "أول ترقية مستوى", "أول مرة تشوف الشريط الذهبي يكتمل. من هنا بدأ الإدمان الجميل.");
        if (L % 5 === 0) { chest = true; n.items.hint++; n.items.freeze++; n.items.potion++; tl(n, "lv" + L, "🏵️", `وصلت المستوى ${L} — صندوق كبير`); }
      }
      n.coins += bonus;
      toast(`⬆️ مستوى ${afterLvl}! +${bonus}🪙 +نقطة مهارة`);
      if (chest) setTimeout(() => toast("🎁 صندوق المستوى الكبير: +💡+🧊+🧪"), 600);
      play("levelup");
    }
    const today = new Date().toDateString();
    if (n.lastDay !== today) {
      const diff = n.lastDay ? (new Date(today) - new Date(n.lastDay)) / 864e5 : 99;
      n.streak = diff === 1 ? n.streak + 1 : 1;
      n.lastDay = today;
      if (n.streak >= 3) grant(n, "streak3");
    }
  };

  const spSpent = g.skills.reduce((a, id) => a + (SKILLS.find(s => s.id === id)?.cost || 0), 0);
  const spFree = Math.max(0, lvlOf(g.xp) - 1 - spSpent);
  const night = g.slot >= 3;

  /* ---- الوقت والطاقة ---- */
  const spendSlot = (energyCost) => mut(n => {
    n.slot = Math.min(3, n.slot + 1);
    n.energy = Math.min(100, Math.max(0, n.energy - energyCost));
  });

  const doSleep = () => {
    play("door");
    const ev = Math.random() < 0.75 ? EVENTS[Math.floor(Math.random() * EVENTS.length)] : null;
    setTrans({ e: "🌙", t: `نهاية اليوم ${g.day}`, sub: "…تغفو والأحلام مليانة معادلات وكلمات إنجليزية…", bg: "#0B1020", ms: 2000 });
    mut(n => {
      ensurePeriods(n);
      n.history.push({ day: n.day, q: accOf(n, Q_SECS), v: accOf(n, V_SECS) });
      if (n.history.length > 40) n.history.shift();
      n.day += 1; n.slot = 0; n.energy = 100; n.dayFlags = {};
      ensurePeriods(n);
      if (ev) { ev.fx(n); n.dayFlags.morningEvent = ev.id; }
    });
    setTimeout(() => {
      if (ev) setTrans({ e: ev.e, t: ev.t, sub: `${ev.d}  (${ev.tag})`, bg: "#14263B", ms: 2600 });
    }, 2050);
    setTimeout(() => {
      setG(cur => { const dn = dueList(cur).length; if (dn > 0) toast(`🧠 خطة اليوم: ${dn} ${dn === 1 ? "مراجعة" : "مراجعات"} بانتظارك بالأكاديمية`); return cur; });
    }, ev ? 4800 : 2200);
  };

  /* ---- نهاية معركة (نفس منطق v1 كاملًا) ---- */
  const onBattleEnd = (res) => {
    let tip = null;
    mut(n => {
      res.answered.forEach(({ sec, ok, t, to }) => {
        n.stats.answered++; if (ok) n.stats.correct++;
        n.stats.bySec[sec] ||= { a: 0, c: 0, t: 0, to: 0 };
        const v = n.stats.bySec[sec];
        v.a++; if (ok) v.c++; v.t = (v.t || 0) + (t || 0); if (to) v.to = (v.to || 0) + 1;
      });
      n.stats.bestCombo = Math.max(n.stats.bestCombo, res.bestCombo);
      n.lastBattle = { won: res.won, boss: res.isBoss };
      /* 🪞 ذاكرة السلوك */
      n.mem ||= { study: 0, work: 0, rest: 0, perfects: 0, lost: {}, comeback: {}, gatFirst: null, gatImproved: null, lastComeback: null };
      const bkey = `${res.chId}:${res.questId}`;
      const bname = res.isBoss ? CH.find(c => c.id === res.chId).boss.name : (CH.find(c => c.id === res.chId).quests.find(q => q.id === res.questId)?.name || "المعركة");
      if (String(res.questId).startsWith("side")) n.mem.work++; else n.mem.study++;
      if (!res.won) n.mem.lost[bkey] = (n.mem.lost[bkey] || 0) + 1;
      if (res.won && (n.mem.lost[bkey] || 0) > 0 && !n.mem.comeback[bkey]) {
        n.mem.comeback[bkey] = true; n.mem.lastComeback = bname;
        tl(n, "cb" + bkey, "🔁", `العودة الكبرى: هزمت "${bname}"`, `طرحك ${n.mem.lost[bkey]} ${n.mem.lost[bkey] === 1 ? "مرة" : "مرات"}… ثم رجعت وأنهيت القصة. الناس بدأت تلاحظ أنك لا تستسلم.`);
        toast(`🔁 عودة الأبطال! الجميع سيتذكر هذا`);
      }
      if (res.won && res.acc === 1 && res.answered.length >= 3) {
        n.mem.perfects++;
        if (n.mem.perfects === 1) tl(n, "perf1", "💎", "أول معركة مثالية", "صفر أخطاء. حتى أنت ما صدقت الشاشة أول ثانية.");
      }
      n.coachN = (n.coachN || 0) + 1;
      const ins = coachInsight(n);
      if (ins && (ins.p >= 60 || n.coachN >= 3)) { tip = ins; n.coachN = 0; }
      ensurePeriods(n);
      questEv(n, "correct", res.answered.filter(x => x.ok).length);
      if (res.won) {
        questEv(n, "win");
        if (res.isBoss) questEv(n, "bosswin");
        if (String(res.questId).startsWith("side")) questEv(n, "work");
        if (res.acc === 1 && res.answered.length >= 3) questEv(n, "perfect");
        if (res.bestCombo >= 3) questEv(n, "combo3");
        n.season.pts += res.isBoss ? 25 : 10;
      }
      addRewards(n, res.xpGained + (res.won ? res.xp : 0), res.won ? res.coins : 0);
      if (res.won) {
        n.stats.battles++;
        grant(n, "first");
        if (res.bestCombo >= 5) grant(n, "combo5");
        n.done[`${res.chId}:${res.questId}`] = true;
        if (res.isGat) {
          const score = Math.min(100, Math.round(55 + res.acc * 45));
          if (n.mem.gatFirst === null) { n.mem.gatFirst = score; tl(n, "gat", "🎫", `ظهرت نتيجة القدرات: ${score}`, "أسبوعان من الانتظار… ثم رسالة قياس. يدك ارتجفت وأنت تفتحها."); }
          else if (score > (n.gatScore || 0) && !n.mem.gatImproved) { n.mem.gatImproved = { from: n.gatScore, to: score }; tl(n, "gatup", "📈", `أعدت القدرات: من ${n.gatScore} إلى ${score}`, "كان ممكن تكتفي… لكنك رجعت للقاعة نفسها وطلعت برقم أعلى."); }
          n.gatScore = Math.max(n.gatScore || 0, score);
          if (n.gatScore >= 90) grant(n, "gat90");
          toast(`📜 درجة القدرات: ${n.gatScore}`);
        }
        if (res.chId === 5 && res.questId === "q2") tl(n, "proj", "🧪", "أول مشروع جامعي ينجح", "فريقك تأخر والتسليم كان غدًا… وأنت اللي أنقذ الموقف بالأرقام.");
        if (res.isBoss) {
          play("door");
          if (!Object.keys(n.done).some(k => k.endsWith(":boss") && k !== `${res.chId}:boss`)) tl(n, "firstboss", "⚔️", `أول زعيم يسقط: ${bname}`, "أول مرة تشوف شريط صحة زعيم يوصل صفر بيدك. ما ينتسى هذا الشعور.");
          tl(n, "boss" + res.chId, CH.find(c => c.id === res.chId).emoji, `أنهيت ${CH.find(c => c.id === res.chId).title}`);
          if (res.chId === 1) grant(n, "ch1");
          if (res.chId >= n.chapter && res.chId < 7) {
            n.chapter = res.chId + 1;
            if (n.chapter === 4) { grant(n, "usa"); tl(n, "usa1", "🗽", "أول يوم في أمريكا", "برد ما تعرفه، لغة حولك من كل جهة، وسرير غريب… وحماس يمنعك من النوم."); }
          }
          if (res.chId === 6) grant(n, "grad");
          if (res.isFinal) {
            n.finalAcc = Math.round(res.acc * 100);
            const gs = n.gatScore || 0;
            n.ending = gs >= 90 && n.finalAcc >= 70 ? "legend" : (gs >= 80 || n.finalAcc >= 60) ? "good" : "open";
            if (n.ending === "legend") grant(n, "aramco");
            tl(n, "ending", n.ending === "legend" ? "👑" : "🌅", n.ending === "legend" ? "يوم التوظيف: مهندس في أرامكو" : "أنهيت الرحلة الأولى", n.ending === "legend" ? `اتصال من الظهران: "مبروك يا مهندس ${n.name}". أول شخص اتصلت عليه؟ أبوك. ${n.mem.work >= 4 ? "ومن ورديات الكشك إلى برج أرامكو… يا لها من قصة." : ""}` : "الرحلة ما انتهت… هذي استراحة محارب قبل الجولة الأخيرة.");
          }
        }
      }
    });
    if (tip) setTimeout(() => setCoach(tip), 900);
    if (res.won && res.isFinal) { setView({ s: "ending" }); return; }
    // زعيم مهزوم → مشهد ختام الفصل + بطاقة الفصل الجديد
    const ch = CH.find(c => c.id === res.chId);
    if (res.won && res.isBoss && !g.seen[`out${res.chId}`] && ch.outro.length) {
      mut(n => { n.seen[`out${res.chId}`] = true; });
      setView({ s: "dialog", lines: ch.outro, after: { s: "chapterCard", id: res.chId + 1 } });
    } else if (res.won && res.isBoss && res.chId < 7) {
      setView({ s: "chapterCard", id: res.chId + 1 });
    } else setView({ s: "world" });
  };

  useEffect(() => {
    if (view.s === "world" && g.started && !g.seen.hello) {
      mut(n => { n.seen.hello = true; });
      const nm = g.name;
      setTimeout(() => setCoach({ e: "🧭", h: `أهلًا ${nm}! هذي بوصلتك`, d: "قبل أي معركة: 📚 الأكاديمية تعلّمك كل شي من الصفر — حتى جدول الضرب — على أربع مراحل حتى الاحتراف. الشريط الذهبي فوق يوجهك دائمًا 📍، والمعارك تطبيقك العملي. تعبت؟ نم، وكل صباح يجيب جديدًا." }), 1100);
    }
    if (view.s === "chapterCard") {
      const ch = CH.find(c => c.id === view.id);
      if (ch) setTrans({ e: ch.emoji, t: ch.title, sub: `📍 ${ch.place}`, bg: ch.usa ? "#101B30" : "#0E2B25", ms: 2300 });
      const t = setTimeout(() => {
        if (ch && !g.seen[`in${ch.id}`]) {
          mut(n => { n.seen[`in${ch.id}`] = true; });
          setView({ s: "dialog", lines: ch.intro, after: { s: "world" } });
        } else setView({ s: "world" });
      }, 2350);
      return () => clearTimeout(t);
    }
  }, [view.s]);

  const startBattle = (q) => {
    if (q.isBoss) { play("boss"); setView({ s: "prep", q }); return; }
    launchBattle(q);
  };
  const launchBattle = (q) => {
    play("click");
    spendSlot(q.side ? 20 : 15);
    const count = q.enemy.hp + 4;
    setView({
      s: "battle", chId: q.chId, questId: q.qid, isBoss: !!q.isBoss,
      usa: eraOf(g.chapter) === "us",
      enemy: { ...q.enemy, name: q.name, icon: q.icon },
      qs: buildChallenges(q.enemy.secs, count, g, !!q.isBoss),
      key: Date.now(),
    });
  };

  const doAct = (act, loc) => {
    if (act === "sleep") { doSleep(); setView({ s: "world" }); return; }
    if (act === "rest") { mut(n => { n.mem ||= {}; n.mem.rest = (n.mem.rest || 0) + 1; }); spendSlot(-40); play("coin"); toast("🛋️ ارتحت… +40 طاقة"); return; }
    if (act === "call") { mut(n => { n.dayFlags.called = true; n.energy = Math.min(100, n.energy + 15); }); play("coin"); toast("📞 «الله يوفقك يا وليدي» — +15 طاقة"); return; }
    if (act === "daily") {
      const today = new Date().toDateString();
      if (g.dailyDate === today) { toast("⏳ الصندوق يتجدد بكرة"); return; }
      const item = ["hint", "freeze", "potion"][Math.floor(Math.random() * 3)];
      mut(n => { n.dailyDate = today; n.coins += 40; n.items[item]++; addRewards(n, 10, 0); });
      play("coin");
      toast(`🎁 +40 🪙 + ${SHOP_ITEMS.find(s => s.id === item).icon} ${SHOP_ITEMS.find(s => s.id === item).name}`);
      return;
    }
    if (act === "academy") { play("door"); setView({ s: "acad" }); return; }
    if (act === "choice") { setView({ s: "choice" }); return; }
    if (act === "retake") {
      const b = CH.find(c => c.id === 2).boss;
      startBattle({ chId: 2, qid: "boss", isBoss: false, name: b.name, icon: b.icon, enemy: { hp: b.hp, secs: b.secs, time: b.time, xp: b.xp, coins: b.coins, isGat: true } });
    }
  };

  const claimTask = (scope, id) => mut(n => {
    ensurePeriods(n);
    const pool = scope === "d" ? DAILY_POOL : WEEKLY_POOL;
    const st = scope === "d" ? n.daily : n.weekly;
    const d = pool.find(p => p.id === id);
    if (!d || st.claimed[id] || (st.prog[id] || 0) < d.goal) return;
    st.claimed[id] = true;
    addRewards(n, d.r.xp || 0, d.r.coins || 0);
    if (d.r.item) n.items[d.r.item]++;
    n.season.pts += scope === "d" ? 15 : 40;
    toast(`✅ مهمة مكتملة: +${d.r.coins || 0}🪙${d.r.xp ? ` +${d.r.xp}XP` : ""}${d.r.item ? " +" + SHOP_ITEMS.find(s => s.id === d.r.item).icon : ""} • +${scope === "d" ? 15 : 40} نقطة موسم`);
    play("coin");
  });
  const claimSeason = (idx) => mut(n => {
    ensurePeriods(n);
    const t = SEASON.tiers[idx];
    if (!t || n.season.claimed.includes(idx) || n.season.pts < t.p) return;
    n.season.claimed.push(idx);
    if (t.r.coins) n.coins += t.r.coins;
    if (t.r.items) Object.entries(t.r.items).forEach(([k, v]) => { n.items[k] += v; });
    toast(`🏆 مكافأة الموسم: ${t.e} ${t.t}`);
    play("win");
  });

  const usaNow = eraOf(g.chapter) === "us" && view.s !== "title";
  const theme = usaNow ? { bg: "#0B1626", head: "#122B4A", card: "#16233A", text: "#EAF0F8", sub: "#9FB2CC", line: "#24354F" }
                       : { bg: "#F4F6F3", head: "#0F5147", card: "#FFFFFF", text: "#17251F", sub: "#5A6A62", line: "#E2E8E1" };

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: theme.bg, color: theme.text, fontFamily: "'Segoe UI', Tahoma, system-ui, sans-serif", transition: "background .6s ease" }}>
      <style>{`
        *{box-sizing:border-box;margin:0}
        html,body{background:${theme.bg};overscroll-behavior-y:contain}
        .card{box-shadow:0 1px 2px rgba(15,30,25,.05),0 5px 16px rgba(15,30,25,.06);background:${theme.card};border:1px solid ${theme.line};border-radius:16px;padding:14px;margin-bottom:10px;transition:background .5s ease}
        .btn{border:none;box-shadow:0 3px 10px rgba(15,81,71,.28);background:linear-gradient(180deg,#146455,#0F5147);color:#fff;padding:12px 20px;border-radius:12px;font-size:15px;font-weight:800;cursor:pointer;font-family:inherit}
        .btn.gold{background:linear-gradient(180deg,#D9A344,#C08A2C);box-shadow:0 3px 10px rgba(200,146,53,.3)}.btn.dark{background:#17251F}.btn.ghost{background:transparent;color:${theme.text};border:1.5px solid ${theme.line}}
        .opt{display:block;width:100%;text-align:left;direction:ltr;border:1.5px solid ${theme.line};background:${usaNow ? "#1B2B45" : "#FAFBFA"};color:${theme.text};border-radius:12px;padding:12px 14px;margin-bottom:8px;font-size:15px;cursor:pointer;font-family:inherit}
        .opt:disabled{opacity:.35}
        .hudbtn{border:none;background:rgba(255,255,255,.15);color:#fff;border-radius:12px;padding:8px 10px;font-size:13px;font-weight:800;cursor:pointer;font-family:inherit;white-space:nowrap}
        @keyframes pop{0%{transform:scale(.4);opacity:0}70%{transform:scale(1.12)}100%{transform:scale(1);opacity:1}}
        @keyframes shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-8px)}40%{transform:translateX(7px)}60%{transform:translateX(-5px)}80%{transform:translateX(4px)}}
        @keyframes floatUp{from{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(-52px)}}
        @keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}
        @keyframes drop{from{opacity:0;transform:translateY(-14px)}to{opacity:1;transform:none}}
        @keyframes fadein{from{opacity:0}to{opacity:1}}
        @keyframes walkbob{from{transform:translateY(0)}to{transform:translateY(-4px)}}
        .toast{background:#17251F;color:#F0C560;padding:11px 18px;border-radius:13px;font-weight:800;font-size:14px;animation:pop .3s ease;box-shadow:0 6px 22px rgba(0,0,0,.3);margin-bottom:8px}
        button:focus-visible{outline:3px solid #C89235;outline-offset:2px}
        button:active{transform:scale(.98)}
        .tpulse{animation:pulse .5s infinite;display:inline-block}
        @keyframes confetti{0%{transform:translateY(0) rotate(0);opacity:1}100%{transform:translateY(-90px) rotate(260deg);opacity:0}}
        @keyframes sheen{0%{background-position:-80px 0}100%{background-position:160px 0}}
        .goldbar{background-image:linear-gradient(90deg,#F0C560,#C89235),linear-gradient(100deg,transparent 30%,rgba(255,255,255,.55) 50%,transparent 70%)!important;background-size:100% 100%,60px 100%;background-repeat:no-repeat,no-repeat;animation:sheen 2.6s ease-in-out infinite}
      `}</style>

      <div style={{ position: "fixed", top: 12, left: "50%", transform: "translateX(-50%)", zIndex: 210, width: "min(92vw,420px)" }}>
        {toasts.map(t => <div className="toast" key={t.id}>{t.msg}</div>)}
      </div>

      {trans && <Transition card={trans} onDone={() => setTrans(null)} />}
      {coach && <Coach tip={coach} close={() => setCoach(null)} />}

      {view.s !== "title" && <HUD g={g} spFree={spFree} setPanel={setPanel} sound={sound} setSound={setSound}
        musicMode={musicMode} setMusicMode={setMusicMode}
        mode={g.mode} setMode={(m) => { mut(n => { n.mode = m; }); toast(m === "calm" ? "🧘 وضع هادئ: بدون مؤقت (إلا الزعماء)" : "⚡ وضع التحدي: مؤقت + بونص سرعة"); }} />}

      <div style={{ padding: "10px 14px 40px", maxWidth: 620, margin: "0 auto" }}>
        {view.s === "title" && <Title g={g} setG={setG} onStart={(name) => {
          mut(n => { n.started = true; n.name = name || n.name; ensurePeriods(n); tl(n, "start", "🎒", "بدأت الرحلة — سنة التخرج"); });
          play("win");
          setView({ s: "chapterCard", id: 1 });
        }} onContinue={() => { play("click"); setView({ s: "world" }); }} />}

        {view.s === "world" && <World g={g} theme={theme} night={night} startBattle={startBattle} doAct={doAct}
          onTalkEv={() => mut(n => questEv(n, "talk"))}
          onReview={() => { play("click"); setView({ s: "acad", review: true }); }}
          claimTask={claimTask} claimSeason={claimSeason} toast={toast} />}

        {view.s === "chapterCard" && <div style={{ minHeight: 200 }} />}

        {view.s === "prep" && <BossPrep g={g} theme={theme} q={view.q} onBegin={() => launchBattle(view.q)} onBack={() => { play("click"); setView({ s: "world" }); }} />}

        {view.s === "dialog" && <Dialog lines={view.lines} theme={theme} onDone={() => setView(view.after)} />}

        {view.s === "acad" && <Academy g={g} theme={theme} startReview={view.review}
          onOpenUnit={(u) => mut(n => { n.acad.opened ||= {}; n.acad.opened[u.id] = true; })}
          onReview={(records) => mut(n => {
            n.srs ||= {};
            let kept = 0;
            records.forEach(({ id, ok }) => {
              const s = n.srs[id] || { lvl: 0, due: n.day };
              if (ok) { kept++; s.lvl = Math.min(SRS_INT.length - 1, s.lvl + 1); s.due = n.day + SRS_INT[s.lvl]; if (AWL_WORDS[id]) questEv(n, "awlword", 1); }
              else { s.lvl = Math.max(0, s.lvl - 2); s.due = n.day + 1; }
              n.srs[id] = s;
            });
            addRewards(n, kept * 8, kept * 3);
            questEv(n, "correct", kept);
            tl(n, "firstrev", "🧠", "أول جلسة مراجعة متباعدة", "المعلومة اللي تراجعها بموعدها… تسكن الذاكرة الطويلة وتنتظرك يوم الاختبار.");
            toast(`🧠 ثبّت ${kept} • أعاد للغد ${records.length - kept}`);
          })}
          onExit={() => { play("click"); setView({ s: "world" }); }}
          onPlace={(rec) => mut(n => { n.acad.placed = rec; tl(n, "acadstart", "📚", "التحقت بالأكاديمية", rec === 0 ? "قررت تبني نفسك من الطابوقة الأولى. القرارات الكبيرة تبدأ هكذا." : `التشخيص وضعك في ${ACADEMY[rec].name.split(":")[1]} — أساسك موجود، نبني فوقه.`); })}
          onFinishUnit={(u, ph, opts = {}) => mut(n => {
            if (opts.bonusOnly) { addRewards(n, opts.bonusOnly, 0); return; }
            const review = !!n.acad.units[u.id];
            n.acad.units[u.id] = true;
            if (u.awl) questEv(n, "awlword", u.need || 5);
            n.srs ||= {};
            if (!n.srs[u.id] && u.drills) n.srs[u.id] = opts.tested ? { lvl: 2, due: n.day + SRS_INT[2] } : { lvl: 0, due: n.day + SRS_INT[0] };
            if (!review) {
              if (opts.tested) tl(n, "testout", "🔓", "تجاوزت مفهومًا باختبار الإتقان", "3/3 بلا خطأ — أثبتّ أن الأساس عندك، والخريطة فتحت الطريق.");
              const R = opts.tested ? [30, 15] : { F: [45, 20], S: [55, 25], Q: [70, 35] }[ph.id] || [50, 25];
              n.mem ||= {}; n.mem.study = (n.mem.study || 0) + 1;
              addRewards(n, R[0], R[1]);
              questEv(n, "correct", 3);
              tl(n, "firstlesson", "📖", "أول درس في الأكاديمية", "جلست، تعلمت مفهومًا، وطبقته بيدك. هكذا تُبنى العقول — درسًا فوق درس.");
              toast(`🎓 أتقنت: ${u.name} (+${R[0]} XP +${R[1]}🪙)`);
              if (phaseDone(n, ph.id)) { tl(n, "dip" + ph.id, ph.icon, `شهادة: ${ph.name.split(":")[1]}`, "مرحلة كاملة خلف ظهرك. المقتنيات 🎒 استقبلت شهادتك."); play("win"); setTimeout(() => toast(`${ph.icon} أكملت ${ph.name}!`), 700); }
            }
          })}
          onSimDone={(u, ph, res) => mut(n => {
            n.acad.units[u.id] = true;
            if (!n.acad.simBest || res.score > n.acad.simBest.score) n.acad.simBest = { score: res.score };
            res.log.forEach(({ sec, ok, t }) => {
              n.stats.answered++; if (ok) n.stats.correct++;
              n.stats.bySec[sec] ||= { a: 0, c: 0, t: 0, to: 0 };
              const v = n.stats.bySec[sec]; v.a++; if (ok) v.c++; v.t += t || 0;
            });
            addRewards(n, 60 + res.score, 45);
            tl(n, "firstsim", "🎭", `أول محاكاة كاملة — درجة تقديرية ${res.score}`, "قاعة صامتة ومؤقت لا يرحم… وطلعت منها برقم وخريطة ضعف واضحة. هذا هو التدريب الحقيقي.");
            if (u.sim.hard && res.score >= 90) tl(n, "elite", "🏅", "قهرت تحدي الصفوة بدرجة 90+", "22 ثانية للسؤال ولم ترمش. قياس بعدها بتحسها بطيئة.");
            if (phaseDone(n, ph.id)) { tl(n, "dipP", ph.icon, `ختم الاحتراف`, "أنهيت آخر قاعة في الأكاديمية. من هنا وطالع… أنت المعلم."); play("win"); }
            toast(`🎭 درجتك التقديرية: ${res.score}`);
          })} />}

        {view.s === "choice" && <UniChoice g={g} theme={theme} onPick={(u) => {
          mut(n => { n.uni = u.name; n.done["3:choice"] = true; addRewards(n, 30, 20); tl(n, "uni", "✉️", `القبول: ${u.name}`, "قرأت خطاب القبول ثلاث مرات عشان تتأكد إنه اسمك فعلًا."); });
          play("win"); toast(`🎓 انقبلت في ${u.name}`);
          setView({ s: "world" });
        }} onRetake={() => doAct("retake")} back={() => setView({ s: "world" })} />}

        {view.s === "battle" && <Battle key={view.key} view={view} g={g} theme={theme} spendItem={(id) => mut(n => { n.items[id]--; })} onEnd={onBattleEnd} />}

        {view.s === "ending" && <Ending g={g} theme={theme} onReplay={() => {
          mut(n => { n.done["7:boss"] = false; n.ending = null; });
          setView({ s: "world" });
        }} onFree={() => setView({ s: "world" })} />}
      </div>

      {panel === "road" && <RoadPanel g={g} theme={theme} close={() => setPanel(null)} goAcad={() => setView({ s: "acad" })} />}
      {panel === "journal" && <Journal g={g} theme={theme} close={() => setPanel(null)} />}
      {panel && panel !== "journal" && <Panel g={g} theme={theme} panel={panel} spFree={spFree} close={() => setPanel(null)}
        buySkill={(sk) => mut(n => { n.skills.push(sk.id); if (n.skills.length >= 3) grant(n, "skills3"); })}
        buyItem={(it) => mut(n => { n.coins -= (n.dayFlags?.sale ? Math.ceil(it.price / 2) : it.price); n.items[it.id]++; })}
        buyAvatar={(av) => mut(n => { n.coins -= av.price; n.owned.push(av.id); n.avatar = av.id; })}
        wearAvatar={(av) => mut(n => { n.avatar = av.id; })} toast={toast} />}
    </div>
  );
}

/* ---------- العالم: شارع + داخل مبنى ---------- */
function World({ g, theme, night, startBattle, doAct, onTalkEv, claimTask, claimSeason, onReview, toast }) {
  const [inside, setInside] = useState(null);
  const [pos, setPos] = useState(0);
  const [talk, setTalk] = useState(null);
  const canAct = !night;
  const era = eraOf(g.chapter);
  useEffect(() => { setInside(null); setPos(0); setTalk(null); }, [g.chapter]);
  if (talk) return <Dialog lines={talk} theme={theme} onDone={() => setTalk(null)} />;
  return (
    <div>
      {!inside && <GoalTasks g={g} theme={theme} claimTask={claimTask} claimSeason={claimSeason} onReview={onReview} />}
      {!inside && <Street g={g} theme={theme} night={night} pos={pos} setPos={setPos} onEnter={(loc) => setInside(loc)} />}
      {!inside && night && (
        <div className="card" style={{ textAlign: "center", fontWeight: 800, fontSize: 13.5 }}>
          🌙 استهلكت يومك كله. ادخل {era === "us" ? "السكن" : "البيت"} ونَم لتبدأ اليوم {g.day + 1}.
        </div>
      )}
      {inside && <Interior g={g} theme={theme} loc={inside} night={night} canAct={canAct}
        onQuest={(q) => { if (!canAct) { toast("🌙 الوقت متأخر — نم أولًا"); return; } startBattle(q); }}
        onAct={(a) => doAct(a, inside)} onTalk={(lines) => { onTalkEv(); setTalk(lines); }} close={() => { play("click"); setInside(null); }} />}
    </div>
  );
}

/* ---------- HUD v2: لاعب + يوم + طاقة ---------- */
function HUD({ g, spFree, setPanel, sound, setSound, musicMode, setMusicMode, mode, setMode }) {
  const lvl = lvlOf(g.xp);
  const cur = g.xp - xpForLvl(lvl), need = xpForLvl(lvl + 1) - xpForLvl(lvl);
  const t = titleOf(g.xp);
  const av = AVATARS.find(a => a.id === g.avatar);
  const usa = eraOf(g.chapter) === "us";
  const head = usa ? "#122B4A" : "#0F5147";
  return (
    <div style={{ background: head, color: "#fff", padding: "calc(env(safe-area-inset-top, 0px) + 12px) 14px 10px", borderRadius: "0 0 20px 20px", transition: "background .6s ease" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ fontSize: 32 }}>{av.e}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 900, fontSize: 14.5 }}>{g.name} <span style={{ fontSize: 11.5, opacity: .85 }}>• {t.icon} {t.name} • Lv.{lvl}</span></div>
          <div style={{ background: "rgba(255,255,255,.18)", borderRadius: 99, height: 7, overflow: "hidden", marginTop: 4 }}>
            <div className="goldbar" style={{ width: `${Math.min(100, (cur / need) * 100)}%`, height: "100%", transition: "width .5s" }} />
          </div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontWeight: 900, fontSize: 14, color: "#F0C560" }}><Ico n="coin" s={15} /> {g.coins}</div>
          {g.streak > 0 && <div style={{ fontSize: 11, fontWeight: 800 }}><Ico n="bolt2" s={12} /> {g.streak}ي</div>}
        </div>
      </div>
      {/* شريط اليوم والطاقة */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8, fontSize: 12, fontWeight: 800 }}>
        <span style={{ background: "rgba(255,255,255,.15)", borderRadius: 8, padding: "2px 8px" }}>📅 اليوم {g.day}</span>
        <span style={{ background: "rgba(255,255,255,.15)", borderRadius: 8, padding: "2px 8px" }}>{g.slot >= 3 ? "🌙 ليل" : SLOTS[g.slot]}</span>
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 5 }}>
          <Ico n="battery" s={16} c="#fff" />
          <div style={{ flex: 1, background: "rgba(255,255,255,.18)", borderRadius: 99, height: 8, overflow: "hidden" }}>
            <div style={{ width: `${g.energy}%`, height: "100%", background: g.energy < 30 ? "#E85D4A" : g.energy < 60 ? "#F0C560" : "#7FD8A4", transition: "width .5s", borderRadius: 99 }} />
          </div>
          <span style={{ minWidth: 30 }}>{g.energy}%</span>
        </div>
      </div>
      <div style={{ display: "flex", gap: 6, marginTop: 9, overflowX: "auto", WebkitOverflowScrolling: "touch" }}>
        <button className="hudbtn" style={{ position: "relative" }} onClick={() => setPanel("skills")}>🌳{spFree > 0 && <span style={{ position: "absolute", top: -4, left: -4, background: "#B3402F", borderRadius: 99, fontSize: 10, padding: "1px 6px", fontWeight: 900 }}>{spFree}</span>}</button>
        <button className="hudbtn" onClick={() => setPanel("shop")}>🛒</button>
        <button className="hudbtn" style={{ fontWeight: 900 }} onClick={() => setPanel("road")}>🏢</button>
        <button className="hudbtn" onClick={() => setPanel("journal")}>📔</button>
        <button className="hudbtn" onClick={() => setPanel("ach")}>🏅</button>
        <button className="hudbtn" onClick={() => setPanel("stats")}>📊</button>
        <button className="hudbtn" onClick={() => setMode(mode === "calm" ? "hard" : "calm")}>{mode === "calm" ? "🧘" : "⚡"}</button>
        <button className="hudbtn" onClick={() => setSound(!sound)}>{sound ? "🔊" : "🔇"}</button>
        <button className="hudbtn" onClick={() => setMusicMode(musicMode === "off" ? "dream" : musicMode === "dream" ? "glow" : "off")}>{musicMode === "off" ? "🎶✖️" : musicMode === "dream" ? "🌙" : "🌈"}</button>
      </div>
    </div>
  );
}

function Title({ g, setG, onStart, onContinue }) {
  const [name, setName] = useState(g.name || "ضاوي");
  const [confirmNew, setConfirmNew] = useState(false);
  return (
    <div style={{ textAlign: "center", paddingTop: 40, animation: "pop .5s ease" }}>
      <div style={{ color: "#0F5147" }}><AriseLogo size={96} /></div>
      <h1 dir="ltr" style={{ fontSize: 34, fontWeight: 900, color: "#17251F", margin: "4px 0 2px", letterSpacing: 6 }}>ARISE</h1>
      <div style={{ fontSize: 15.5, color: "#5A6A62", fontWeight: 700 }}>من الصفر… إلى أرامكو 🛢️</div>
      <div style={{ fontSize: 13, color: "#8A968E", margin: "10px 0 26px", lineHeight: 1.8 }}>عالم حر • أيام تعيشها • شخصيات تتذكرك — وسلاحك عقلك</div>
      {g.started && !confirmNew && (
        <button className="btn gold" style={{ width: "80%", padding: 15, fontSize: 17, marginBottom: 12 }} onClick={onContinue}>▶️ متابعة — اليوم {g.day}</button>
      )}
      {!confirmNew ? (
        <button className={g.started ? "btn ghost" : "btn"} style={{ width: "80%", padding: g.started ? 12 : 15, fontSize: g.started ? 14 : 17 }}
          onClick={() => (g.started ? setConfirmNew(true) : onStart(name))}>🆕 قصة جديدة</button>
      ) : (
        <div className="card" style={{ width: "88%", margin: "0 auto" }}>
          <div style={{ fontSize: 14, marginBottom: 10, fontWeight: 700 }}>بداية جديدة تمسح تقدمك الحالي كاملًا. متأكد؟</div>
          <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
            <button className="btn dark" onClick={() => { setG({ ...newSave(), started: false }); setConfirmNew(false); }}>نعم، امسح</button>
            <button className="btn ghost" onClick={() => setConfirmNew(false)}>تراجع</button>
          </div>
        </div>
      )}
      {!g.started && (
        <div style={{ marginTop: 18 }}>
          <div style={{ fontSize: 13, fontWeight: 800, color: "#5A6A62", marginBottom: 6 }}>اسم البطل:</div>
          <input value={name} onChange={e => setName(e.target.value)} maxLength={14}
            style={{ padding: "10px 14px", borderRadius: 12, border: "1.5px solid #D6DED6", fontSize: 15, fontFamily: "inherit", textAlign: "center", width: 200 }} />
        </div>
      )}
    </div>
  );
}
function Dialog({ lines, theme, onDone }) {
  const [li, setLi] = useState(0);
  const [chars, setChars] = useState(0);
  const line = lines[li];
  const full = line.t;
  useEffect(() => {
    setChars(0);
    const t = setInterval(() => setChars(c => {
      if (c >= full.length) { clearInterval(t); return c; }
      return c + 1;
    }), 17);
    return () => clearInterval(t);
  }, [li]);
  const tap = () => {
    play("click");
    if (chars < full.length) setChars(full.length);
    else if (li + 1 < lines.length) setLi(li + 1);
    else onDone();
  };
  return (
    <div onClick={tap} style={{ cursor: "pointer", paddingTop: 30, animation: "drop .3s ease" }}>
      <div style={{ textAlign: "center", fontSize: 76, marginBottom: 14, animation: "pulse 3s infinite" }}>{line.e}</div>
      <div className="card" style={{ padding: 18, minHeight: 130 }}>
        <div style={{ fontWeight: 900, fontSize: 14, color: "#C89235", marginBottom: 8 }}>{line.who}</div>
        <div style={{ fontSize: 16, lineHeight: 2 }}>{full.slice(0, chars)}<span style={{ opacity: .5 }}>▌</span></div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8, padding: "0 4px" }}>
        <span style={{ fontSize: 12.5, color: theme.sub }}>اضغط للمتابعة • {li + 1}/{lines.length} {chars >= full.length && <span className="tpulse">▼</span>}</span>
        <button onClick={(e) => { e.stopPropagation(); play("click"); onDone(); }} style={{ background: "none", border: "none", color: theme.sub, fontWeight: 800, fontSize: 12.5, cursor: "pointer", fontFamily: "inherit" }}>تخطي ⏭</button>
      </div>
    </div>
  );
}

function UniChoice({ g, theme, onPick, onRetake, back }) {
  const score = g.gatScore || 0;
  return (
    <div style={{ animation: "drop .35s ease" }}>
      <button onClick={back} style={{ background: "none", border: "none", color: theme.text, fontWeight: 800, fontSize: 14, cursor: "pointer", fontFamily: "inherit", marginBottom: 8, opacity: .8 }}>→ رجوع</button>
      <div className="card" style={{ textAlign: "center" }}>
        <div style={{ fontSize: 34 }}>🗝️</div>
        <div style={{ fontWeight: 900, fontSize: 16, margin: "4px 0" }}>درجتك: <span style={{ color: "#C89235" }}>{score}</span></div>
        <div style={{ fontSize: 13, color: theme.sub }}>كل باب له مفتاح. الأبواب المقفلة تحتاج درجة أعلى.</div>
      </div>
      {UNIS.map(u => {
        const open = score >= u.need;
        return (
          <button key={u.name} className="card" disabled={!open} onClick={() => open && onPick(u)}
            style={{ width: "100%", textAlign: "right", fontFamily: "inherit", cursor: open ? "pointer" : "not-allowed", opacity: open ? 1 : .5, display: "flex", gap: 12, alignItems: "center", color: theme.text, border: open ? "1.5px solid #1F7A5C55" : `1px solid ${theme.line}` }}>
            <div style={{ fontSize: 28 }}>{open ? u.e : "🔒"}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 900, fontSize: 14.5 }}>{u.name}</div>
              <div style={{ fontSize: 12.5, color: theme.sub, marginTop: 2 }}>{u.need > 0 ? `يتطلب ${u.need}+` : "قبول مفتوح"}</div>
            </div>
            {open && <div style={{ fontWeight: 900, color: "#1F7A5C", fontSize: 13 }}>ادخل ←</div>}
          </button>
        );
      })}
      {score < 90 && (
        <button className="btn dark" style={{ width: "100%", padding: 13, marginTop: 4 }} onClick={onRetake}>🔁 أعد اختبار القدرات وارفع درجتك</button>
      )}
    </div>
  );
}

/* ═══════════════ ⚔️ BATTLE ENGINE — أربعة أنماط لعب ═══════════════ */

const QUANT_SECS = ["arithmetic", "algebra", "geometry", "comparison", "data"];

function Battle({ view, g, theme, spendItem, onEnd }) {
  const { enemy, qs, chId, questId, isBoss } = view;
  const calm = g.mode === "calm" && !isBoss;      // 🧘 بدون مؤقت خارج الزعماء
  const maxHearts = g.skills.includes("heart4") ? 4 : 3;
  const [qi, setQi] = useState(0);
  const [picked, setPicked] = useState(null);      // mcq: index | -1 مهلة | "done"
  const [numVal, setNumVal] = useState("");
  const [matchSel, setMatchSel] = useState(null);  // كلمة إنجليزية مختارة
  const [matchDone, setMatchDone] = useState([]);  // أزواج مكتملة
  const [matchWrong, setMatchWrong] = useState(0);
  const [matchShuf] = useState(() => qs.map(c => c.kind === "match" ? [...c.pairs.map(p => p[1])].sort(() => Math.random() - 0.5) : null));
  const [orderProg, setOrderProg] = useState([]);
  const [orderFails, setOrderFails] = useState(0);
  const [orderShuf] = useState(() => qs.map(c => c.kind === "order" ? [...c.steps].sort(() => Math.random() - 0.5) : null));
  const [removed, setRemoved] = useState([]);
  const [frozen, setFrozen] = useState(false);
  const [freeHint, setFreeHint] = useState(g.skills.includes("vhint"));
  const [enemyHp, setEnemyHp] = useState(enemy.hp);
  const tired = (g.energy ?? 100) < 30;
  const [hearts, setHearts] = useState(Math.max(2, maxHearts - (tired ? 1 : 0)));
  const [combo, setCombo] = useState(0);
  const [bestCombo, setBestCombo] = useState(0);
  const [xpGained, setXpGained] = useState(0);
  const [log, setLog] = useState([]);
  const [over, setOver] = useState(null);
  const [fx, setFx] = useState({});
  const q = qs[qi % qs.length];
  const isQuant = QUANT_SECS.includes(q.sec);
  const baseTime = q.kind === "match" || q.kind === "order" ? 60 : enemy.time;
  const TIME = baseTime + (isQuant && g.skills.includes("qtime") ? 8 : 0) + (!isQuant && g.skills.includes("vtime") ? 8 : 0);
  const [timeLeft, setTimeLeft] = useState(TIME);
  const [teach, setTeach] = useState(false);
  const qStart = useRef(Date.now());
  const took = () => Math.min(90, Math.max(1, Math.round((Date.now() - qStart.current) / 1000)));

  useEffect(() => { setTimeLeft(TIME); qStart.current = Date.now(); }, [qi]);

  useEffect(() => {
    if (calm || picked !== null || over || frozen) return;
    const t = setInterval(() => setTimeLeft(x => x - 1), 1000);
    return () => clearInterval(t);
  }, [picked, over, qi, frozen, calm]);

  useEffect(() => {
    if (!calm && timeLeft <= 0 && picked === null && !over && !frozen) miss(-1);
  }, [timeLeft]);

  const critAt = isQuant && g.skills.includes("qcrit") ? 2 : 3;

  const endBattle = (won, finalLog, finalXp, finalBest) => {
    const correct = finalLog.filter(x => x.ok).length;
    const acc = finalLog.length ? correct / finalLog.length : 0;
    setOver(won ? "win" : "lose");
    play(won ? "win" : "wrong");
    setFx(f => ({ ...f, result: { won, chId, questId, isBoss, isGat: !!enemy.isGat, isFinal: !!enemy.isFinal, acc, xpGained: finalXp, coins: enemy.coins, xp: enemy.xp, bestCombo: finalBest, answered: finalLog } }));
  };

  const dealDamage = (dmg, gain, crit, newLog, newCombo) => {
    const newXp = xpGained + gain;
    const newBest = Math.max(bestCombo, newCombo);
    setBestCombo(newBest); setXpGained(newXp);
    play(crit ? "crit" : "correct");
    setFx({ hitEnemy: true, dmgText: crit ? `💥 −${dmg} حاسمة!` : `−${dmg}`, xpText: `+${gain}` });
    setTimeout(() => setFx(f => ({ ...f, hitEnemy: false })), 450);
    const newHp = Math.max(0, enemyHp - dmg);
    setEnemyHp(newHp);
    if (newHp <= 0) { setTimeout(() => endBattle(true, newLog, newXp, newBest), 900); return true; }
    return false;
  };

  const takeHit = (newLog) => {
    setCombo(0);
    play("heart");
    setFx({ hitMe: true });
    setTimeout(() => setFx(f => ({ ...f, hitMe: false })), 450);
    const h = hearts - 1;
    setHearts(h);
    if (h <= 0) setTimeout(() => endBattle(false, newLog, xpGained, bestCombo), 1100);
    return h;
  };

  /* --- MCQ --- */
  const hit = (idx) => {
    if (picked !== null || over) return;
    setPicked(idx);
    const ok = idx === q.a;
    const newLog = [...log, { sec: q.sec, ok, t: took() }];
    setLog(newLog);
    if (ok) {
      const newCombo = combo + 1;
      setCombo(newCombo);
      const crit = newCombo >= critAt;
      const fast = !calm && timeLeft > TIME * 0.6;
      dealDamage(crit ? 2 : 1, 10 * Math.min(newCombo, 4) + (fast ? 5 : 0) + (crit ? 5 : 0), crit, newLog, newCombo);
    } else takeHit(newLog);
  };

  const miss = (idx) => {
    setPicked(-1);
    const newLog = [...log, { sec: q.sec, ok: false, t: TIME, to: true }];
    setLog(newLog);
    takeHit(newLog);
  };

  /* --- NUM (لوحة أرقام) --- */
  const numSubmit = () => {
    if (picked !== null || numVal === "") return;
    const ok = parseInt(numVal, 10) === q.a;
    setPicked(ok ? "done" : "wrongnum");
    const newLog = [...log, { sec: q.sec, ok, t: took() }];
    setLog(newLog);
    if (ok) {
      const newCombo = combo + 1;
      setCombo(newCombo);
      const crit = newCombo >= critAt;
      dealDamage(crit ? 2 : 1, 12 * Math.min(newCombo, 4) + (crit ? 5 : 0), crit, newLog, newCombo);
    } else takeHit(newLog);
  };

  /* --- MATCH (توصيل كلمات) --- */
  const tapEn = (w) => { if (!matchDone.some(d => d[0] === w)) { setMatchSel(w); play("click"); } };
  const tapAr = (m) => {
    if (!matchSel || matchDone.some(d => d[1] === m)) return;
    const pair = q.pairs.find(p => p[0] === matchSel);
    const newLog = [...log, { sec: "vocab", ok: pair[1] === m, t: took() }];
    setLog(newLog);
    if (pair[1] === m) {
      const nd = [...matchDone, [matchSel, m]];
      setMatchDone(nd); setMatchSel(null);
      const newCombo = combo + 1; setCombo(newCombo);
      const dead = dealDamage(1, 8, false, newLog, newCombo);
      if (!dead && nd.length === q.pairs.length) setPicked("done");
    } else {
      setMatchSel(null);
      const mw = matchWrong + 1; setMatchWrong(mw);
      setFx({ hitMe: true }); play("wrong"); setCombo(0);
      setTimeout(() => setFx(f => ({ ...f, hitMe: false })), 400);
      if (mw >= 3) { setMatchWrong(0); takeHit(newLog); }
    }
  };

  /* --- ORDER (رتّب الحل) --- */
  const tapStep = (s) => {
    if (picked !== null || orderProg.includes(s)) return;
    if (q.steps[orderProg.length] === s) {
      const np = [...orderProg, s];
      setOrderProg(np); play("click");
      if (np.length === q.steps.length) {
        setPicked("done");
        const newLog = [...log, { sec: q.sec, ok: true, t: took() }];
        setLog(newLog);
        const newCombo = combo + 1; setCombo(newCombo);
        dealDamage(2, 25, true, newLog, newCombo);
      }
    } else {
      setOrderProg([]); setCombo(0);
      setFx({ hitMe: true }); play("wrong");
      setTimeout(() => setFx(f => ({ ...f, hitMe: false })), 400);
      const of = orderFails + 1; setOrderFails(of);
      if (of >= 2) {
        setOrderFails(0);
        const newLog = [...log, { sec: q.sec, ok: false, t: took() }];
        setLog(newLog);
        takeHit(newLog);
        setPicked("failorder");   // اكشف الحل الصحيح بدل تعليق اللاعب
      }
    }
  };

  const next = () => {
    play("click");
    setQi(qi + 1); setPicked(null); setRemoved([]); setFrozen(false);
    setNumVal(""); setMatchSel(null); setMatchDone([]); setMatchWrong(0);
    setOrderProg([]); setOrderFails(0);
  };

  const useHint = () => {
    if (q.kind !== "mcq" || picked !== null || removed.length) return;
    if (freeHint) setFreeHint(false);
    else if (g.items.hint > 0) spendItem("hint");
    else return;
    setRemoved([0, 1, 2, 3].filter(i => i !== q.a).sort(() => Math.random() - 0.5).slice(0, 2));
    play("coin");
  };
  const useFreeze = () => {
    if (calm || picked !== null || frozen || g.items.freeze <= 0) return;
    spendItem("freeze"); setFrozen(true); play("coin");
  };
  const usePotion = () => {
    if (hearts >= maxHearts || g.items.potion <= 0 || over) return;
    spendItem("potion"); setHearts(hearts + 1); play("coin");
  };

  /* --- نتيجة المعركة --- */
  if (over && fx.result) {
    const r = fx.result;
    const acc = Math.round(r.acc * 100);
    return (
      <div className="card" style={{ textAlign: "center", padding: 26, animation: "pop .45s ease", position: "relative", overflow: "hidden" }}>
        {r.won && ["🎉", "✨", "⭐", "🎊", "✨", "🌟", "🎉", "⭐"].map((c, i) => (
          <span key={i} style={{ position: "absolute", bottom: 10, left: `${8 + i * 12}%`, fontSize: 18, animation: `confetti ${0.9 + (i % 3) * 0.3}s ease ${i * 0.08}s forwards` }}>{c}</span>
        ))}
        <div style={{ fontSize: 58 }}>{r.won ? (isBoss ? "🏆" : "⚔️") : "💔"}</div>
        <div style={{ fontSize: 21, fontWeight: 900, margin: "8px 0 6px", color: r.won ? "#1F7A5C" : "#B3402F" }}>
          {r.won ? `هزمت ${enemy.name}!` : "سقطت في المعركة"}
        </div>
        {r.won && r.isGat && <div style={{ fontSize: 15, fontWeight: 900, background: "#C8923522", color: "#C89235", borderRadius: 12, padding: "8px 12px", margin: "6px 0" }}>📜 درجتك في القدرات: {Math.min(100, Math.round(55 + r.acc * 45))}</div>}
        <div style={{ fontSize: 14.5, lineHeight: 2.1 }}>
          الدقة: <b>{acc}%</b> • أفضل كومبو: <b>🔥×{r.bestCombo}</b><br />
          <span style={{ color: "#C89235", fontWeight: 900, fontSize: 17 }}>+{r.xpGained + (r.won ? r.xp : 0)} XP</span>
          {r.won && <span style={{ fontWeight: 900 }}> • 🪙 +{r.coins}{g.skills.includes("gold") ? " (×1.5)" : ""}</span>}
        </div>
        {!r.won && <div style={{ fontSize: 13, color: theme.sub, marginTop: 8, lineHeight: 1.8 }}>احتفظت بالـXP اللي جمعته. جهّز أدواتك أو افتح مهارة وارجع.</div>}
        <button className="btn gold" style={{ marginTop: 14, width: "100%", padding: 13 }} onClick={() => onEnd(r)}>
          {r.won ? "استلم الغنائم ←" : "انسحاب تكتيكي ←"}
        </button>
      </div>
    );
  }

  const kindChip = { mcq: "🎯 اختر الضربة", num: "🔢 اكتب الجواب واضرب", match: "🔗 وصّل الأزواج — كل وصلة ضربة", order: "🧩 رتّب خطوات الحل — ترتيب كامل = ضربة حاسمة" }[q.kind];

  return (
    <div style={{ animation: "drop .3s ease" }}>
      {/* العدو */}
      <div className="card" style={{ textAlign: "center", background: "#17251F", color: "#fff", border: "none", position: "relative", animation: fx.hitEnemy ? "shake .4s ease" : "none" }}>
        {fx.dmgText && fx.hitEnemy && <div style={{ position: "absolute", top: 6, left: "50%", transform: "translateX(-50%)", color: "#F0C560", fontWeight: 900, fontSize: 20, animation: "floatUp .8s ease forwards" }}>{fx.dmgText}</div>}
        <div style={{ fontSize: 54, filter: fx.hitEnemy ? "brightness(2)" : "none", animation: "pulse 2.5s infinite" }}>{enemy.icon}</div>
        <div style={{ fontWeight: 900, fontSize: 15, margin: "4px 0 8px" }}>{enemy.name}</div>
        <div style={{ background: "rgba(255,255,255,.15)", borderRadius: 99, height: 12, overflow: "hidden", maxWidth: 260, margin: "0 auto" }}>
          <div style={{ width: `${(enemyHp / enemy.hp) * 100}%`, height: "100%", background: "linear-gradient(90deg,#E85D4A,#B3402F)", transition: "width .5s ease", borderRadius: 99 }} />
        </div>
        <div style={{ fontSize: 12, marginTop: 4, opacity: .9, fontWeight: 800 }}><Ico n="skull" s={14} /> {enemyHp}/{enemy.hp}</div>
      </div>

      {/* اللاعب */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 4px", marginBottom: 8, animation: fx.hitMe ? "shake .4s ease" : "none" }}>
        <div style={{ display: "flex", gap: 3 }}>{Array.from({ length: maxHearts }).map((_, i) => <Ico key={i} n="heart" s={19} c={i < hearts ? "#E0453A" : theme.line} style={{ filter: i < hearts ? "drop-shadow(0 1px 1px rgba(0,0,0,.25))" : "none", transition: "fill .3s" }} />)}</div>
        <div style={{ fontWeight: 900, fontSize: 13, color: combo >= 2 ? "#C89235" : theme.sub }}>{combo >= 2 ? `🔥 كومبو ×${Math.min(combo, 4)}` : tired ? "🥱 مرهق: −1 قلب" : calm ? "🧘 خذ راحتك" : `جولة ${qi + 1}`}</div>
        <div style={{ display: "flex", gap: 6 }}>
          <button className="hudbtn" onClick={useHint} disabled={q.kind !== "mcq" || picked !== null || removed.length > 0 || (!freeHint && g.items.hint <= 0)}
            style={{ opacity: q.kind === "mcq" && (freeHint || g.items.hint > 0) && !removed.length ? 1 : .35 }}>💡{freeHint ? "★" : g.items.hint}</button>
          <button className="hudbtn" onClick={useFreeze} disabled={calm || frozen || g.items.freeze <= 0} style={{ opacity: !calm && g.items.freeze > 0 && !frozen ? 1 : .35 }}>🧊{g.items.freeze}</button>
          <button className="hudbtn" onClick={usePotion} disabled={hearts >= maxHearts || g.items.potion <= 0} style={{ opacity: g.items.potion > 0 && hearts < maxHearts ? 1 : .35 }}>🧪{g.items.potion}</button>
        </div>
      </div>

      <div className="card" style={{ position: "relative" }}>
        {fx.xpText && fx.hitEnemy && <div style={{ position: "absolute", top: 8, left: 14, color: "#C89235", fontWeight: 900, fontSize: 15, animation: "floatUp .9s ease forwards", direction: "ltr" }}>{fx.xpText} XP</div>}
        <div style={{ fontSize: 12, fontWeight: 900, color: "#C89235", marginBottom: 8 }}>{kindChip}</div>

        {/* المؤقت — يختفي كليًا في الوضع الهادئ */}
        {!calm && (
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <span className={!frozen && timeLeft <= 5 ? "tpulse" : ""} style={{ fontWeight: 900, fontSize: 13, color: frozen ? "#3B82C4" : timeLeft <= 8 ? "#B3402F" : theme.text, minWidth: 44, direction: "ltr", textAlign: "left" }}>{frozen ? "🧊 ∞" : `⏱ ${Math.max(timeLeft, 0)}s`}</span>
            <div style={{ flex: 1, background: theme.line, height: 6, borderRadius: 99, overflow: "hidden" }}>
              <div style={{ width: frozen ? "100%" : `${(Math.max(timeLeft, 0) / TIME) * 100}%`, height: "100%", background: frozen ? "#3B82C4" : timeLeft <= 8 ? "#B3402F" : "#C89235", transition: "width 1s linear", borderRadius: 99 }} />
            </div>
          </div>
        )}

        {/* ---------- MCQ ---------- */}
        {q.kind === "mcq" && <>
          <div dir="ltr" style={{ textAlign: "left", fontSize: 15.5, lineHeight: 1.75, marginBottom: 13, whiteSpace: "pre-line", fontWeight: 600 }}>{q.q}</div>
          {q.options.map((o, idx) => {
            const gone = removed.includes(idx);
            let style = {};
            if (picked !== null) {
              if (idx === q.a) style = { borderColor: "#1F7A5C", background: "#1F7A5C22", fontWeight: 700 };
              else if (idx === picked) style = { borderColor: "#B3402F", background: "#B3402F22" };
            }
            return <button key={idx} className="opt" style={style} disabled={gone} onClick={() => hit(idx)}>{String.fromCharCode(65 + idx)}. {gone ? "—" : o}</button>;
          })}
        </>}

        {/* ---------- NUM: لوحة أرقام ---------- */}
        {q.kind === "num" && <>
          <div dir="ltr" style={{ textAlign: "left", fontSize: 17, fontWeight: 700, marginBottom: 10 }}>{q.q}</div>
          <div dir="ltr" style={{ textAlign: "center", fontSize: 26, fontWeight: 900, letterSpacing: 3, background: theme.line + "55", borderRadius: 12, padding: "10px 0", marginBottom: 10, minHeight: 52, color: picked === "done" ? "#1F7A5C" : picked === "wrongnum" ? "#B3402F" : theme.text }}>
            {numVal || "؟"}
          </div>
          {picked === null && <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 7 }}>
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, "⌫", 0, "⚔️"].map(k => (
              <button key={k} className="opt" style={{ textAlign: "center", fontSize: 18, fontWeight: 900, padding: "13px 0", margin: 0, background: k === "⚔️" ? "#0F5147" : undefined, color: k === "⚔️" ? "#fff" : undefined, opacity: k === "⚔️" && !numVal ? .45 : 1 }}
                onClick={() => {
                  play("click");
                  if (k === "⌫") setNumVal(v => v.slice(0, -1));
                  else if (k === "⚔️") numSubmit();
                  else if (numVal.length < 6) setNumVal(v => v + k);
                }}>{k}</button>
            ))}
          </div>}
        </>}

        {/* ---------- MATCH: توصيل ---------- */}
        {q.kind === "match" && <>
          <div style={{ fontSize: 13.5, marginBottom: 10, lineHeight: 1.7 }}>وصّل كل كلمة بمعناها. كل وصلة صحيحة = ضربة للعدو. (3 أخطاء = العدو يضربك)</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            <div>
              {q.pairs.map(([w]) => {
                const done = matchDone.some(d => d[0] === w);
                return <button key={w} className="opt" disabled={done} onClick={() => tapEn(w)}
                  style={{ textAlign: "center", fontWeight: 800, margin: "0 0 8px", opacity: done ? .35 : 1, borderColor: matchSel === w ? "#C89235" : undefined, background: matchSel === w ? "#C8923522" : done ? "#1F7A5C22" : undefined }}>{done ? "✓ " : ""}{w}</button>;
              })}
            </div>
            <div>
              {matchShuf[qi % qs.length].map((m) => {
                const done = matchDone.some(d => d[1] === m);
                return <button key={m} className="opt" dir="rtl" disabled={done} onClick={() => tapAr(m)}
                  style={{ textAlign: "center", fontWeight: 800, margin: "0 0 8px", opacity: done ? .35 : 1, background: done ? "#1F7A5C22" : undefined }}>{done ? "✓ " : ""}{m}</button>;
              })}
            </div>
          </div>
          {matchWrong > 0 && picked === null && <div style={{ fontSize: 12.5, color: "#B3402F", fontWeight: 800, marginTop: 4 }}>محاولات خاطئة: {matchWrong}/3</div>}
        </>}

        {/* ---------- ORDER: رتّب الحل ---------- */}
        {q.kind === "order" && <>
          <div style={{ fontSize: 14.5, fontWeight: 800, marginBottom: 10, lineHeight: 1.7 }}>{q.title}</div>
          <div style={{ minHeight: 34, background: theme.line + "44", borderRadius: 10, padding: "8px 10px", marginBottom: 10, fontSize: 13, lineHeight: 1.9 }}>
            {orderProg.length === 0 ? <span style={{ color: theme.sub }}>اضغط الخطوات بالترتيب الصحيح ↓</span> :
              orderProg.map((s, i) => <div key={i} style={{ color: "#1F7A5C", fontWeight: 700 }}>{i + 1}. {s}</div>)}
          </div>
          {picked === null && [...q.steps].filter(s => !orderProg.includes(s)).length > 0 &&
            (orderShuf[qi % qs.length] || q.steps).map((s) => !orderProg.includes(s) && (
              <button key={s} className="opt" dir="rtl" style={{ textAlign: "right" }} onClick={() => tapStep(s)}>{s}</button>
            ))}
          {orderFails > 0 && picked === null && <div style={{ fontSize: 12.5, color: "#B3402F", fontWeight: 800 }}>ترتيب خاطئ — انعاد من البداية ({orderFails}/2)</div>}
        </>}

        {/* شريط ما بعد الجولة */}
        {picked !== null && hearts > 0 && enemyHp > 0 && (
          <div style={{ marginTop: 8 }}>
            <div style={{ background: (picked === "done" || picked === q.a) ? "#1F7A5C1d" : "#B3402F1d", borderRadius: 12, padding: "11px 13px", fontSize: 13.5, lineHeight: 1.8 }}>
              <b style={{ color: (picked === "done" || picked === q.a) ? "#1F7A5C" : "#B3402F" }}>
                {picked === "done" || picked === q.a ? "⚔️ ضربة ناجحة" : picked === -1 ? "⏰ انتهى الوقت — العدو ضربك" : picked === "failorder" ? "🧩 العدو ضربك — هذا الترتيب الصحيح:" : "🩸 العدو ضربك"}
              </b>{picked === "failorder" ? ` ${q.steps.join(" ← ")}` : q.ex ? ` — ${q.ex}` : q.kind === "num" && picked === "wrongnum" ? ` — الجواب الصحيح: ${q.a}. ${q.ex || ""}` : ""}
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
              {picked !== q.a && picked !== "done" && q.kind !== "match" && q.kind !== "order" && (
                <button className="btn ghost" style={{ flex: 1, padding: 11, fontSize: 13.5 }} onClick={() => { play("click"); setTeach(true); }}>🧑‍🏫 لم أفهم</button>
              )}
              <button className="btn" style={{ flex: 2, padding: 11 }} onClick={next}>استمر بالقتال ←</button>
            </div>
          </div>
        )}
      </div>
      {teach && <Teacher g={g} theme={theme} q={q} picked={typeof picked === "number" && picked >= 0 ? picked : null}
        onBonus={(b) => { setXpGained(x => x + b); setFx(f => ({ ...f, hitEnemy: false })); }}
        onClose={() => setTeach(false)} />}
    </div>
  );
}

/* ═══════════════ 🏁 ENDINGS ═══════════════ */

function Ending({ g, theme, onReplay, onFree }) {
  const E = {
    legend: { e: "👑🛢️", t: "النهاية الأسطورية", d: `"${g.name}... مبروك. أهلًا بك مهندسًا في أرامكو السعودية." — البداية كانت ليلة مذاكرة وكسل يجلس على كتفك. والنهاية: مكتبك يطل على أبراج الظهران. الرحلة اللي بدأت بسؤال حساب... انتهت بحلم كامل.`, c: "#C89235" },
    good: { e: "💼✨", t: "نهاية مشرّفة", d: `حصلت على وظيفة قوية في شركة كبرى. أرامكو ردّت: "ملفك واعد — نرحب بإعادة التقديم بعد سنة خبرة." الحلم مو بعيد... يحتاج جولة أخيرة أقوى.`, c: "#1F7A5C" },
    open: { e: "🌅", t: "الرحلة مستمرة", d: `ما عبرت اختبار أرامكو هالمرة، لكن اللي بنيته ما ينهدم: شهادة، لغة، وعقل أقوى بكثير من طالب الثانوية اللي بدأ الرحلة. ارفع درجاتك وارجع للمعركة الأخيرة.`, c: "#3B82C4" },
  }[g.ending || "open"];
  const acc = g.stats.answered ? Math.round((g.stats.correct / g.stats.answered) * 100) : 0;
  return (
    <div style={{ textAlign: "center", paddingTop: 24, animation: "pop .5s ease" }}>
      <div style={{ fontSize: 74 }}>{E.e}</div>
      <div style={{ fontSize: 24, fontWeight: 900, color: E.c, margin: "8px 0" }}>{E.t}</div>
      <div className="card" style={{ textAlign: "right", fontSize: 15, lineHeight: 2.1, padding: 18 }}>{E.d}</div>
      <div className="card" style={{ textAlign: "right" }}>
        <div style={{ fontWeight: 900, marginBottom: 8 }}>📜 سجل الرحلة</div>
        <div style={{ fontSize: 13.5, lineHeight: 2.2 }}>
          درجة القدرات: <b style={{ color: "#C89235" }}>{g.gatScore ?? "—"}</b> • الجامعة: <b>{g.uni ?? "—"}</b><br />
          دقة الإجابات الكلية: <b>{acc}%</b> • معارك محسومة: <b>{g.stats.battles}</b> • أفضل كومبو: <b>🔥×{g.stats.bestCombo}</b><br />
          الإنجازات: <b>{g.ach.length}/{ACHV.length}</b> • اللقب: <b>{titleOf(g.xp).icon} {titleOf(g.xp).name}</b>
        </div>
      </div>
      {g.ending !== "legend" && <button className="btn gold" style={{ width: "100%", padding: 14, marginBottom: 8 }} onClick={onReplay}>⚔️ أعد المعركة الأخيرة</button>}
      <button className="btn ghost" style={{ width: "100%", padding: 12 }} onClick={onFree}>🗺️ ارجع للعالم (لعب حر ورفع الدرجات)</button>
      <div style={{ fontSize: 12, color: theme.sub, marginTop: 16 }}>Qudrat Quest • صُنعت لرحلة {g.name} الحقيقية 🤍</div>
    </div>
  );
}

/* ═══════════════ 🗂 PANELS ═══════════════ */

function Panel({ g, theme, panel, spFree, close, buySkill, buyItem, buyAvatar, wearAvatar, toast }) {
  const priceOf = (p) => (g.dayFlags?.sale ? Math.ceil(p / 2) : p);
  return (
    <div onClick={close} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 50, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <div onClick={e => e.stopPropagation()} style={{ background: theme.bg, color: theme.text, width: "min(100%,620px)", maxHeight: "82vh", overflowY: "auto", borderRadius: "22px 22px 0 0", padding: "16px 16px 30px", animation: "drop .3s ease" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div style={{ fontWeight: 900, fontSize: 17 }}>
            {panel === "skills" && `🌳 شجرة المهارات (نقاطك: ${spFree})`}
            {panel === "shop" && `🛒 المتجر (🪙 ${g.coins})`}
            {panel === "ach" && `🏅 الإنجازات ${g.ach.length}/${ACHV.length} — ${Math.round((g.ach.length / ACHV.length) * 100)}%`}
            {panel === "stats" && "📊 إحصائياتك"}
          </div>
          <button onClick={close} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: theme.text }}>✕</button>
        </div>

        {panel === "skills" && SKILLS.map(sk => {
          const owned = g.skills.includes(sk.id);
          const can = !owned && spFree >= sk.cost;
          return (
            <div className="card" key={sk.id} style={{ display: "flex", gap: 12, alignItems: "center", border: owned ? "1.5px solid #1F7A5C" : `1px solid ${theme.line}` }}>
              <div style={{ fontSize: 28 }}>{sk.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 900, fontSize: 14 }}>{sk.name} <span style={{ fontSize: 11, color: theme.sub }}>({sk.branch})</span></div>
                <div style={{ fontSize: 12.5, color: theme.sub, marginTop: 2 }}>{sk.desc}</div>
              </div>
              {owned ? <span style={{ color: "#1F7A5C", fontWeight: 900, fontSize: 13 }}>✓ مفتوحة</span> :
                <button className="btn" style={{ padding: "8px 14px", fontSize: 13, opacity: can ? 1 : .45 }} disabled={!can}
                  onClick={() => { buySkill(sk); play("levelup"); }}>{sk.cost} ⭐</button>}
            </div>
          );
        })}
        {panel === "skills" && <div style={{ fontSize: 12.5, color: theme.sub, textAlign: "center" }}>تكسب نقطة مهارة ⭐ مع كل مستوى جديد</div>}

        {panel === "shop" && <>
          <div style={{ fontWeight: 900, fontSize: 13.5, color: "#C89235", margin: "4px 4px 8px" }}>أدوات المعركة{g.dayFlags?.sale ? " — 🏷️ تخفيضات اليوم −50%!" : ""}</div>
          {SHOP_ITEMS.map(it => (
            <div className="card" key={it.id} style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <div style={{ fontSize: 26 }}>{it.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 900, fontSize: 14 }}>{it.name} <span style={{ fontSize: 12, color: theme.sub }}>(معك: {g.items[it.id]})</span></div>
                <div style={{ fontSize: 12.5, color: theme.sub }}>{it.desc}</div>
              </div>
              <button className="btn gold" style={{ padding: "8px 14px", fontSize: 13, opacity: g.coins >= priceOf(it.price) ? 1 : .45 }} disabled={g.coins < priceOf(it.price)}
                onClick={() => { buyItem(it); play("coin"); }}>🪙 {priceOf(it.price)}{g.dayFlags?.sale ? " 🏷️" : ""}</button>
            </div>
          ))}
          <div style={{ fontWeight: 900, fontSize: 13.5, color: "#C89235", margin: "10px 4px 8px" }}>شخصيات</div>
          {AVATARS.map(av => {
            const owned = g.owned.includes(av.id);
            const wearing = g.avatar === av.id;
            return (
              <div className="card" key={av.id} style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <div style={{ fontSize: 28 }}>{av.e}</div>
                <div style={{ flex: 1, fontWeight: 900, fontSize: 14 }}>{av.name}</div>
                {wearing ? <span style={{ color: "#1F7A5C", fontWeight: 900, fontSize: 13 }}>✓ مُرتدى</span> :
                  owned ? <button className="btn" style={{ padding: "8px 14px", fontSize: 13 }} onClick={() => { wearAvatar(av); play("click"); }}>ارتدِ</button> :
                    <button className="btn gold" style={{ padding: "8px 14px", fontSize: 13, opacity: g.coins >= av.price ? 1 : .45 }} disabled={g.coins < av.price}
                      onClick={() => { buyAvatar(av); play("coin"); toast(`${av.e} فتحت: ${av.name}`); }}>🪙 {av.price}</button>}
              </div>
            );
          })}
        </>}

        {panel === "ach" && <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          {ACHV.map(a => {
            const got = g.ach.includes(a.id);
            return (
              <div key={a.id} className="card" style={{ textAlign: "center", opacity: got ? 1 : .45, margin: 0, border: got ? "1.5px solid #C89235" : `1px solid ${theme.line}` }}>
                <div style={{ fontSize: 26, filter: got ? "none" : "grayscale(1)" }}>{a.icon}</div>
                <div style={{ fontWeight: 900, fontSize: 12.5, marginTop: 3 }}>{a.name}</div>
                <div style={{ fontSize: 11, color: theme.sub, marginTop: 2, lineHeight: 1.5 }}>{a.desc}</div>
              </div>
            );
          })}
        </div>}

        {panel === "stats" && <StatsPanel g={g} theme={theme} />}
      </div>
    </div>
  );
}

function ProgressChart({ g, theme }) {
  const h = (g.history || []).filter(x => x.q !== null || x.v !== null);
  if (h.length < 2) return (
    <div className="card" style={{ textAlign: "center", fontSize: 12.5, color: theme.sub }}>
      📈 نم ليلتين على الأقل داخل اللعبة وسيظهر هنا منحنى تطورك في الكمي واللفظي يومًا بيوم
    </div>
  );
  const W = 300, H = 110, pad = 8;
  const pts = (key, color) => {
    const vals = h.map(x => x[key]);
    const path = h.map((x, i) => {
      const px = pad + (i / (h.length - 1)) * (W - 2 * pad);
      const py = H - pad - ((x[key] ?? 0) / 100) * (H - 2 * pad);
      return `${px},${py}`;
    }).join(" ");
    return { path, color, last: vals[vals.length - 1] };
  };
  const q = pts("q", "#C89235"), v = pts("v", "#7B5EA7");
  return (
    <div className="card">
      <div style={{ fontWeight: 900, fontSize: 14, marginBottom: 8 }}>📈 تطورك عبر الأيام</div>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", display: "block" }}>
        {[25, 50, 75].map(y => <line key={y} x1={pad} x2={W - pad} y1={H - pad - (y / 100) * (H - 2 * pad)} y2={H - pad - (y / 100) * (H - 2 * pad)} stroke={theme.line} strokeDasharray="3 4" />)}
        <polyline points={q.path} fill="none" stroke={q.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        <polyline points={v.path} fill="none" stroke={v.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <div style={{ display: "flex", justifyContent: "center", gap: 16, fontSize: 12, fontWeight: 800, marginTop: 4 }}>
        <span style={{ color: "#C89235" }}>● الكمي {q.last ?? "—"}%</span>
        <span style={{ color: "#7B5EA7" }}>● اللفظي {v.last ?? "—"}%</span>
      </div>
    </div>
  );
}


function StatsPanel({ g, theme }) {
  const acc = g.stats.answered ? Math.round((g.stats.correct / g.stats.answered) * 100) : 0;
  const secs = Object.entries(g.stats.bySec);
  return (
    <div>
      <div className="card" style={{ textAlign: "center" }}>
        <div style={{ fontSize: 34, fontWeight: 900, color: acc >= 90 ? "#C89235" : "#0F5147" }}>{acc}%</div>
        <div style={{ fontSize: 13, color: theme.sub }}>الدقة الكلية • {g.stats.correct}/{g.stats.answered} إجابة صحيحة</div>
        <div style={{ fontSize: 13, marginTop: 6, fontWeight: 800 }}>⚔️ {g.stats.battles} معركة محسومة • 🔥 أفضل كومبو ×{g.stats.bestCombo} • ⚡ سلسلة {g.streak} يوم</div>
      </div>
      <ProgressChart g={g} theme={theme} />
      <div className="card">
        <div style={{ fontWeight: 900, marginBottom: 10, fontSize: 14 }}>الدقة حسب القسم — هذي بوصلتك: العب في الأقسام الحمراء</div>
        {secs.length === 0 && <div style={{ fontSize: 13, color: theme.sub }}>خض معاركك الأولى وستظهر بياناتك هنا</div>}
        {secs.length >= 2 && (
          <div style={{ fontSize: 12, fontWeight: 800, background: "#C8923518", color: "#C89235", borderRadius: 10, padding: "7px 10px", marginBottom: 10, lineHeight: 1.7 }}>
            🧠 اللعبة تركز حاليًا على: {[...secs].sort((x, y) => weightOf(g, y[0]) - weightOf(g, x[0])).slice(0, 2).map(([s]) => SEC_AR[s] || s).join(" و ")} — لأنها أضعف أقسامك الآن
          </div>
        )}
        {secs.map(([sec, v]) => {
          const p = Math.round((v.c / v.a) * 100);
          const m = masteryOf(g, sec);
          const avg = v.a ? Math.round((v.t || 0) / v.a) : 0;
          return (
            <div key={sec} style={{ marginBottom: 11 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 12.5, fontWeight: 800, marginBottom: 3, gap: 6 }}>
                <span>{SEC_AR[sec] || sec} <span style={{ fontSize: 10.5, background: theme.line + "88", borderRadius: 6, padding: "1px 6px" }}>{m.e} {m.label}</span></span>
                <span style={{ color: p >= 80 ? "#1F7A5C" : p >= 60 ? "#C89235" : "#B3402F", whiteSpace: "nowrap" }}>{p}% ({v.c}/{v.a}){avg ? ` • ⏱${avg}ث` : ""}{v.to ? ` • ⏰${v.to}` : ""}</span>
              </div>
              <div style={{ background: theme.line, borderRadius: 99, height: 8, overflow: "hidden" }}>
                <div style={{ width: `${p}%`, height: "100%", borderRadius: 99, background: p >= 80 ? "#1F7A5C" : p >= 60 ? "#C89235" : "#B3402F", transition: "width .5s" }} />
              </div>
            </div>
          );
        })}
      </div>
      {g.gatScore && <div className="card" style={{ textAlign: "center", fontWeight: 900 }}>📜 درجة القدرات داخل اللعبة: <span style={{ color: "#C89235", fontSize: 18 }}>{g.gatScore}</span></div>}
    </div>
  );
}
