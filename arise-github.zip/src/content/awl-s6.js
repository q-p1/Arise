/* ═══ AWL Sublist 6 — جاهز للتعبئة ═══
   انسخ مخطط awl-s1.js: const __W = { p1:[{ w, ar, ex, bl, syn, ant? }, ...] };
   ثم: QQ.registerAWL("s6", { title: "S6", packs: [ { id: "s6p1", icon: "📗", name: "...", words: __W.p1 }, ... ] });
   المحرك سيبني الحزم والتدريبات والمراجعة المتباعدة والمعارك تلقائيًا. */
