/* ═══ AWL Sublist 10 — جاهز للتعبئة ═══
   انسخ مخطط awl-s1.js: const __W = { p1:[{ w, ar, ex, bl, syn, ant? }, ...] };
   ثم: QQ.registerAWL("s10", { title: "S10", packs: [ { id: "s10p1", icon: "📗", name: "...", words: __W.p1 }, ... ] });
   المحرك سيبني الحزم والتدريبات والمراجعة المتباعدة والمعارك تلقائيًا. */
