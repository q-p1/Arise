/* ═══ AWL Sublist 9 — جاهز للتعبئة ═══
   انسخ مخطط awl-s1.js: const __W = { p1:[{ w, ar, ex, bl, syn, ant? }, ...] };
   ثم: QQ.registerAWL("s9", { title: "S9", packs: [ { id: "s9p1", icon: "📗", name: "...", words: __W.p1 }, ... ] });
   المحرك سيبني الحزم والتدريبات والمراجعة المتباعدة والمعارك تلقائيًا. */
