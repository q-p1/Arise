/* build.mjs — يجمع المحرك + كل ملفات content/ في ملف اللعبة الواحد */
import { readFileSync, writeFileSync, readdirSync } from "fs";
const dir = new URL(".", import.meta.url).pathname;
const engine = readFileSync(dir + "engine.jsx", "utf8");
const files = readdirSync(dir + "content").filter(f => f.endsWith(".js")).sort();
const content = files.map(f => `\n/* ═══ content/${f} ═══ */\n` + readFileSync(dir + "content/" + f, "utf8")).join("\n");
const out = engine.replace("/*__CONTENT_INJECT__*/", content);
writeFileSync(dir + "../qudrat-quest.jsx", out);
console.log(`✅ built qudrat-quest.jsx — engine + ${files.length} content files:`, files.join(", "));
